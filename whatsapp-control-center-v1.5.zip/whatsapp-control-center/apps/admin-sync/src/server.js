'use strict';

const express = require('express');
const path = require('path');
const fs = require('fs');
const QRCode = require('qrcode');
const { Client, LocalAuth } = require('whatsapp-web.js');
const { getPrimaryClient, initializePrimaryClient, primaryStatus } = require('../../../shared/primary-whatsapp-client');

const { createLogger, instrument } = require('../../../shared/diagnostics');
const diagnostics = createLogger('admin');

const PORT = Number(process.env.PORT || 3020);
const HOST = '127.0.0.1';
const SESSION_DIR = path.join(__dirname, '..', 'sessions');
const DATA_DIR = path.join(__dirname, '..', 'data');
const ACCOUNTS_FILE = path.join(DATA_DIR, 'accounts.json');
const ACTIONS_FILE = path.join(DATA_DIR, 'actions.json');
const MIN_DELAY_MS = 1000;

fs.mkdirSync(SESSION_DIR, { recursive: true });
fs.mkdirSync(DATA_DIR, { recursive: true });

const app = express();
instrument(app, diagnostics);
app.use(express.json({ limit: '100kb' }));
app.use(express.static(path.join(__dirname, '..', 'public')));

const accounts = new Map();
let groups = [];
let inviteResults = [];
let busy = false;
let logs = [];

function now() { return new Date().toISOString(); }
function pause(ms) { return new Promise((resolve) => setTimeout(resolve, ms)); }
function safeText(value, fallback = '') { return String(value ?? fallback).trim(); }
function accountId() { return `account-${Date.now()}-${Math.random().toString(16).slice(2, 7)}`; }
function serializedId(value) {
  if (!value) return '';
  return safeText(value._serialized || value.user || value.$1 || value);
}

function log(level, text, meta = undefined) {
  const row = diagnostics.record(level, text, meta);
  const item = { at: row.at, level: row.level, text: row.message, meta: row.context };
  logs.unshift(item);
  logs = logs.slice(0, 200);
  console[level === 'error' ? 'error' : level === 'warn' ? 'warn' : 'log'](item.text, item.meta || '');
  return item;
}

function loadJson(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch (_) { return fallback; }
}
function saveJson(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2), 'utf8');
}
function saveAccounts() {
  saveJson(ACCOUNTS_FILE, [...accounts.values()].map((record) => ({ id: record.id, label: record.label, primary: record.primary === true })));
}
function appendAction(action) {
  const history = loadJson(ACTIONS_FILE, []);
  history.unshift(action);
  saveJson(ACTIONS_FILE, history.slice(0, 1000));
}

function publicAccount(record) {
  return {
    id: record.id,
    label: record.label,
    status: record.status,
    statusText: record.statusText,
    qrDataUrl: record.qrDataUrl || null,
    me: record.me || null,
    groupCount: record.groups.length,
  };
}

function state() {
  return {
    accounts: [...accounts.values()].map(publicAccount),
    groups,
    inviteResults,
    actions: loadJson(ACTIONS_FILE, []).slice(0, 100),
    logs,
    busy,
  };
}

function groupType(chat) {
  const metadata = chat.groupMetadata || {};
  if (metadata.isCommunityAnnounce || chat.isCommunityAnnounce || metadata.announce === 'community_announce') return 'הכרזה';
  if (metadata.isCommunity || metadata.isParentGroup || chat.isCommunity) return 'קהילה';
  if (metadata.parentGroupId || metadata.parentGroup || chat.parentGroupId) return 'קבוצת קהילה';
  if (chat.isReadOnly || metadata.announce) return 'הכרזה/לקריאה בלבד';
  return 'קבוצה';
}

function participantSummary(participant) {
  const id = serializedId(participant?.id || participant);
  return {
    id,
    isAdmin: Boolean(participant?.isAdmin || participant?.isSuperAdmin),
  };
}

function summarizeChat(chat, me) {
  const id = serializedId(chat?.id);
  const participants = (Array.isArray(chat?.participants) ? chat.participants : []).map(participantSummary).filter((p) => p.id);
  const self = participants.find((participant) => participant.id === me);
  return {
    id,
    name: safeText(chat?.name, id || 'ללא שם'),
    type: groupType(chat),
    isAdmin: Boolean(self?.isAdmin),
    participantCount: participants.length,
  };
}

async function scanAccount(record) {
  if (!record.client || record.status !== 'ready') return [];
  const chats = await record.client.getChats();
  const me = serializedId(record.client.info?.wid);
  record.me = me;
  record.groups = chats
    .filter((chat) => chat?.isGroup)
    .map((chat) => summarizeChat(chat, me))
    .filter((chat) => chat.id);
  return record.groups;
}

function buildComparison() {
  const byId = new Map();
  for (const record of accounts.values()) {
    for (const group of record.groups) {
      if (!byId.has(group.id)) {
        byId.set(group.id, {
          id: group.id,
          name: group.name,
          type: group.type,
          participantCount: group.participantCount,
          accounts: {},
        });
      }
      const row = byId.get(group.id);
      row.name = row.name || group.name;
      row.accounts[record.id] = { present: true, admin: group.isAdmin };
    }
  }

  groups = [...byId.values()].map((row) => {
    const admins = [];
    const missing = [];
    const needsPromotion = [];
    for (const record of accounts.values()) {
      const status = row.accounts[record.id] || { present: false, admin: false };
      row.accounts[record.id] = status;
      if (!status.present) missing.push(record.id);
      else if (status.admin) admins.push(record.id);
      else needsPromotion.push(record.id);
    }
    return {
      ...row,
      admins,
      missing,
      needsPromotion,
      inviteStatus: 'לא נבדק',
      complete: missing.length === 0 && needsPromotion.length === 0,
    };
  }).sort((a, b) => a.name.localeCompare(b.name, 'he'));
}

async function scanAll() {
  const ready = [...accounts.values()].filter((record) => record.status === 'ready');
  log('info', `מתחיל סריקה: ${ready.length} חשבונות מוכנים`);
  for (const record of ready) {
    await scanAccount(record);
    log('info', `נסרקו ${record.groups.length} קבוצות עבור ${record.label}`);
  }
  buildComparison();
  log('info', `ההשוואה הושלמה: ${groups.length} יעדים ייחודיים נמצאו`);
  return groups;
}

function makeClient(record) {
  const sharedPrimary = record.primary === true;
  const client = sharedPrimary
    ? getPrimaryClient()
    : new Client({
      authStrategy: new LocalAuth({ clientId: record.id, dataPath: SESSION_DIR }),
      // QR is delivered to the local Admin Sync screen. Never open WhatsApp Web
      // as a separate visible browser window on the user's desktop.
      puppeteer: { headless: true, args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage'] },
    });
  record.client = client;
  record.status = 'connecting';
  record.statusText = 'ממתין לחיבור';

  client.on('qr', async (qr) => {
    record.qrDataUrl = await QRCode.toDataURL(qr, { margin: 1, width: 280 });
    record.status = 'awaiting_qr';
    record.statusText = 'סרוק את קוד ה־QR בחשבון הזה';
    log('info', `ממתין ל־QR עבור ${record.label}`);
  });
  client.on('authenticated', () => {
    record.statusText = 'ההתחברות אושרה; טוען קבוצות…';
  });
  client.on('auth_failure', (message) => {
    record.status = 'error';
    record.statusText = `שגיאת חיבור: ${message}`;
    log('error', `חיבור נכשל עבור ${record.label}`, { message });
  });
  client.on('ready', async () => {
    record.status = 'ready';
    record.statusText = 'מחובר ומוכן';
    record.qrDataUrl = null;
    record.me = serializedId(client.info?.wid);
    log('info', `${record.label} מחובר ומוכן`);
    try { await scanAll(); } catch (error) { log('warn', 'סריקה ראשונית נכשלה', { message: error.message }); }
  });
  client.on('disconnected', (reason) => {
    record.status = 'disconnected';
    record.statusText = `מנותק: ${reason}`;
    log('warn', `${record.label} נותק`, { reason });
  });
  // A page can open after the shared client has already produced its QR.
  // Reuse the current QR state so the user never needs to trigger a second one.
  const snapshot = sharedPrimary ? primaryStatus() : null;
  if (snapshot?.qr) {
    QRCode.toDataURL(snapshot.qr, { margin: 1, width: 280 }).then((dataUrl) => {
      record.qrDataUrl = dataUrl;
      record.status = 'awaiting_qr';
      record.statusText = 'סרוק את קוד ה־QR של החשבון הראשי';
    }).catch((error) => log('error', 'לא ניתן להציג את ה־QR המשותף', { error: error.message }));
  }
  const start = sharedPrimary ? initializePrimaryClient() : client.initialize();
  start.catch((error) => {
    record.status = 'error';
    record.statusText = error.message;
    log('error', `לא ניתן להפעיל את ${record.label}`, { message: error.message });
  });
}

function accountOrThrow(id) {
  const record = accounts.get(id);
  if (!record || record.status !== 'ready') throw new Error('חשבון ניהול אינו מחובר ומוכן');
  return record;
}
function selectedGroups(ids) {
  const requested = new Set(Array.isArray(ids) ? ids : []);
  return groups.filter((group) => requested.size === 0 || requested.has(group.id));
}
function findAdminAccount(group, usage = null) {
  const candidates = group.admins
    .map((id) => accounts.get(id))
    .filter((record) => record?.status === 'ready');
  if (!usage || candidates.length < 2) return candidates[0] || null;

  // When two or three accounts can manage the same group, spread promotions
  // across them. This avoids making one account perform every admin action.
  return candidates
    .slice()
    .sort((a, b) => (usage.get(a.id) || 0) - (usage.get(b.id) || 0))[0] || null;
}

async function fetchInviteLinks(ids) {
  const results = [];
  for (const group of selectedGroups(ids).filter((row) => row.missing.length)) {
    log('info', 'מתחיל שליפת קישור', { groupId: group.id });
    const manager = findAdminAccount(group);
    if (!manager) {
      results.push({ groupId: group.id, groupName: group.name, ok: false, error: 'אין חשבון מנהל מחובר לשליפת קישור' });
      continue;
    }
    try {
      let code = '';
      let lastError = '';
      // WhatsApp Web occasionally loads group metadata before its invite code.
      // Re-fetch the chat and retry rather than reporting a false permanent failure.
      for (const waitMs of [0, 900, 2200]) {
        log('info', 'ניסיון שליפת קישור', { groupId: group.id, attempt: [0, 900, 2200].indexOf(waitMs) + 1, accountId: manager.id });
        if (waitMs) await pause(waitMs);
        try {
          const chat = await manager.client.getChatById(group.id);
          if (!chat?.isGroup || typeof chat.getInviteCode !== 'function') throw new Error('WhatsApp לא חשף פעולה לשליפת קישור עבור יעד זה');
          const rawCode = await chat.getInviteCode();
          const value = safeText(rawCode?.code || rawCode);
          code = value.replace(/^https?:\/\/chat\.whatsapp\.com\//i, '').trim();
          if (code) break;
          lastError = 'לא הוחזר קוד הזמנה';
        } catch (error) { lastError = error.message; diagnostics.record('warn', 'ניסיון שליפת קישור נכשל', { groupId: group.id, error }); }
      }
      if (!code) throw new Error(`${lastError || 'לא הוחזר קוד הזמנה'}; ייתכן שאין לחשבון הרשאה או שזה יעד שאינו תומך בקישור`);

      let verified = false;
      let verificationError = '';
      try {
        // A retrieved string alone is not enough. Ask WhatsApp to resolve it.
        // The result is kept as evidence in the UI and CSV export.
        const info = await manager.client.getInviteInfo(code);
        verified = Boolean(info);
        log(verified ? 'info' : 'warn', 'בדיקת אימות קישור הסתיימה', { groupId: group.id, verified });
        if (!verified) verificationError = 'WhatsApp לא החזיר פרטים לאימות הקישור';
      } catch (error) { verificationError = error.message; diagnostics.record('warn', 'אימות קישור נכשל', { groupId: group.id, error }); }
      results.push({
        groupId: group.id,
        groupName: group.name,
        sourceAccountId: manager.id,
        ok: verified,
        codeRetrieved: true,
        verified,
        link: `https://chat.whatsapp.com/${code}`,
        error: verificationError,
      });
    } catch (error) {
      diagnostics.record('error', 'שליפת קישור נכשלה', { groupId: group.id, error });
      results.push({ groupId: group.id, groupName: group.name, sourceAccountId: manager.id, ok: false, error: error.message });
    }
    await pause(350);
  }
  inviteResults = results;
  const byId = new Map(results.map((row) => [row.groupId, row]));
  groups = groups.map((group) => ({ ...group, inviteStatus: byId.get(group.id)?.ok ? 'נשלף בהצלחה' : byId.has(group.id) ? 'נכשל' : group.inviteStatus }));
  log('info', `שליפת קישורים הסתיימה: ${results.filter((row) => row.ok).length} קישורים נשלפו ואומתו מתוך ${results.length}`);
  return results;
}

async function promote(ids, delayMs) {
  const result = [];
  const delay = Math.max(MIN_DELAY_MS, Number(delayMs) || 3000);
  const managerUsage = new Map([...accounts.keys()].map((id) => [id, 0]));
  for (const group of selectedGroups(ids)) {
    const manager = findAdminAccount(group, managerUsage);
    if (!manager) {
      result.push({ groupId: group.id, groupName: group.name, ok: false, error: 'אין חשבון מנהל מחובר' });
      continue;
    }
    const chat = await manager.client.getChatById(group.id);
    for (const targetId of group.needsPromotion) {
      const target = accountOrThrow(targetId);
      try {
        log('info', 'מתחיל קידום לניהול', { groupId: group.id, manager: manager.id, target: targetId, delayMs: delay });
        const response = await chat.promoteParticipants([target.me]);
        if (response?.status !== 200) throw new Error(`WhatsApp החזיר סטטוס ${response?.status ?? 'לא ידוע'}`);
        managerUsage.set(manager.id, (managerUsage.get(manager.id) || 0) + 1);
        log('info', `ממתין ${delay / 1000} שניות לפני אימות הקידום`);
        await pause(delay);
        await scanAll();
        const verified = groups.find((row) => row.id === group.id)?.accounts[targetId]?.admin === true;
        const entry = { at: now(), groupId: group.id, groupName: group.name, manager: manager.label, target: target.label, ok: verified, status: verified ? 'אומת' : 'נשלח אך לא אומת' };
        result.push(entry);
        appendAction(entry);
        log(verified ? 'info' : 'warn', `קידום ${target.label} ב־${group.name}: ${entry.status}`);
      } catch (error) {
        const entry = { at: now(), groupId: group.id, groupName: group.name, manager: manager.label, target: target.label, ok: false, error: error.message };
        result.push(entry);
        appendAction(entry);
        log('error', `קידום נכשל ב־${group.name}`, entry);
      }
    }
  }
  return result;
}

app.get('/api/state', (req, res) => res.json(state()));

app.post('/api/accounts', (req, res) => {
  if (accounts.size >= 3) return res.status(400).json({ ok: false, error: 'המערכת מוגבלת לשלושה חשבונות' });
  const label = safeText(req.body?.label, `חשבון ${accounts.size + 1}`).slice(0, 60);
  const record = { id: accountId(), label, primary: false, status: 'new', statusText: 'נוצר', qrDataUrl: null, client: null, me: null, groups: [] };
  accounts.set(record.id, record);
  saveAccounts();
  makeClient(record);
  res.json({ ok: true, account: publicAccount(record) });
});

app.post('/api/scan', async (req, res) => {
  if (busy) return res.status(409).json({ ok: false, error: 'פעולה אחרת עדיין רצה' });
  busy = true;
  try { res.json({ ok: true, groups: await scanAll() }); }
  catch (error) { diagnostics.record('error', 'הפעולה נכשלה', { error }); res.status(500).json({ ok: false, error: error.message }); }
  finally { busy = false; }
});

app.post('/api/invites', async (req, res) => {
  if (busy) return res.status(409).json({ ok: false, error: 'פעולה אחרת עדיין רצה' });
  busy = true;
  try { res.json({ ok: true, results: await fetchInviteLinks(req.body?.groupIds) }); }
  catch (error) { diagnostics.record('error', 'הפעולה נכשלה', { error }); res.status(500).json({ ok: false, error: error.message }); }
  finally { busy = false; }
});

app.post('/api/promote', async (req, res) => {
  if (busy) return res.status(409).json({ ok: false, error: 'פעולה אחרת עדיין רצה' });
  if (req.body?.confirm !== 'PROMOTE') return res.status(400).json({ ok: false, error: 'נדרש אישור מפורש לקידום: PROMOTE' });
  busy = true;
  try { res.json({ ok: true, results: await promote(req.body?.groupIds, req.body?.delayMs) }); }
  catch (error) { diagnostics.record('error', 'הפעולה נכשלה', { error }); res.status(500).json({ ok: false, error: error.message }); }
  finally { busy = false; }
});

app.get('/api/invites.csv', (req, res) => {
  const quote = (value) => `"${String(value ?? '').replace(/"/g, '""')}"`;
  const rows = [['קבוצה', 'נשלף קוד', 'אומת מול WhatsApp', 'קישור', 'חשבון ששולף', 'שגיאה'], ...inviteResults.map((row) => [row.groupName, row.codeRetrieved ? 'כן' : 'לא', row.verified ? 'כן' : 'לא', row.link || '', accounts.get(row.sourceAccountId)?.label || '', row.error || ''])];
  res.type('text/csv; charset=utf-8').attachment('invite-links.csv').send('\ufeff' + rows.map((row) => row.map(quote).join(',')).join('\n'));
});

const savedAccounts = loadJson(ACCOUNTS_FILE, []);
for (const [index, saved] of savedAccounts.entries()) {
  const record = { id: safeText(saved.id), label: safeText(saved.label, 'חשבון'), primary: saved.primary === true || (index === 0 && !savedAccounts.some((row) => row?.primary === true)), status: 'saved', statusText: 'ממתין להפעלה', qrDataUrl: null, client: null, me: null, groups: [] };
  if (record.id) accounts.set(record.id, record);
}
if (!accounts.size) {
  accounts.set('primary', { id: 'primary', label: 'חשבון ראשי משותף', primary: true, status: 'saved', statusText: 'ממתין לחיבור המרכזי', qrDataUrl: null, client: null, me: null, groups: [] });
  saveAccounts();
}

let server = null;
function start(port = PORT) {
  if (server) return server;
  server = app.listen(port, HOST, () => {
  log('info', `WhatsApp Admin Sync מוכן ב־http://${HOST}:${PORT}`);
  for (const record of accounts.values()) makeClient(record);
  });
  return server;
}

if (require.main === module) start();

module.exports = { app, start };
