'use strict';

const path = require('path');
const express = require('express');
const { createLogger, redact } = require('./shared/diagnostics');
const { destroyPrimaryClient } = require('./shared/primary-whatsapp-client');
const diagnostics = createLogger('hub');
const events = [];
let eventId = 0;
function event(system, level, message, context) {
  const row = diagnostics.record(level, message, { ...context, source: system });
  events.push({ ...row, system, id: ++eventId });
  if (events.length > 500) events.shift();
}


const HUB_PORT = Number(process.env.HUB_PORT || 3030);
const HOST = '127.0.0.1';
const root = __dirname;
const apps = [
  { id: 'reports', name: 'בדיקת כפילויות ודוחות', port: 3031, description: 'סריקת משתתפים, כפילויות, קישורי הצטרפות וייצוא דוחות.' },
  { id: 'master', name: 'Master Groups', port: 3032, description: 'ניהול והפצה של הודעות לקבוצות, קהילות והכרזות.' },
  { id: 'admin', name: 'סנכרון ניהול', port: 3033, description: 'השוואת שלושה חשבונות, קישורי הצטרפות וקידום מאומת לניהול.' },
];
const children = new Map();
const modules = {
  reports: require('./apps/reports/src/server'),
  master: require('./apps/master-groups'),
  admin: require('./apps/admin-sync/src/server'),
};

async function startChild(item) {
  event(item.id, 'info', 'מפעיל מערכת');
  children.set(item.id, { startedAt: new Date().toISOString(), status: 'starting' });
  try {
    const server = await modules[item.id].start(item.port);
    children.set(item.id, { server, startedAt: new Date().toISOString(), status: 'running' });
    event(item.id, 'info', 'המערכת מוכנה; משתמשת בחיבור WhatsApp הראשי');
  } catch (error) {
    children.set(item.id, { startedAt: new Date().toISOString(), status: 'failed', error: error.message });
    event(item.id, 'error', 'הפעלת המערכת נכשלה', { error });
  }
}

const app = express();
app.use(express.static(path.join(root, 'public')));
app.get('/api/apps', (req, res) => {
  res.json(apps.map((item) => ({
    ...item,
    url: `http://${HOST}:${item.port}`,
    state: (() => { const { server, ...state } = children.get(item.id) || { status: 'not_started' }; return redact(state); })(),
  })));
});
app.get('/api/logs', (req, res) => res.json({ events, writeFailure: diagnostics.writeFailure }));
app.get('/api/diagnostics/download', (req, res) => {
  const fs = require('node:fs');
  // Only rotated central logs: never sessions, account data, QR images or application reports.
  const contents = [diagnostics.file + '.1', diagnostics.file].filter(f => fs.existsSync(f)).map(f => fs.readFileSync(f, 'utf8')).join('');
  res.type('text/plain; charset=utf-8').attachment('whatsapp-diagnostics.jsonl').send(contents);
});
const poll = setInterval(async () => {
  for (const item of apps) {
    const state = children.get(item.id);
    if (!state || ['stopped', 'failed'].includes(state.status)) continue;
    try {
      const response = await fetch(`http://${HOST}:${item.port}${item.id === 'master' ? '/api/health' : '/api/state'}`, { signal: AbortSignal.timeout(1500) });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const body = await response.json();
      if (!body || typeof body !== 'object') throw new Error('Invalid health response');
      if (state.status !== 'running') event(item.id, 'info', 'המערכת מוכנה; אפשר לחבר חשבון WhatsApp');
      state.status = 'running';
    } catch (_) {
      if (state.status === 'running') event(item.id, 'warn', 'המערכת אינה מגיבה לבדיקת מוכנות');
      state.status = 'starting';
    }
  }
}, 3000);
poll.unref();
const hubServer = app.listen(HUB_PORT, HOST, () => {
  console.log(`WhatsApp Control Center: http://${HOST}:${HUB_PORT}`);
  // Reports starts first because its QR/browser settings are the proven setup.
  void (async () => {
    for (const id of ['reports', 'admin', 'master']) await startChild(apps.find((item) => item.id === id));
  })();
});

hubServer.on('error', (error) => {
  event('hub', 'error', 'לא ניתן לפתוח את מרכז השליטה', { error });
  console.error(error.code === 'EADDRINUSE' ? 'מרכז השליטה כבר פועל או שהפורט תפוס. סגור את ההפעלה הקודמת או הגדר HUB_PORT.' : error.message);
  process.exit(1);
});

let shuttingDown = false;
function shutdown() {
  if (shuttingDown) return;
  shuttingDown = true;
  clearInterval(poll);
  hubServer.close();
  const active = [...children.values()].map(({ server }) => server).filter(Boolean);
  for (const server of active) server.close();
  void destroyPrimaryClient().catch(() => {}).finally(() => process.exit(0));
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
