'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const sensitive = /qr|pairing.?code|invite.?code|token|secret|password|authorization|cookie|session|body|caption|preview|^text$|base64|media|^link$|^code$/i;
function redact(value, depth = 0, seen = new WeakSet()) {
  if (depth > 7) return '[depth limit]';
  if (value instanceof Error) return redact({ name: value.name, message: value.message, stack: value.stack, cause: value.cause }, depth + 1, seen);
  if (typeof value === 'string') return value
    .replace(/https?:\/\/chat\.whatsapp\.com\/[^\s"'<>\\]+/gi, '[invite hidden]')
    .replace(/data:[^\s"']+/gi, '[data hidden]')
    .replace(/"(?:qr[^"]*|pairing[^"]*|inviteCode|token|password|secret|cookie|body[^"]*|caption[^"]*|preview[^"]*|text)"\s*:\s*"(?:\\.|[^"\\])*"/gi, '"private":"[hidden]"')
    .replace(/\b(?:Bearer\s+\S+|[A-Za-z0-9+/_=-]{80,})/gi, '[credential hidden]')
    .replace(/\b(?:qr|pairing[ _-]?code|invite[ _-]?code|token|password|secret|authorization|cookie)\s*[:=]\s*[^\s,;]+/gi, '[credential hidden]')
    .replace(/\b\d{7,}(?::\d+)?@(?:c\.us|g\.us|lid)\b/g, '[WhatsApp ID hidden]')
    .replace(/\b\+?\d{9,15}\b/g, '[number hidden]').slice(0, 12000);
  if (!value || typeof value !== 'object') return value;
  if (seen.has(value)) return '[circular]';
  seen.add(value);
  const result = Array.isArray(value) ? value.slice(0, 100).map(v => redact(v, depth + 1, seen)) : Object.fromEntries(Object.entries(value).slice(0, 100).map(([k,v]) => [k, sensitive.test(k) ? '[hidden]' : redact(v, depth + 1, seen)]));
  seen.delete(value);
  return result;
}
function createLogger(system, options = {}) {
  const directory = options.directory || process.env.DIAGNOSTICS_DIR || path.join(__dirname, '..', 'logs');
  fs.mkdirSync(directory, { recursive: true });
  const file = path.join(directory, `${system}.jsonl`);
  const rows = [];
  let sequence = 0;
  let writeFailure = null;
  function record(level, message, context) {
    const row = redact({ id: ++sequence, at: new Date().toISOString(), system, level, message, context });
    rows.push(row); if (rows.length > 500) rows.shift();
    try {
      if (fs.existsSync(file) && fs.statSync(file).size > 5 * 1024 * 1024) {
        fs.rmSync(file + '.1', { force: true }); fs.renameSync(file, file + '.1');
      }
      fs.appendFileSync(file, JSON.stringify(row) + '\n', { mode: 0o600 });
      writeFailure = null;
    } catch (error) { writeFailure = redact(error.message); }
    if (process.connected) process.send({ type: 'diagnostic', row }, () => {});
    return row;
  }
  return { record, rows, file, get writeFailure() { return writeFailure; } };
}
function instrument(app, logger) {
  app.use((req, res, next) => {
    if (req.path.startsWith('/api/') && !['/api/state', '/api/health'].includes(req.path)) {
      const operationId = crypto.randomUUID();
      const started = Date.now();
      // Use route templates at completion; never log query strings, request bodies or QR responses.
      logger.record('info', 'הפעולה התחילה', { operationId, method: req.method });
      let finished = false;
      res.once('finish', () => {
        finished = true;
        logger.record(res.statusCode >= 400 ? 'error' : 'info', res.statusCode >= 400 ? 'הפעולה נכשלה' : 'הבקשה הסתיימה', {
          operationId, method: req.method, route: req.route?.path || '[unmatched]', status: res.statusCode, durationMs: Date.now() - started
        });
      });
      res.once('close', () => { if (!finished) logger.record('warn', 'החיבור נסגר לפני סיום הבקשה', { operationId }); });
    }
    next();
  });
}
module.exports = { redact, createLogger, instrument };
