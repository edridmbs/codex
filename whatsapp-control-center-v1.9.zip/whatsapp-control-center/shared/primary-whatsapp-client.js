'use strict';

// A single WhatsApp Web client for the primary account.  The three modules run
// in the same Node process and subscribe to this client, so scanning one QR
// connects that account everywhere without copying Chromium profile files.
const fs = require('fs');
const path = require('path');
const { Client, LocalAuth } = require('whatsapp-web.js');

const runtimeRoot = process.env.SCALEAD_RUNTIME_DIR
  ? path.resolve(process.env.SCALEAD_RUNTIME_DIR)
  : (process.platform === 'win32' && process.env.LOCALAPPDATA
      ? path.join(process.env.LOCALAPPDATA, 'ScaleAd', 'WhatsApp Group Analyzer')
      : path.join(__dirname, '..', 'apps', 'reports'));
const authPath = path.join(runtimeRoot, '.wwebjs_auth');
fs.mkdirSync(authPath, { recursive: true });

function findBrowserExecutable() {
  const candidates = [
    process.env.PUPPETEER_EXECUTABLE_PATH,
    process.env.CHROME_PATH,
    process.env.WEB_BROWSER_PATH,
    process.env.LOCALAPPDATA && path.join(process.env.LOCALAPPDATA, 'Google', 'Chrome', 'Application', 'chrome.exe'),
    process.env.PROGRAMFILES && path.join(process.env.PROGRAMFILES, 'Google', 'Chrome', 'Application', 'chrome.exe'),
    process.env['PROGRAMFILES(X86)'] && path.join(process.env['PROGRAMFILES(X86)'], 'Google', 'Chrome', 'Application', 'chrome.exe'),
    process.env.LOCALAPPDATA && path.join(process.env.LOCALAPPDATA, 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
    process.env.PROGRAMFILES && path.join(process.env.PROGRAMFILES, 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
    process.env['PROGRAMFILES(X86)'] && path.join(process.env['PROGRAMFILES(X86)'], 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
    '/usr/bin/google-chrome', '/usr/bin/google-chrome-stable', '/usr/bin/chromium', '/usr/bin/chromium-browser', '/usr/bin/microsoft-edge',
  ].filter(Boolean);
  return candidates.find((candidate) => fs.existsSync(candidate)) || null;
}
const browserExecutable = findBrowserExecutable();

let client = null;
let initialization = null;
const status = { phase: 'idle', qr: null, reason: null };

function getPrimaryClient() {
  if (client) return client;
  client = new Client({
    // A new, dedicated primary profile using the proven Reports QR settings.
    // It is opened once and shared in memory by the other two modules.
    authStrategy: new LocalAuth({ clientId: 'group-audience-analyzer-primary', dataPath: authPath, rmMaxRetries: 30 }),
    webVersion: process.env.WWEBJS_VERSION || undefined,
    webVersionCache: { type: 'local', path: path.join(runtimeRoot, 'web-cache'), strict: false },
    authTimeoutMs: 300000,
    qrMaxRetries: 0,
    userAgent: false,
    deviceName: 'Windows',
    browserName: 'Chrome',
    takeoverOnConflict: true,
    takeoverTimeoutMs: 5000,
    puppeteer: {
      headless: true,
      protocolTimeout: 900000,
      timeout: 180000,
      defaultViewport: null,
      ...(browserExecutable ? { executablePath: browserExecutable } : {}),
      args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage', '--no-first-run'],
    },
  });
  client.on('qr', (qr) => { status.phase = 'qr'; status.qr = qr; status.reason = null; });
  client.on('authenticated', () => { status.phase = 'authenticated'; status.qr = null; });
  client.on('ready', () => { status.phase = 'ready'; status.qr = null; status.reason = null; });
  client.on('auth_failure', (reason) => { status.phase = 'error'; status.reason = String(reason || 'Authentication failed'); });
  client.on('disconnected', (reason) => { status.phase = 'disconnected'; status.reason = String(reason || 'Disconnected'); status.qr = null; });
  return client;
}

function initializePrimaryClient() {
  const active = getPrimaryClient();
  if (!initialization) initialization = active.initialize().catch((error) => {
    initialization = null;
    throw error;
  });
  return initialization;
}

function isPrimaryClient(value) { return Boolean(client && value === client); }
function primaryStatus() { return { ...status }; }

async function destroyPrimaryClient() {
  if (!client) return;
  const active = client;
  client = null;
  initialization = null;
  status.phase = 'idle';
  status.qr = null;
  status.reason = null;
  await active.destroy();
}

module.exports = { getPrimaryClient, initializePrimaryClient, isPrimaryClient, primaryStatus, destroyPrimaryClient };
