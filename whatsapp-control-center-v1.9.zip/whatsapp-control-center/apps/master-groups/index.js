// Master Groups 2.0 - Multi-account WhatsApp broadcaster
require('dotenv').config();

const express = require('express');
const path = require('path');
const fs = require('fs');
const cors = require('cors');
const crypto = require('crypto');
const QRCode = require('qrcode');
const { Client, LocalAuth } = require('whatsapp-web.js');
const { getPrimaryClient, initializePrimaryClient, isPrimaryClient } = require('../../shared/primary-whatsapp-client');

const { createLogger, instrument } = require('../../shared/diagnostics');
const diagnostics = createLogger('master');

const PORT = Number(process.env.PORT || 3010);
const DEFAULT_ACCOUNT_ID = sanitizeId(process.env.ACCOUNT_ID || 'Master_Broadcaster');
const SESSIONS_DIR = path.resolve(process.env.SESSIONS_DIR || './sessions');
const BROADCAST_DELAY_MS = Math.max(0, Number(process.env.BROADCAST_DELAY_MS || 10000));
const DEFAULT_DELAY_SEC = Math.min(3600, Math.max(0, Math.round(BROADCAST_DELAY_MS / 1000)));
const CONFIG_FILE = path.join(__dirname, 'config.json');


// ---------------- EXTENDED DIAGNOSTIC LOGGING ----------------
const LOG_LEVEL = String(process.env.LOG_LEVEL || 'debug').toLowerCase();
const LOG_TO_FILE = String(process.env.LOG_TO_FILE || 'true').toLowerCase() !== 'false';
const LOG_FILE = diagnostics.file;
const LOG_BODY_PREVIEW_CHARS = Math.max(0, Number(process.env.LOG_BODY_PREVIEW_CHARS || 120));
const LOG_LEVELS = { error: 0, warn: 1, info: 2, debug: 3 };
let logSequence = 0;

if (LOG_TO_FILE) {
  fs.mkdirSync(path.dirname(LOG_FILE), { recursive: true });
}

function safeJson(value, depth = 0) {
  if (depth > 4) return '[max-depth]';
  if (value === null || value === undefined) return value;
  if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') return value;
  if (Array.isArray(value)) return value.slice(0, 30).map((v) => safeJson(v, depth + 1));
  if (typeof value === 'object') {
    const out = {};
    for (const key of Object.keys(value).slice(0, 50)) {
      try { out[key] = safeJson(value[key], depth + 1); } catch { out[key] = '[getter-error]'; }
    }
    return out;
  }
  return String(value);
}

function safeRead(obj, key) {
  try { return obj?.[key]; } catch { return '[getter-error]'; }
}

function summarizeIdObject(value) {
  if (!value) return null;
  const out = { type: typeof value };
  try { out.keys = Object.keys(value).slice(0, 30); } catch { out.keys = ['[keys-error]']; }
  for (const key of ['id', '_serialized', '$1', 'user', 'server', 'domain', 'device']) {
    try {
      if (value[key] !== undefined) out[key] = value[key];
    } catch {
      out[key] = '[getter-error]';
    }
  }
  return out;
}

function extractMessageText(msg) {
  const direct = safeRead(msg, 'body');
  if (typeof direct === 'string' && direct.length) return { text: direct, source: 'body' };

  const publicCaption = safeRead(msg, 'caption');
  if (typeof publicCaption === 'string' && publicCaption.length) return { text: publicCaption, source: 'caption' };

  const data = safeRead(msg, '_data');
  const dataCaption = safeRead(data, 'caption');
  if (typeof dataCaption === 'string' && dataCaption.length) return { text: dataCaption, source: '_data.caption' };

  const dataBody = safeRead(data, 'body');
  if (typeof dataBody === 'string' && dataBody.length) return { text: dataBody, source: '_data.body' };

  return { text: '', source: null };
}

async function resolveMediaCaptionFromStore(client, source, accountId) {
  if (!client?.pupPage || !source?.hasMedia) return { text: '', source: null };
  const idObject = safeRead(source, 'id');
  const messageId = serializedId(idObject);
  if (!messageId) return { text: '', source: null };

  try {
    const result = await client.pupPage.evaluate(async (messageId) => {
      const tryValue = (value) => typeof value === 'string' && value.trim().length ? value : '';
      const deepFindCaption = (value, depth = 0, seen = new Set()) => {
        if (!value || depth > 5) return '';
        if ((typeof value !== 'object' && typeof value !== 'function') || seen.has(value)) return '';
        seen.add(value);
        for (const key of ['caption', 'text', 'body']) {
          try {
            const candidate = tryValue(value[key]);
            if (candidate) return { text: candidate, key };
          } catch {}
        }
        let keys = [];
        try { keys = Object.keys(value).slice(0, 120); } catch {}
        for (const key of keys) {
          if (key === 'id' || key === '_data') continue;
          let child;
          try { child = value[key]; } catch { continue; }
          const found = deepFindCaption(child, depth + 1, seen);
          if (found) return { text: found.text, key: `${key}.${found.key}` };
        }
        return '';
      };

      try {
        const collections = window.require('WAWebCollections');
        let msg = collections?.Msg?.get(messageId);
        if (!msg && typeof collections?.Msg?.getMessagesById === 'function') {
          const batch = await collections.Msg.getMessagesById([messageId]);
          msg = batch?.messages?.[0] || null;
        }
        if (!msg) return { text: '', source: null, storeFound: false };

        const candidates = [
          ['store.caption', msg?.caption],
          ['store.body', msg?.body],
          ['store._data.caption', msg?._data?.caption],
          ['store._data.body', msg?._data?.body],
        ];
        for (const [source, value] of candidates) {
          const text = tryValue(value);
          if (text) return { text, source, storeFound: true };
        }

        const deep = deepFindCaption(msg);
        if (deep) return { text: deep.text, source: `store.deep:${deep.key}`, storeFound: true };
        return { text: '', source: null, storeFound: true };
      } catch (error) {
        return { text: '', source: null, storeFound: false, error: String(error?.message || error) };
      }
    }, messageId);

    debugLog('debug', `[${accountId}] MEDIA STORE CAPTION LOOKUP`, {
      messageId,
      result,
    });
    return result || { text: '', source: null };
  } catch (error) {
    debugLog('debug', `[${accountId}] MEDIA STORE CAPTION LOOKUP FAILED`, {
      messageId,
      message: error?.message,
    });
    return { text: '', source: null };
  }
}

async function resolveMediaCaption(client, source, accountId) {
  if (!source?.hasMedia) return extractMessageText(source);

  let best = extractMessageText(source);
  if (best.text.trim()) return best;

  // On current WhatsApp Web builds, message_create for an outgoing media
  // message can fire before the underlying Store model has been patched with
  // the caption typed in the media composer. Refresh the Message object a few
  // times before giving up, then fall back to the raw Store lookup.
  const attempts = [0, 150, 400, 900, 1500];
  for (const waitMs of attempts) {
    if (waitMs) await sleep(waitMs);

    try {
      if (typeof source.reload === 'function') {
        const reloaded = await source.reload();
        if (reloaded) {
          const refreshed = extractMessageText(reloaded);
          debugLog('debug', `[${accountId}] MEDIA CAPTION RELOAD`, {
            waitMs,
            bodyLength: refreshed.text.length,
            source: refreshed.source,
            type: safeRead(reloaded, 'type'),
            hasMedia: safeRead(reloaded, 'hasMedia'),
          });
          if (refreshed.text.trim()) return refreshed;
          best = refreshed;
        }
      }
    } catch (error) {
      debugLog('debug', `[${accountId}] MEDIA CAPTION RELOAD FAILED`, {
        waitMs,
        message: error?.message,
      });
    }

    const fromStore = await resolveMediaCaptionFromStore(client, source, accountId);
    if (fromStore.text?.trim()) return fromStore;
  }

  return best;
}

function summarizeMessage(msg, source = null) {
  const target = source || msg;
  return {
    messageKeys: (() => { try { return Object.keys(msg || {}).slice(0, 80); } catch { return ['[keys-error]']; } })(),
    sourceKeys: target && target !== msg ? (() => { try { return Object.keys(target).slice(0, 80); } catch { return ['[keys-error]']; } })() : undefined,
    id: summarizeIdObject(safeRead(target, 'id')),
    from: safeRead(target, 'from'),
    to: safeRead(target, 'to'),
    author: safeRead(target, 'author'),
    fromMe: safeRead(target, 'fromMe'),
    type: safeRead(target, 'type'),
    hasMedia: safeRead(target, 'hasMedia'),
    hasQuotedMsg: safeRead(target, 'hasQuotedMsg'),
    isForwarded: safeRead(target, 'isForwarded'),
    timestamp: safeRead(target, 'timestamp'),
    bodyLength: String(safeRead(target, 'body') || '').length,
    bodyPreview: LOG_BODY_PREVIEW_CHARS > 0 ? String(safeRead(target, 'body') || '').slice(0, LOG_BODY_PREVIEW_CHARS) : undefined,
    mediaInfo: (() => {
      try {
        const mi = safeRead(target, 'mediaKey') || safeRead(target, '_data')?.mediaData || null;
        return safeJson(mi);
      } catch { return '[media-info-error]'; }
    })(),
  };
}

function debugLog(level, message, meta = undefined) {
  const normalized = LOG_LEVELS[level] !== undefined ? level : 'info';
  if (LOG_LEVELS[normalized] > (LOG_LEVELS[LOG_LEVEL] ?? LOG_LEVELS.debug)) return;
  logSequence++;
  const row = diagnostics.record(normalized, message, meta);
  console[normalized === 'error' ? 'error' : normalized === 'warn' ? 'warn' : 'log'](row.message);
}

process.on('uncaughtException', (error) => {
  debugLog('error', 'UNCAUGHT_EXCEPTION', { message: error?.message, stack: error?.stack });
});
process.on('unhandledRejection', (reason) => {
  debugLog('error', 'UNHANDLED_REJECTION', { reason: reason?.message || reason, stack: reason?.stack });
});

if (!fs.existsSync(SESSIONS_DIR)) fs.mkdirSync(SESSIONS_DIR, { recursive: true });

let config = loadConfig();
const accounts = new Map();
let chatCache = new Map();
let broadcastLocks = new Set();

// WhatsApp Web can expose a Community's Announcement destination as a normal
// @g.us chat with isReadOnly=true. Keep the original Chat objects intact so
// their sendMessage methods continue to work, while remembering which chats
// are really Community Announcements.
const communityAnnouncementChats = new WeakSet();
const communityAnnouncementParents = new WeakMap();

function sanitizeId(value) {
  const cleaned = String(value || '')
    .trim()
    .replace(/[^a-zA-Z0-9_-]+/g, '_')
    .replace(/^_+|_+$/g, '')
    .slice(0, 40);
  return cleaned || `account_${Date.now()}`;
}

function makeAccountId(displayName = 'WhatsApp') {
  const base = sanitizeId(displayName) || 'WhatsApp';
  let id = base;
  let n = 2;
  while (config.accounts[id] || accounts.has(id)) id = `${base}_${n++}`;
  return id;
}

function loadConfig() {
  let raw = {};
  if (fs.existsSync(CONFIG_FILE)) {
    try {
      raw = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8')) || {};
    } catch (error) {
      console.error('Could not read config.json:', error.message);
    }
  }

  // Migrate the previous single-account config automatically.
  if (raw.accounts && typeof raw.accounts === 'object') {
    return {
      version: 2,
      accounts: raw.accounts,
    };
  }

  const legacyAccount = {
    id: DEFAULT_ACCOUNT_ID,
    name: DEFAULT_ACCOUNT_ID,
    masterChatId: raw.masterGroupId || null,
    masterChatName: raw.masterGroupName || null,
    masterChatType: raw.masterGroupType || null,
    targets: [],
    targetTypes: {},
    enabled: true,
  };

  return {
    version: 2,
    accounts: {
      [DEFAULT_ACCOUNT_ID]: legacyAccount,
    },
  };
}

function saveConfig() {
  fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2), 'utf8');
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function normalizeDelaySec(value, fallback = DEFAULT_DELAY_SEC) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(3600, Math.max(0, Math.round(n)));
}

function normalizeDelayRange(minValue, maxValue) {
  let minSec = normalizeDelaySec(minValue, DEFAULT_DELAY_SEC);
  let maxSec = normalizeDelaySec(maxValue, DEFAULT_DELAY_SEC);
  if (minSec > maxSec) [minSec, maxSec] = [maxSec, minSec];
  return { minSec, maxSec };
}

function pickRandomDelaySec(minSec, maxSec) {
  if (minSec === maxSec) return minSec;
  return Math.floor(Math.random() * (maxSec - minSec + 1)) + minSec;
}

function normalizeAccountSettings(settings, fallback = {}) {
  const safeTargets = Array.isArray(settings.targets) ? settings.targets.map((x) => String(x)).filter(Boolean) : [];
  const rawTargetTypes = settings.targetTypes && typeof settings.targetTypes === 'object' ? settings.targetTypes : {};
  const delayRange = normalizeDelayRange(
    settings.delayMinSec ?? fallback.delayMinSec ?? DEFAULT_DELAY_SEC,
    settings.delayMaxSec ?? fallback.delayMaxSec ?? DEFAULT_DELAY_SEC,
  );
  return {
    id: settings.id || fallback.id,
    name: String(settings.name || fallback.name || settings.id || fallback.id || 'WhatsApp'),
    masterChatId: settings.masterChatId || null,
    masterChatName: settings.masterChatName || null,
    masterChatType: settings.masterChatType || null,
    targets: [...new Set(safeTargets.map((x) => String(x)).filter(Boolean))],
    targetTypes: Object.fromEntries(
      Object.entries(rawTargetTypes)
        .map(([id, type]) => [String(id), String(type)])
        .filter(([id]) => safeTargets.includes(id))
    ),
    delayMinSec: delayRange.minSec,
    delayMaxSec: delayRange.maxSec,
    enabled: settings.enabled !== false,
  };
}

function ensureAccountConfig(id, name = id) {
  if (!config.accounts[id]) {
    config.accounts[id] = normalizeAccountSettings({
      id,
      name,
      masterChatId: null,
      targets: [],
      enabled: true,
    });
    saveConfig();
  }
  config.accounts[id] = normalizeAccountSettings(config.accounts[id], { id, name });
  return config.accounts[id];
}

function accountClient(accountId) {
  return accounts.get(accountId)?.client || null;
}

function accountState(accountId) {
  const item = accounts.get(accountId);
  if (!item) return 'missing';
  return item.state;
}

function serializedId(value) {
  if (!value) return null;
  return value._serialized ?? value.$1 ?? null;
}

function normalizeChatNameForPairing(value) {
  return String(value || '')
    .normalize('NFKC')
    .replace(/\s+/g, ' ')
    .trim()
    .toLocaleLowerCase('he');
}

function getChatType(chat) {
  const id = serializedId(chat?.id) || '';
  if (chat && communityAnnouncementChats.has(chat)) return 'announcement';
  if (chat?.isChannel || id.endsWith('@newsletter')) return 'channel';
  if (chat?.isGroup || id.endsWith('@g.us')) {
    const meta = chat?.groupMetadata || {};
    const isAnnouncement = Boolean(
      meta.isCommunityAnnounce ||
      chat?.isCommunityAnnounce ||
      meta.isAnnouncement ||
      meta.announce === 'community_announce' ||
      meta.announcement
    );
    if (isAnnouncement) return 'announcement';

    const isCommunity = Boolean(
      meta.isParentGroup ||
      meta.isCommunity ||
      chat?.isCommunity
    );
    if (isCommunity) return 'community';

    const parentGroupId = meta.parentGroupId ||
      meta.parentGroup?.id ||
      meta.linkedParent ||
      chat?.parentGroupId ||
      chat?.linkedParent;
    if (parentGroupId) return 'community_group';

    return 'group';
  }
  return 'other';
}

function isCommunityAnnouncement(chat) {
  const meta = chat?.groupMetadata || {};
  return Boolean(
    meta.isCommunityAnnounce ||
    chat?.isCommunityAnnounce ||
    meta.isAnnouncement ||
    meta.announcement
  );
}

function communityParentId(chat) {
  if (chat && communityAnnouncementParents.has(chat)) {
    return communityAnnouncementParents.get(chat);
  }
  const meta = chat?.groupMetadata || {};
  const raw = meta.linkedParent || meta.parentGroupId || meta.parentGroup?.id || chat?.linkedParent || chat?.parentGroupId;
  return serializedId(raw) || (typeof raw === 'string' ? raw : null);
}

function decorateCommunityAnnouncementChats(chats) {
  const list = Array.isArray(chats) ? chats : [];
  const communities = list.filter((chat) => getChatType(chat) === 'community');
  const byName = new Map();

  for (const community of communities) {
    const key = normalizeChatNameForPairing(community?.name);
    if (!key) continue;
    const bucket = byName.get(key) || [];
    bucket.push(community);
    byName.set(key, bucket);
  }

  for (const chat of list) {
    if (!chat || chat.isReadOnly !== true) continue;
    if (getChatType(chat) !== 'group') continue;

    const meta = chat?.groupMetadata || {};
    const rawParent = meta.linkedParent || meta.parentGroupId || meta.parentGroup?.id || chat?.linkedParent || chat?.parentGroupId;
    const explicitParent = serializedId(rawParent) || (typeof rawParent === 'string' ? rawParent : null);
    const explicitAnnouncement = Boolean(
      meta.isCommunityAnnounce ||
      chat?.isCommunityAnnounce ||
      meta.isAnnouncement ||
      meta.announce === 'community_announce' ||
      meta.announcement
    );

    if (explicitAnnouncement || explicitParent) {
      communityAnnouncementChats.add(chat);
      if (explicitParent) communityAnnouncementParents.set(chat, explicitParent);
      continue;
    }

    // In this user's Communities, the Announcement destination appears as a
    // read-only group with the same display name as the parent Community.
    // Only auto-pair when exactly one Community has that name, so unrelated
    // read-only groups remain locked.
    const key = normalizeChatNameForPairing(chat?.name);
    const matches = key ? (byName.get(key) || []) : [];
    if (matches.length === 1) {
      const parentId = serializedId(matches[0]?.id);
      communityAnnouncementChats.add(chat);
      if (parentId) communityAnnouncementParents.set(chat, parentId);
    }
  }

  return list;
}

function communityPublicationKey(chat) {
  const id = serializedId(chat?.id) || '';
  const type = getChatType(chat);
  if (type === 'community') return `community:${id}`;
  if (type === 'announcement') {
    const parent = communityParentId(chat);
    return parent ? `community:${parent}` : `announcement:${id}`;
  }
  return `chat:${id}`;
}

function isCommunityPublishCandidate(chat) {
  const type = getChatType(chat);
  return type === 'community' || type === 'announcement';
}

function expandCommunityTargetIds(rawTargets, chatMap) {
  const expanded = [];
  const seen = new Set();
  const allChats = [...chatMap.values()];
  for (const rawId of rawTargets) {
    const id = String(rawId || '').trim();
    if (!id || seen.has(id)) continue;
    const chat = chatMap.get(id);
    const key = chat && isCommunityPublishCandidate(chat) ? communityPublicationKey(chat) : null;
    const related = key && key.startsWith('community:')
      ? allChats.filter((candidate) => isCommunityPublishCandidate(candidate) && communityPublicationKey(candidate) === key)
      : [chat];
    for (const candidate of related) {
      const candidateId = serializedId(candidate?.id);
      if (candidateId && !seen.has(candidateId)) {
        seen.add(candidateId);
        expanded.push(candidateId);
      }
    }
    if (!related.length && !seen.has(id)) {
      seen.add(id);
      expanded.push(id);
    }
  }
  return expanded;
}

function buildBroadcastUnits(targetIds, targetChatMap) {
  const units = [];
  const byKey = new Map();
  for (const targetId of targetIds) {
    const chat = targetChatMap.get(targetId) || null;
    const type = chat ? getChatType(chat) : null;
    const key = chat && isCommunityPublishCandidate(chat)
      ? communityPublicationKey(chat)
      : `chat:${targetId}`;
    let unit = byKey.get(key);
    if (!unit) {
      unit = { key, candidates: [] };
      byKey.set(key, unit);
      units.push(unit);
    }
    unit.candidates.push({ targetId, chat, type });
  }
  for (const unit of units) {
    unit.candidates.sort((a, b) => {
      const rank = (type) => type === 'announcement' ? 0 : type === 'community' ? 1 : 2;
      return rank(a.type) - rank(b.type);
    });
  }
  return units;
}

function typeLabel(type) {
  return ({
    group: 'קבוצה',
    announcement: 'הכרזה',
    community: 'קהילה',
    community_group: 'קבוצת קהילה',
    channel: 'ערוץ',
  })[type] || 'אחר';
}

function isBroadcastableChat(chat) {
  const type = getChatType(chat);
  return ['group', 'announcement', 'community', 'community_group', 'channel'].includes(type);
}

function globalOwners() {
  const owners = new Map();
  for (const [accountId, settings] of Object.entries(config.accounts)) {
    for (const targetId of settings.targets || []) {
      if (!owners.has(targetId)) owners.set(targetId, accountId);
    }
  }
  return owners;
}

function globalMasters() {
  const masters = new Map();
  for (const [accountId, settings] of Object.entries(config.accounts)) {
    if (settings.masterChatId) masters.set(settings.masterChatId, accountId);
  }
  return masters;
}

function isAccountConfigured(accountId) {
  const settings = config.accounts[accountId];
  return Boolean(settings?.masterChatId && settings.targets?.length);
}

function accountSummary(accountId) {
  const settings = ensureAccountConfig(accountId);
  const item = accounts.get(accountId);
  const info = item?.client?.info;
  return {
    id: accountId,
    name: settings.name,
    ready: Boolean(item?.ready),
    state: item?.state || 'starting',
    enabled: settings.enabled !== false,
    masterChatId: settings.masterChatId,
    masterChatName: settings.masterChatName,
    masterChatType: settings.masterChatType,
    targetCount: settings.targets.length,
    targets: settings.targets,
    targetTypes: settings.targetTypes,
    delayMinSec: settings.delayMinSec,
    delayMaxSec: settings.delayMaxSec,
    qrAvailable: Boolean(item?.qrImage),
    phone: info?.wid?.user || null,
    pushname: info?.pushname || null,
    configured: isAccountConfigured(accountId),
  };
}

async function safeGetChats(client) {
  const all = [];
  try {
    const chats = await client.getChats();
    if (Array.isArray(chats)) all.push(...chats);
  } catch (error) {
    debugLog('error', 'getChats failed', { message: error?.message, stack: error?.stack });
  }

  if (typeof client.getChannels === 'function') {
    try {
      const channels = await client.getChannels();
      if (Array.isArray(channels)) all.push(...channels);
    } catch (error) {
      debugLog('warn', 'getChannels failed', { message: error?.message, stack: error?.stack });
    }
  }

  const seen = new Set();
  return all.filter((chat) => {
    const id = serializedId(chat?.id);
    if (!id || seen.has(id) || !isBroadcastableChat(chat)) return false;
    seen.add(id);
    return true;
  });
}

async function loadChatsForAccount(accountId, force = false) {
  const item = accounts.get(accountId);
  if (!item?.ready) return [];
  const cached = chatCache.get(accountId);
  if (!force && cached && Date.now() - cached.at < 15000) return cached.chats;

  const chats = await safeGetChats(item.client);
  decorateCommunityAnnouncementChats(chats);
  chatCache.set(accountId, { at: Date.now(), chats });
  return chats;
}

function serializeChat(chat) {
  const id = serializedId(chat.id);
  if (!id) throw new Error('לא ניתן לזהות את מזהה השיחה.');
  const type = getChatType(chat);
  const meta = chat.groupMetadata || {};
  return {
    id,
    name: chat.name || 'ללא שם',
    type,
    typeLabel: typeLabel(type),
    isReadOnly: Boolean(chat.isReadOnly),
    isGroup: Boolean(chat.isGroup),
    isChannel: Boolean(chat.isChannel),
    announce: Boolean(meta.announce),
    isCommunityAnnounce: isCommunityAnnouncement(chat),
    communityParentId: communityParentId(chat),
  };
}

function availableChats(accountId, chats) {
  const settings = ensureAccountConfig(accountId);
  const owners = globalOwners();
  const masters = globalMasters();

  return chats
    .map((chat) => {
      const base = serializeChat(chat);
      const selected = settings.targets.includes(base.id);
      const isMaster = settings.masterChatId === base.id;
      const masterOf = masters.get(base.id);
      const targetOf = owners.get(base.id);

      let lockedBy = null;
      let lockReason = null;
      if (masterOf && masterOf !== accountId) {
        lockedBy = masterOf;
        lockReason = 'master';
      } else if (targetOf && targetOf !== accountId) {
        lockedBy = targetOf;
        lockReason = 'target';
      } else if (base.isReadOnly && !isMaster && !isCommunityPublishCandidate(base)) {
        lockReason = 'readonly';
      }

      return {
        ...base,
        selected,
        isMaster,
        lockedBy,
        lockReason,
      };
    })
    .sort((a, b) => {
      if (a.isMaster !== b.isMaster) return a.isMaster ? -1 : 1;
      if (a.selected !== b.selected) return a.selected ? -1 : 1;
      return a.name.localeCompare(b.name, 'he');
    });
}

async function buildAccountChatMap(accountId, force = false) {
  const chats = await loadChatsForAccount(accountId, force);
  return new Map(chats.map((chat) => [serializedId(chat.id), chat]).filter(([id]) => Boolean(id)));
}


async function installMediaRuntimePatch(client, accountId) {
  if (!client || !client.pupPage) return false;
  try {
    const installed = await client.pupPage.evaluate(() => {
      if (!window.WWebJS || typeof window.WWebJS.processMediaData !== 'function') return false;
      if (window.__MASTER_GROUPS_MEDIA_PATCH_INSTALLED__) return true;

      const original = window.WWebJS.processMediaData;
      const sanitize = (value) => {
        if (!value || typeof value !== 'object') return value;
        const clean = { ...value };
        delete clean.__x_id;
        if (typeof value.toJSON === 'function') {
          const originalToJSON = value.toJSON.bind(value);
          clean.toJSON = () => {
            const json = originalToJSON() || {};
            const jsonClean = { ...json };
            delete jsonClean.__x_id;
            return jsonClean;
          };
        }
        return clean;
      };

      window.WWebJS.processMediaData = async (...args) => {
        const result = await original(...args);
        return sanitize(result);
      };

      if (typeof window.WWebJS.processStickerData === 'function') {
        const originalSticker = window.WWebJS.processStickerData;
        window.WWebJS.processStickerData = async (...args) => {
          const result = await originalSticker(...args);
          return sanitize(result);
        };
      }

      window.__MASTER_GROUPS_MEDIA_PATCH_INSTALLED__ = true;
      return true;
    });
    debugLog(installed ? 'info' : 'warn', `[${accountId}] MEDIA RUNTIME PATCH ${installed ? 'INSTALLED' : 'UNAVAILABLE'}`);
    return installed;
  } catch (error) {
    debugLog('error', `[${accountId}] MEDIA RUNTIME PATCH FAILED`, { message: error?.message, stack: error?.stack });
    return false;
  }
}

async function createWhatsAppAccount(settings) {
  const accountId = settings.id;
  if (accounts.has(accountId)) return accounts.get(accountId);

  const item = {
    id: accountId,
    state: 'starting',
    ready: false,
    qrImage: null,
    qrText: null,
    client: null,
  };
  accounts.set(accountId, item);

  const sharedPrimary = accountId === DEFAULT_ACCOUNT_ID;
  const client = sharedPrimary ? getPrimaryClient() : new Client({
    authStrategy: new LocalAuth({
      clientId: accountId,
      dataPath: SESSIONS_DIR,
    }),
    puppeteer: {
      headless: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox'],
    },
  });

  item.client = client;
  debugLog('info', `[${accountId}] client created`, { sessionDir: SESSIONS_DIR, ready: item.ready, state: item.state });

  client.on('qr', async (qr) => {
    debugLog('info', `[${accountId}] QR received`, { qrLength: String(qr || '').length });
    item.qrText = qr;
    item.qrImage = null;
    item.state = 'qr_received';
    item.ready = false;
    try {
      item.qrImage = await QRCode.toDataURL(qr, {
        errorCorrectionLevel: 'M',
        margin: 2,
        width: 360,
      });
    } catch (error) {
      debugLog('error', `[${accountId}] QR conversion failed`, { message: error?.message, stack: error?.stack });
    }
  });

  client.on('authenticated', () => {
    item.state = 'authenticated';
    item.ready = false;
    debugLog('info', `[${accountId}] authenticated`);
  });

  client.on('ready', async () => {
    await installMediaRuntimePatch(item.client, accountId);
    item.ready = true;
    item.state = 'ready';
    item.qrText = null;
    item.qrImage = null;
    chatCache.delete(accountId);
    debugLog('info', `[${accountId}] ready`, {
      wid: summarizeIdObject(safeRead(item.client?.info, 'wid')),
      pushname: safeRead(item.client?.info, 'pushname'),
    });
    void (async () => {
      try {
        if (typeof item.client.getWWebVersion === 'function') {
          debugLog('info', `[${accountId}] WWebVersion`, { version: await item.client.getWWebVersion() });
        }
      } catch (e) {
        debugLog('warn', `[${accountId}] getWWebVersion failed`, { message: e?.message, stack: e?.stack });
      }
    })();
  });

  client.on('auth_failure', (message) => {
    item.ready = false;
    item.state = 'auth_failure';
    debugLog('error', `[${accountId}] auth failure`, { message });
  });

  client.on('disconnected', (reason) => {
    item.ready = false;
    item.state = 'disconnected';
    item.qrText = null;
    item.qrImage = null;
    chatCache.delete(accountId);
    debugLog('warn', `[${accountId}] disconnected`, { reason });
  });

  client.on('change_state', (state) => {
    debugLog('debug', `[${accountId}] change_state`, { state });
    if (!item.ready) item.state = String(state || 'starting').toLowerCase();
  });

  client.on('message', (msg) => {
    debugLog('debug', `[${accountId}] EVENT message`, summarizeMessage(msg));
    void handleIncomingMessage(accountId, msg);
  });

  client.on('message_create', (msg) => {
    debugLog('debug', `[${accountId}] EVENT message_create`, summarizeMessage(msg));
    // Some WhatsApp surfaces (notably channels in some versions) can expose
    // outgoing messages through message_create rather than message.
    void handleIncomingMessage(accountId, msg, true);
  });

  const start = sharedPrimary ? initializePrimaryClient() : client.initialize();
  start.catch((error) => {
    item.ready = false;
    item.state = 'initialization_failed';
    console.error(`[${accountId}] initialization failed:`, error);
  });

  return item;
}

async function handleIncomingMessage(accountId, msg, isCreatedEvent = false) {
  const settings = config.accounts[accountId];
  const item = accounts.get(accountId);
  debugLog('debug', `[${accountId}] handleIncomingMessage:start`, {
    isCreatedEvent,
    ready: Boolean(item?.ready),
    enabled: Boolean(settings?.enabled),
    masterChatId: settings?.masterChatId || null,
    msg: summarizeMessage(msg),
  });

  if (!item?.ready || !settings?.enabled || !settings.masterChatId) {
    debugLog('debug', `[${accountId}] message ignored: account not ready/enabled or master not configured`);
    return;
  }
  if (isCreatedEvent && !msg.fromMe) {
    debugLog('debug', `[${accountId}] message_create ignored: fromMe=false`);
    return;
  }
  // WhatsApp Web can expose outgoing messages with the sender's LID in `from`
  // and the actual chat/group in `to`. For incoming messages, the chat is in
  // `from`. Normalize both cases before comparing with the configured master.
  const sourceChatId = msg.fromMe
    ? (safeRead(msg, 'to') || safeRead(msg, 'from'))
    : (safeRead(msg, 'from') || safeRead(msg, 'to'));

  if (sourceChatId !== settings.masterChatId) {
    debugLog('debug', `[${accountId}] message ignored: source chat mismatch`, {
      expectedMasterChatId: settings.masterChatId,
      sourceChatId,
      actualFrom: msg.from,
      actualTo: msg.to,
      msgFrom: safeRead(msg, 'from'),
      msgTo: safeRead(msg, 'to'),
      fromMe: Boolean(safeRead(msg, 'fromMe')),
    });
    return;
  }

  debugLog('info', `[${accountId}] master message accepted`, {
    masterChatId: settings.masterChatId,
    sourceChatId,
    fromMe: Boolean(safeRead(msg, 'fromMe')),
    type: safeRead(msg, 'type'),
    hasMedia: Boolean(safeRead(msg, 'hasMedia')),
    bodyLength: String(safeRead(msg, 'body') || '').length,
  });
  if (!msg.body && !msg.hasMedia && !msg.hasQuotedMsg) {
    debugLog('debug', `[${accountId}] message ignored: no body/media/quote`);
    return;
  }

  // Prevent re-entrancy for a single account/master while it is already broadcasting.
  const lock = `${accountId}:${settings.masterChatId}`;
  if (broadcastLocks.has(lock)) {
    debugLog('warn', `[${accountId}] broadcast already running; ignoring overlapping master message.`, { lock });
    return;
  }
  broadcastLocks.add(lock);
  try {
    debugLog('debug', `[${accountId}] resolving source message`, { hasQuotedMsg: msg.hasQuotedMsg });
    const source = msg.hasQuotedMsg ? await msg.getQuotedMessage() : msg;
    debugLog('debug', `[${accountId}] source resolved`, summarizeMessage(msg, source));
    // Resolve the original message once. Media is downloaded only during the
    // actual broadcast so each target receives a fresh MessageMedia payload.
    await broadcastFromAccount(accountId, source, sourceChatId);
  } catch (error) {
    debugLog('error', `[${accountId}] broadcast preparation failed`, {
      message: error?.message,
      name: error?.name,
      stack: error?.stack,
      error: safeJson(error),
    });
  } finally {
    broadcastLocks.delete(lock);
  }
}

async function broadcastFromAccount(accountId, source, sourceChatId) {
  const settings = config.accounts[accountId];
  const item = accounts.get(accountId);
  debugLog('info', `[${accountId}] broadcastFromAccount:start`, {
    ready: Boolean(item?.ready),
    enabled: Boolean(settings?.enabled),
    masterChatId: settings?.masterChatId,
    masterChatName: settings?.masterChatName,
    configuredTargets: settings?.targets?.length || 0,
    source: summarizeMessage(source),
  });

  if (!item?.ready || !settings?.enabled || !settings.masterChatId) {
    debugLog('warn', `[${accountId}] broadcast aborted: account not ready/enabled or master missing`);
    return;
  }

  const extractedText = await resolveMediaCaption(item.client, source, accountId);
  const content = extractedText.text;
  if (source.hasMedia) {
    debugLog('debug', `[${accountId}] MEDIA CAPTION RESOLVED`, {
      source: extractedText.source,
      captionLength: content.length,
      captionPreview: LOG_BODY_PREVIEW_CHARS > 0 ? content.slice(0, LOG_BODY_PREVIEW_CHARS) : undefined,
      directBodyLength: String(safeRead(source, 'body') || '').length,
      publicCaptionLength: String(safeRead(source, 'caption') || '').length,
      dataCaptionLength: String(safeRead(safeRead(source, '_data'), 'caption') || '').length,
    });
  }
  const masterIds = new Set(Object.values(config.accounts).map((x) => x.masterChatId).filter(Boolean));

  let targetChatMap = new Map();
  try {
    targetChatMap = await buildAccountChatMap(accountId, true);
    debugLog('debug', `[${accountId}] target chat map built`, {
      chatCount: targetChatMap.size,
      sample: [...targetChatMap.entries()].slice(0, 5).map(([id, chat]) => ({
        id,
        name: safeRead(chat, 'name'),
        type: getChatType(chat),
      })),
    });
  } catch (error) {
    debugLog('error', `[${accountId}] failed building target chat map`, {
      message: error?.message,
      stack: error?.stack,
    });
    return;
  }

  // A Community is represented by the Community chat and its Announcement chat.
  // Keep both configured as publish candidates, but broadcast them as ONE logical unit.
  const expandedConfiguredTargets = expandCommunityTargetIds(settings.targets || [], targetChatMap);
  const targets = [...new Set(expandedConfiguredTargets)]
    .filter((id) => id && id !== settings.masterChatId && id !== sourceChatId);
  const safeTargets = targets.filter((id) => !masterIds.has(id) && id !== settings.masterChatId && id !== sourceChatId);

  debugLog('info', `[${accountId}] target selection`, {
    sourceChatId,
    configuredMasterChatId: settings.masterChatId,
    configuredMasterChatName: settings.masterChatName,
    configuredTargets: targets,
    configuredTargetCount: targets.length,
    safeTargets,
    safeTargetCount: safeTargets.length,
    excludedMasterIds: [...masterIds],
  });

  if (!safeTargets.length) {
    debugLog('warn', `[${accountId}] no safe targets configured.`);
    return;
  }

  const broadcastUnits = buildBroadcastUnits(safeTargets, targetChatMap);
  debugLog('info', `[${accountId}] broadcast started`, {
    configuredTargetCount: safeTargets.length,
    logicalPublishUnits: broadcastUnits.length,
    units: broadcastUnits.map((unit) => ({
      key: unit.key,
      candidates: unit.candidates.map((candidate) => ({
        targetId: candidate.targetId,
        name: safeRead(candidate.chat, 'name'),
        type: candidate.type,
        isReadOnly: Boolean(safeRead(candidate.chat, 'isReadOnly')),
        communityParentId: communityParentId(candidate.chat),
      })),
    })),
  });

  let ok = 0;
  let failed = 0;

  for (let index = 0; index < broadcastUnits.length; index += 1) {
    const unit = broadcastUnits[index];
    let unitSucceeded = false;
    let lastUnitError = null;

    for (let candidateIndex = 0; candidateIndex < unit.candidates.length; candidateIndex += 1) {
      const candidate = unit.candidates[candidateIndex];
      const targetId = candidate.targetId;
      const expectedTargetType = settings.targetTypes?.[targetId] || candidate.type || null;
      const startedAt = Date.now();
      let targetChat = targetChatMap.get(targetId) || null;
      let actualTargetType = targetChat ? getChatType(targetChat) : null;

      debugLog('debug', `[${accountId}] TARGET BEGIN`, {
        unitKey: unit.key,
        candidateIndex,
        candidateCount: unit.candidates.length,
        targetId,
        expectedTargetType,
        targetInChatMap: Boolean(targetChat),
        targetChat: targetChat ? {
          name: safeRead(targetChat, 'name'),
          type: actualTargetType,
          id: summarizeIdObject(safeRead(targetChat, 'id')),
          isReadOnly: Boolean(safeRead(targetChat, 'isReadOnly')),
          isGroup: Boolean(safeRead(targetChat, 'isGroup')),
          isChannel: Boolean(safeRead(targetChat, 'isChannel')),
          communityParentId: communityParentId(targetChat),
        } : null,
      });

      try {
        if (targetChat && typeof targetChat.id !== 'undefined') {
          debugLog('debug', `[${accountId}] TARGET ID INSPECTION`, {
            targetId,
            chatIdObject: summarizeIdObject(safeRead(targetChat, 'id')),
            chatIdSerialized: serializedId(safeRead(targetChat, 'id')),
          });
        }

        // Resolve the exact configured candidate ID immediately before sending.
        if (typeof item.client.getChatById === 'function') {
          debugLog('debug', `[${accountId}] getChatById START`, { targetId });
          const fetched = await item.client.getChatById(targetId);
          const resolvedTargetId = serializedId(safeRead(fetched, 'id'));
          debugLog('debug', `[${accountId}] getChatById OK`, {
            targetId,
            resolvedTargetId,
            fetched: fetched ? {
              name: safeRead(fetched, 'name'),
              type: getChatType(fetched),
              id: summarizeIdObject(safeRead(fetched, 'id')),
              isReadOnly: Boolean(safeRead(fetched, 'isReadOnly')),
              isCommunityAnnounce: isCommunityAnnouncement(fetched),
              communityParentId: communityParentId(fetched),
            } : null,
          });
          if (!fetched || resolvedTargetId !== targetId) {
            throw new Error(`TARGET_ID_MISMATCH: configured=${targetId} resolved=${resolvedTargetId || 'null'}`);
          }
          if (resolvedTargetId === settings.masterChatId || resolvedTargetId === sourceChatId || masterIds.has(resolvedTargetId)) {
            throw new Error(`TARGET_BLOCKED: target resolves to master/source chat (${resolvedTargetId})`);
          }
          actualTargetType = getChatType(fetched);

          // WhatsApp Web can resolve a Community Announcement destination
          // as a normal read-only group object. The exact ID is still the
          // Announcement candidate selected by the user, so keep the
          // configured semantic type instead of incorrectly falling back to
          // the parent Community.
          if (expectedTargetType === 'announcement' && actualTargetType === 'group' && safeRead(fetched, 'isReadOnly') === true) {
            debugLog('debug', `[${accountId}] ANNOUNCEMENT RESOLUTION OVERRIDE`, {
              targetId: resolvedTargetId,
              configuredType: expectedTargetType,
              resolvedChatType: actualTargetType,
              reason: 'read-only @g.us chat selected as Community Announcement',
            });
            actualTargetType = 'announcement';
          }

          if (expectedTargetType && actualTargetType !== expectedTargetType) {
            throw new Error(`TARGET_TYPE_MISMATCH: configured=${expectedTargetType} resolved=${actualTargetType || 'other'} target=${resolvedTargetId}`);
          }
          targetChat = fetched;
        }

        if (source.hasMedia) {
          debugLog('debug', `[${accountId}] SEND METHOD = media download + chat.sendMessage`, {
            targetId,
            targetType: actualTargetType,
            source: summarizeMessage(source),
          });

          if (typeof source.downloadMedia !== 'function') {
            throw new Error('MEDIA_DOWNLOAD_UNAVAILABLE: source.downloadMedia is not available');
          }
          const media = await source.downloadMedia();
          if (!media) {
            throw new Error('MEDIA_DOWNLOAD_EMPTY: WhatsApp returned no media payload');
          }
          if (!targetChat || typeof targetChat.sendMessage !== 'function') {
            throw new Error('TARGET_CHAT_SEND_UNAVAILABLE: target chat object cannot send messages');
          }

          const mediaOptions = {};
          if (content.trim()) mediaOptions.caption = content;
          await targetChat.sendMessage(media, mediaOptions);

          debugLog('info', `[${accountId}] MEDIA SEND OK`, {
            targetId,
            targetType: actualTargetType,
            mimeType: media.mimetype || null,
            fileName: media.filename || null,
            hasCaption: Boolean(content.trim()),
            elapsedMs: Date.now() - startedAt,
          });
        } else if (content.trim()) {
          if (actualTargetType === 'announcement' && targetChat && typeof targetChat.sendMessage === 'function') {
            // Community Announcements must be sent through the exact Announcement chat object.
            debugLog('debug', `[${accountId}] SEND METHOD = announcementChat.sendMessage`, {
              targetId,
              targetName: safeRead(targetChat, 'name'),
              targetType: actualTargetType,
              parentCommunityId: communityParentId(targetChat),
              textLength: content.length,
            });
            await targetChat.sendMessage(content, { linkPreview: false });
          } else {
            debugLog('debug', `[${accountId}] SEND METHOD = sendMessage(text)`, {
              targetId,
              targetType: actualTargetType,
              textLength: content.length,
              linkPreview: false,
            });
            await item.client.sendMessage(targetId, content, { linkPreview: false });
          }
          debugLog('info', `[${accountId}] SEND OK`, {
            targetId,
            targetType: actualTargetType,
            elapsedMs: Date.now() - startedAt,
          });
        } else {
          debugLog('warn', `[${accountId}] TARGET SKIP: empty content`, { targetId });
          unitSucceeded = true;
          break;
        }

        unitSucceeded = true;
        debugLog('info', `[${accountId}] PUBLISH UNIT OK`, {
          unitKey: unit.key,
          targetId,
          targetType: actualTargetType,
          candidateIndex,
        });
        break;
      } catch (error) {
        lastUnitError = error;
        debugLog('error', `[${accountId}] TARGET FAIL`, {
          unitKey: unit.key,
          targetId,
          targetName: safeRead(targetChat, 'name'),
          targetType: actualTargetType,
          targetIdObject: summarizeIdObject(safeRead(targetChat, 'id')),
          source: summarizeMessage(source),
          method: source.hasMedia ? 'mediaSend' : 'sendMessage',
          elapsedMs: Date.now() - startedAt,
          errorName: error?.name,
          errorMessage: error?.message,
          errorStack: error?.stack,
          errorObject: safeJson(error),
          willTryFallbackCandidate: candidateIndex < unit.candidates.length - 1,
        });

        if (candidateIndex < unit.candidates.length - 1) {
          const nextCandidate = unit.candidates[candidateIndex + 1];
          debugLog('warn', `[${accountId}] PUBLISH FALLBACK`, {
            unitKey: unit.key,
            failedTargetId: targetId,
            failedTargetType: actualTargetType,
            nextTargetId: nextCandidate.targetId,
            nextTargetType: nextCandidate.type,
            reason: error?.message,
          });
        }
      }

      debugLog('debug', `[${accountId}] TARGET END`, {
        targetId,
        elapsedMs: Date.now() - startedAt,
        unitSucceeded,
      });
    }

    if (unitSucceeded) {
      ok += 1;
    } else {
      failed += 1;
      debugLog('error', `[${accountId}] PUBLISH UNIT FAIL`, {
        unitKey: unit.key,
        candidateTargetIds: unit.candidates.map((candidate) => candidate.targetId),
        lastError: lastUnitError?.message,
      });
    }

    if (index < broadcastUnits.length - 1) {
      const delaySec = pickRandomDelaySec(settings.delayMinSec, settings.delayMaxSec);
      debugLog('info', `[${accountId}] WAIT BETWEEN TARGETS`, {
        afterTarget: unit.candidates[0]?.targetId || unit.key,
        nextTarget: broadcastUnits[index + 1].candidates[0]?.targetId || broadcastUnits[index + 1].key,
        delaySec,
        configuredRangeSec: [settings.delayMinSec, settings.delayMaxSec],
      });
      await sleep(delaySec * 1000);
    }
  }

  debugLog('info', `[${accountId}] broadcast complete`, {
    ok,
    failed,
    total: broadcastUnits.length,
    configuredTargetIds: safeTargets,
    delayRangeSec: [settings.delayMinSec, settings.delayMaxSec],
  });
}

function validateAccountId(id) {
  return /^[a-zA-Z0-9_-]{1,40}$/.test(id);
}

async function closeAccount(accountId, removeSession = false) {
  const item = accounts.get(accountId);
  if (!item) return;

  try {
    if (item.client) {
      if (isPrimaryClient(item.client)) {
        throw new Error('החיבור הראשי משותף לכל המערכות. נתק אותו רק ממרכז השליטה.');
      }
      if (removeSession) {
        try { await item.client.logout(); } catch (e) { console.warn(`[${accountId}] logout:`, e.message); }
      }
      try { await item.client.destroy(); } catch (e) { console.warn(`[${accountId}] destroy:`, e.message); }
    }
  } finally {
    accounts.delete(accountId);
    chatCache.delete(accountId);
  }
}

const app = express();
instrument(app, diagnostics);
app.use(cors());
app.use(express.json({ limit: '2mb' }));
app.use(express.static(path.join(__dirname, 'public')));
app.get('/', (_req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

app.get('/api/debug/log-info', (_req, res) => {
  res.json({
    logLevel: LOG_LEVEL,
    logToFile: LOG_TO_FILE,
    logFile: LOG_FILE,
    sequence: logSequence,
  });
});

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, accounts: [...accounts.values()].map((x) => ({ id: x.id, ready: x.ready, state: x.state })) });
});

app.get('/api/config', (_req, res) => {
  const accountList = Object.keys(config.accounts).map(accountSummary);
  res.json({
    version: 2,
    port: PORT,
    delay: BROADCAST_DELAY_MS,
    defaultDelayRangeSec: [DEFAULT_DELAY_SEC, DEFAULT_DELAY_SEC],
    accounts: accountList,
    totalAccounts: accountList.length,
  });
});

app.get('/api/accounts/:accountId/qr', (req, res) => {
  const item = accounts.get(req.params.accountId);
  if (!item?.qrImage) return res.status(404).send('QR code is not available');
  const base64 = item.qrImage.replace(/^data:image\/png;base64,/, '');
  res.type('png').send(Buffer.from(base64, 'base64'));
});

app.get('/api/accounts/:accountId/chats', async (req, res) => {
  const accountId = req.params.accountId;
  if (!config.accounts[accountId] || !accounts.has(accountId)) return res.status(404).json({ message: 'חשבון לא נמצא' });
  if (!accounts.get(accountId).ready) return res.json({ ready: false, chats: [] });

  try {
    const chats = await loadChatsForAccount(accountId, req.query.refresh === '1');
    res.json({ ready: true, chats: availableChats(accountId, chats) });
  } catch (error) {
    console.error(`Chats for ${accountId}:`, error);
    res.status(500).json({ ready: false, message: error.message });
  }
});

app.post('/api/accounts', async (req, res) => {
  const name = String(req.body?.name || '').trim() || `חשבון ${Object.keys(config.accounts).length + 1}`;
  const id = makeAccountId(name);
  const settings = ensureAccountConfig(id, name);
  settings.name = name;
  saveConfig();
  await createWhatsAppAccount(settings);
  res.json({ success: true, account: accountSummary(id) });
});

app.put('/api/accounts/:accountId', async (req, res) => {
  const accountId = req.params.accountId;
  if (!config.accounts[accountId]) return res.status(404).json({ success: false, message: 'חשבון לא נמצא' });

  const settings = ensureAccountConfig(accountId);
  if (typeof req.body?.name === 'string' && req.body.name.trim()) settings.name = req.body.name.trim();
  if (typeof req.body?.enabled === 'boolean') settings.enabled = req.body.enabled;
  saveConfig();
  res.json({ success: true, account: accountSummary(accountId) });
});

app.delete('/api/accounts/:accountId', async (req, res) => {
  const accountId = req.params.accountId;
  if (!config.accounts[accountId]) return res.status(404).json({ success: false, message: 'חשבון לא נמצא' });

  if (Object.keys(config.accounts).length <= 1) {
    return res.status(400).json({ success: false, message: 'לא ניתן למחוק את החשבון האחרון.' });
  }

  await closeAccount(accountId, true);
  delete config.accounts[accountId];
  saveConfig();
  res.json({ success: true });
});

app.post('/api/accounts/:accountId/logout', async (req, res) => {
  const accountId = req.params.accountId;
  if (!config.accounts[accountId]) return res.status(404).json({ success: false, message: 'חשבון לא נמצא' });
  await closeAccount(accountId, false);
  await createWhatsAppAccount(config.accounts[accountId]);
  res.json({ success: true });
});

app.put('/api/accounts/:accountId/routing', async (req, res) => {
  const accountId = req.params.accountId;
  const settings = config.accounts[accountId];
  const item = accounts.get(accountId);
  if (!settings || !item) return res.status(404).json({ success: false, message: 'חשבון לא נמצא' });
  if (!item.ready) return res.status(400).json({ success: false, message: 'החשבון עדיין לא מחובר ל-WhatsApp.' });

  const masterChatId = String(req.body?.masterChatId || '').trim();
  const rawTargets = Array.isArray(req.body?.targets) ? req.body.targets : [];
  const targets = [...new Set(rawTargets.map((id) => String(id).trim()).filter(Boolean))];
  const currentDelayMin = settings.delayMinSec ?? DEFAULT_DELAY_SEC;
  const currentDelayMax = settings.delayMaxSec ?? DEFAULT_DELAY_SEC;
  const delayMinProvided = req.body?.delayMinSec !== undefined;
  const delayMaxProvided = req.body?.delayMaxSec !== undefined;
  const delayRange = normalizeDelayRange(
    delayMinProvided ? req.body.delayMinSec : currentDelayMin,
    delayMaxProvided ? req.body.delayMaxSec : currentDelayMax,
  );
  if ((delayMinProvided && !Number.isFinite(Number(req.body.delayMinSec))) || (delayMaxProvided && !Number.isFinite(Number(req.body.delayMaxSec)))) {
    return res.status(400).json({ success: false, message: 'מרווח השידור חייב להיות מספר בשניות.' });
  }

  const chatMap = await buildAccountChatMap(accountId, true);
  const expandedTargets = expandCommunityTargetIds(targets, chatMap);
  if (!masterChatId || !chatMap.has(masterChatId)) {
    return res.status(400).json({ success: false, message: 'קבוצת המאסטר חייבת להיות ברשימת השיחות של החשבון.' });
  }

  const masterChat = chatMap.get(masterChatId);
  const masterType = getChatType(masterChat);
  if (!isBroadcastableChat(masterChat)) {
    return res.status(400).json({ success: false, message: 'קבוצת המאסטר חייבת להיות קבוצה, קהילה, הכרזה או ערוץ.' });
  }

  const globalOwner = globalOwners();
  const globalMaster = globalMasters();
  const invalid = [];

  if (globalMaster.has(masterChatId) && globalMaster.get(masterChatId) !== accountId) {
    invalid.push('קבוצת המאסטר כבר משויכת לחשבון אחר.');
  }

  const safeTargets = [];
  const targetTypes = {};
  for (const targetId of expandedTargets) {
    if (targetId === masterChatId) continue;
    if (!chatMap.has(targetId)) {
      invalid.push(`יעד ${targetId} לא זמין בחשבון הזה.`);
      continue;
    }
    const chat = chatMap.get(targetId);
    if (!isBroadcastableChat(chat)) {
      invalid.push(`${chat.name || targetId} אינו יעד נתמך.`);
      continue;
    }
    const otherMaster = globalMaster.get(targetId);
    if (otherMaster && otherMaster !== accountId) {
      invalid.push(`${chat.name || targetId} הוא קבוצת המאסטר של ${config.accounts[otherMaster]?.name || otherMaster}.`);
      continue;
    }
    const otherOwner = globalOwner.get(targetId);
    if (otherOwner && otherOwner !== accountId) {
      invalid.push(`${chat.name || targetId} כבר משויך ל-${config.accounts[otherOwner]?.name || otherOwner}.`);
      continue;
    }
    // Community and Announcement chats are both publish candidates.
    // An Announcement may appear as read-only to normal members while still
    // being writable by the connected admin account.
    if (chat.isReadOnly && !isCommunityPublishCandidate(chat)) {
      invalid.push(`${chat.name || targetId} מסומנת כקריאה בלבד.`);
      continue;
    }
    const targetType = getChatType(chat);
    safeTargets.push(targetId);
    targetTypes[targetId] = targetType;
  }

  if (invalid.length) {
    return res.status(400).json({ success: false, message: invalid.slice(0, 8).join(' '), issues: invalid });
  }

  settings.masterChatId = masterChatId;
  settings.masterChatName = masterChat.name || masterChatId;
  settings.masterChatType = masterType;
  settings.targets = safeTargets;
  settings.targetTypes = targetTypes;
  settings.delayMinSec = delayRange.minSec;
  settings.delayMaxSec = delayRange.maxSec;
  saveConfig();

  res.json({ success: true, account: accountSummary(accountId) });
});

// Startup: preserve the current session/config and then initialize all saved accounts.
let server = null;
async function start(port = PORT) {
  if (server) return server;
  if (!config.accounts[DEFAULT_ACCOUNT_ID]) {
    config.accounts[DEFAULT_ACCOUNT_ID] = normalizeAccountSettings({
      id: DEFAULT_ACCOUNT_ID,
      name: DEFAULT_ACCOUNT_ID,
      targets: [],
      enabled: true,
    });
    saveConfig();
  }
  for (const [accountId, settings] of Object.entries(config.accounts)) {
    ensureAccountConfig(accountId, settings.name || accountId);
  }

  for (const settings of Object.values(config.accounts)) {
    await createWhatsAppAccount(settings);
    await sleep(500);
  }
  server = app.listen(port, '127.0.0.1', () => {
  console.log(`Web UI running on http://localhost:${port}`);
  console.log(`Managed WhatsApp accounts: ${Object.keys(config.accounts).length}`);
  debugLog('info', 'Server started', {
    port: PORT,
    logLevel: LOG_LEVEL,
    logToFile: LOG_TO_FILE,
    logFile: LOG_FILE,
    delayMs: BROADCAST_DELAY_MS,
    accounts: Object.keys(config.accounts),
  });
  });
  return server;
}

async function shutdown(signal) {
  console.log(`${signal} received. Shutting down...`);
  server.close();
  for (const accountId of [...accounts.keys()]) {
    await closeAccount(accountId, false);
  }
  process.exit(0);
}

if (require.main === module) {
  process.on('SIGINT', () => void shutdown('SIGINT'));
  process.on('SIGTERM', () => void shutdown('SIGTERM'));
  void start();
}

module.exports = { app, start };
