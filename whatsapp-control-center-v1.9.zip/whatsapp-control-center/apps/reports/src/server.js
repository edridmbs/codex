'use strict';

const path = require('path');
const fs = require('fs');
const { execFileSync } = require('child_process');
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const QRCode = require('qrcode');
const { Client, LocalAuth } = require('whatsapp-web.js');
const { createXlsx } = require('./xlsx');
const { getPrimaryClient, initializePrimaryClient, isPrimaryClient } = require('../../../shared/primary-whatsapp-client');

const { createLogger, instrument } = require('../../../shared/diagnostics');
const diagnostics = createLogger('reports');

const ROOT = path.join(__dirname, '..');
// Keep authentication and account metadata outside the extracted ZIP folder
// on Windows. Updating the application must not register a brand-new linked
// device every time the user extracts a new release.
const RUNTIME_DIR = process.env.SCALEAD_RUNTIME_DIR
  ? path.resolve(process.env.SCALEAD_RUNTIME_DIR)
  : (process.platform === 'win32' && process.env.LOCALAPPDATA
      ? path.join(process.env.LOCALAPPDATA, 'ScaleAd', 'WhatsApp Group Analyzer')
      : ROOT);
const DATA_DIR = path.join(RUNTIME_DIR, 'data');
const REPORTS_DIR = path.join(RUNTIME_DIR, 'reports');
const ACCOUNTS_FILE = path.join(DATA_DIR, 'accounts.json');
const BUNDLED_ACCOUNTS_FILE = path.join(ROOT, 'data', 'accounts.json');
const SCAN_CACHE_FILE = path.join(DATA_DIR, 'scan-cache.json');
const AUTH_DIR = path.join(RUNTIME_DIR, '.wwebjs_auth');
const WEB_CACHE_DIR = path.join(RUNTIME_DIR, '.wwebjs_cache');
const PORT = Number(process.env.PORT || 3037);

fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(REPORTS_DIR, { recursive: true });
if (!fs.existsSync(ACCOUNTS_FILE) && fs.existsSync(BUNDLED_ACCOUNTS_FILE)) {
  fs.copyFileSync(BUNDLED_ACCOUNTS_FILE, ACCOUNTS_FILE);
}

const app = express();
instrument(app, diagnostics);
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

app.use(express.json({ limit: '10mb' }));
app.use(express.static(path.join(ROOT, 'public')));
app.use('/reports', express.static(REPORTS_DIR));

const state = {
  activeAccountId: null,
  groups: [],
  lastReport: null,
  logs: [],
  sessionBusy: false,
  lastFullScan: null,
  lastRecommendation: null
};

const accounts = new Map();
const scanCache = new Map();
let scanCacheWritePromise = Promise.resolve();
let initSeq = 0;

const CONNECTING_STATUSES = new Set(['booting', 'qr', 'authenticated', 'loading', 'pairing']);

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

// Puppeteer does not always find a browser when node_modules was copied with
// the application. Resolve an installed Chrome/Edge explicitly when possible.
function findBrowserExecutable() {
  const candidates = [
    process.env.PUPPETEER_EXECUTABLE_PATH,
    process.env.CHROME_PATH,
    process.env.WEB_BROWSER_PATH,
    process.env.LOCALAPPDATA && path.join(process.env.LOCALAPPDATA, 'Google', 'Chrome', 'Application', 'chrome.exe'),
    process.env.PROGRAMFILES && path.join(process.env.PROGRAMFILES, 'Google', 'Chrome', 'Application', 'chrome.exe'),
    process.env['PROGRAMFILES(X86)'] && path.join(process.env['PROGRAMFILES(X86)'], 'Google', 'Chrome', 'Application', 'chrome.exe'),
    process.env.LOCALAPPDATA && path.join(process.env.LOCALAPPDATA, 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
    process.env.PROGRAMFILES && path.join(process.env.PROGRAMFILES, 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
    process.env['PROGRAMFILES(X86)'] && path.join(process.env['PROGRAMFILES(X86)'], 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
    '/usr/bin/google-chrome', '/usr/bin/google-chrome-stable', '/usr/bin/chromium',
    '/usr/bin/chromium-browser', '/usr/bin/microsoft-edge'
  ].filter(Boolean);
  for (const candidate of candidates) if (fs.existsSync(candidate)) return candidate;

  const commandNames = process.platform === 'win32'
    ? ['chrome.exe', 'msedge.exe']
    : ['google-chrome', 'google-chrome-stable', 'chromium', 'chromium-browser', 'microsoft-edge'];
  for (const name of commandNames) {
    try {
      const command = process.platform === 'win32' ? 'where.exe' : 'which';
      const result = execFileSync(command, [name], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] })
        .split(/\r?\n/).map(v => v.trim()).find(Boolean);
      if (result && fs.existsSync(result)) return result;
    } catch (_) {}
  }
  return null;
}

const BROWSER_EXECUTABLE = findBrowserExecutable();

function clearStaleWebCache() {
  // Keep the versioned cache between launches. Deleting it on every start made
  // WhatsApp Web reload from scratch and could replace a QR while it was being
  // scanned. An explicit environment flag remains available for recovery.
  if (process.env.SCALEAD_CLEAR_WWEB_CACHE !== '1') return;
  try {
    fs.rmSync(WEB_CACHE_DIR, { recursive: true, force: true });
    log('קאש WhatsApp Web נוקה לפי בקשה מפורשת.', 'warn');
  } catch (err) {
    log(`לא הצלחתי לנקות קאש ישן של WhatsApp Web: ${err.message || err}`, 'warn');
  }
}

function isSessionLockError(err) {
  const msg = String(err && (err.stack || err.message || err) || '');
  return /EBUSY|resource busy or locked|first_party_sets\.db|LocalAuth\.js/i.test(msg);
}

function isBrowserTeardownError(err) {
  const msg = String(err && (err.stack || err.message || err) || '');
  return /Attempted to use detached Frame|Execution context was destroyed|Target closed|Session closed|Protocol error \((?:Runtime\.|Target\.)|Most likely the page has been closed|Navigating frame was detached/i.test(msg);
}

function hasRecentIntentionalTeardown() {
  const now = Date.now();
  return [...accounts.values()].some(rec => Number(rec.teardownUntil || 0) > now);
}

function isExpectedShutdownError(err) {
  return isSessionLockError(err) || (isBrowserTeardownError(err) && hasRecentIntentionalTeardown());
}

async function safeRemoveSessionDir(accountId, attempts = 18) {
  const dir = sessionDir(accountId);
  for (let i = 1; i <= attempts; i++) {
    try {
      fs.rmSync(dir, { recursive: true, force: true, maxRetries: 10, retryDelay: 700 });
      return true;
    } catch (err) {
      if (i === attempts) {
        log(`לא הצלחתי למחוק סשן אחרי ${attempts} ניסיונות: ${err.message || err}`, 'error', accountId);
        return false;
      }
      log(`קובץ סשן עדיין נעול, ממתין ומשחרר ניסיון ${i}/${attempts}...`, 'warn', accountId);
      await sleep(1200);
    }
  }
  return false;
}

process.on('uncaughtException', err => {
  if (isExpectedShutdownError(err)) {
    log(`סגירת חיבור ישן הושלמה; הודעת הדפדפן הישנה נבלמה והמערכת ממשיכה לעבוד.`, 'warn');
    emitState();
    return;
  }
  log(`שגיאה לא מטופלת: ${err.stack || err.message || err}`, 'error');
});

process.on('unhandledRejection', err => {
  if (isExpectedShutdownError(err)) {
    log(`סגירת חיבור ישן הושלמה; הודעת הדפדפן הישנה נבלמה והמערכת ממשיכה לעבוד.`, 'warn');
    emitState();
    return;
  }
  log(`Promise לא מטופל: ${err && (err.stack || err.message) || err}`, 'error');
});

function loadAccounts() {
  let saved = null;
  try { saved = JSON.parse(fs.readFileSync(ACCOUNTS_FILE, 'utf8')); } catch (_) {}
  const currentFormat = saved?.controlCenterVersion === 2;
  if (!currentFormat && Array.isArray(saved?.accounts)) {
    // Remove old independent slots (such as a27) during the one-time upgrade.
    // The system now has one clean shared primary account instead.
    for (const row of saved.accounts) {
      try { fs.rmSync(sessionDir(row?.id), { recursive: true, force: true, maxRetries: 8, retryDelay: 300 }); } catch (_) {}
    }
  }
  const rows = currentFormat && Array.isArray(saved?.accounts) && saved.accounts.length ? saved.accounts : [
    { id: 'primary', label: 'חשבון ראשי', createdAt: new Date().toISOString(), primary: true }
  ];
  for (const row of rows) ensureAccount(row.id, row.label || row.account?.pushname || row.id, row);
  state.activeAccountId = saved?.activeAccountId && accounts.has(saved.activeAccountId) ? saved.activeAccountId : rows[0].id;
}

function saveAccounts() {
  const rows = [...accounts.values()].map(rec => ({
    id: rec.id,
    label: rec.label,
    createdAt: rec.createdAt,
    account: rec.account || null,
    primary: rec.primary === true
  }));
  fs.writeFileSync(ACCOUNTS_FILE, JSON.stringify({ controlCenterVersion: 2, activeAccountId: state.activeAccountId, accounts: rows }, null, 2), 'utf8');
}

function clearSavedReportHistory() {
  let removed = 0;
  try {
    for (const name of fs.readdirSync(REPORTS_DIR)) {
      if (!/^report-.*\.(?:json|csv)$/i.test(name)) continue;
      fs.rmSync(path.join(REPORTS_DIR, name), { force: true });
      removed += 1;
    }
  } catch (err) {
    log(`לא הצלחתי לנקות את כל היסטוריית התוצאות: ${err.message || err}`, 'warn');
  }
  if (removed) log(`נמחקו ${removed} קובצי היסטוריית תוצאות קודמים. מטמון הסריקות המאומתות נשמר.`);
}

function ensureAccount(id, label, saved = {}) {
  if (accounts.has(id)) return accounts.get(id);
  const rec = {
    id,
    label: label || id,
    createdAt: saved.createdAt || new Date().toISOString(),
    status: 'idle',
    statusText: 'עדיין לא הופעל',
    qrDataUrl: null,
    pairingCode: null,
    pairingPhone: null,
    pairingCodeRequestedAt: null,
    account: saved.account || null,
    groups: [],
    client: null,
    initSeq: 0,
    refreshPromise: null,
    catalogSyncSeq: 0,
    catalogSyncPromise: null,
    sessionBusy: false,
    readyHandled: false,
    starting: false,
    teardownUntil: 0,
    qrLogged: false,
    authenticatedLogged: false,
    primary: saved.primary === true || accounts.size === 0
  };
  accounts.set(id, rec);
  return rec;
}

function activeRecord() {
  if (!state.activeAccountId || !accounts.has(state.activeAccountId)) {
    state.activeAccountId = accounts.keys().next().value || null;
  }
  return accounts.get(state.activeAccountId) || null;
}

function connectingRecord(excludeAccountId = null) {
  return [...accounts.values()].find(rec => (
    rec.id !== excludeAccountId &&
    rec.client &&
    (rec.starting || CONNECTING_STATUSES.has(rec.status))
  )) || null;
}

function allGroups() {
  // Never expose groups that the matching connected account does not manage.
  // The browser collapses the same managed group across several accounts and
  // prefers the active account, while keeping account-specific filtering.
  return [...accounts.values()].flatMap(rec => (rec.groups || [])
    .filter(group => group.isAdmin === true)
    .map(group => ({
      ...group,
      accountId: rec.id,
      accountLabel: rec.account?.pushname || rec.label,
      key: `${rec.id}::${group.id}`
    })))
    .sort((a, b) => (b.participantsCount - a.participantsCount) || a.name.localeCompare(b.name, 'he'));
}

function accountSummaries() {
  return [...accounts.values()].map(rec => ({
    id: rec.id,
    label: rec.label,
    status: rec.status,
    statusText: rec.statusText,
    account: rec.account,
    groupsCount: (rec.groups || []).length,
    managedGroupsCount: (rec.groups || []).filter(group => group.isAdmin === true).length,
    pairingCode: rec.pairingCode || null,
    pairingPhone: rec.pairingPhone || null,
    isActive: rec.id === state.activeAccountId
  }));
}

function statusForEmit() {
  const rec = activeRecord();
  return {
    active: rec,
    status: rec?.status || 'idle',
    statusText: rec?.statusText || 'לא מחובר',
    qrDataUrl: rec?.qrDataUrl || null,
    pairingCode: rec?.pairingCode || null,
    pairingPhone: rec?.pairingPhone || null,
    account: rec?.account || null
  };
}

function log(message, level = 'info', accountId = null) {
  const rec = accountId ? accounts.get(accountId) : null;
  const prefix = rec ? `[${rec.account?.pushname || rec.label}] ` : '';
  const event = diagnostics.record(level, prefix + message, { accountId });
  const row = { ts: event.at, message: event.message, level, accountId };
  state.logs.unshift(row);
  state.logs = state.logs.slice(0, 350);
  io.emit('log', row);
  console.log(`[${level.toUpperCase()}] ${row.message}`);
}

function emitState() {
  state.groups = allGroups();
  const s = statusForEmit();
  io.emit('state', {
    status: s.status,
    statusText: s.statusText,
    qrDataUrl: s.qrDataUrl,
    account: s.account,
    activeAccountId: state.activeAccountId,
    accounts: accountSummaries(),
    groups: state.groups,
    lastReport: state.lastReport,
    logs: state.logs.slice(0, 100)
  });
}

function safeName(name) {
  return String(name || 'ללא שם').replace(/[\\/:*?"<>|]/g, '-').slice(0, 120);
}

function participantKey(p) {
  return p?.id?._serialized || p?.id?.user || p?._serialized || p?.user || p?.wid?._serialized || String(p?.id || '').trim();
}

function isHumanParticipantId(id) {
  const value = String(id || '').trim().toLowerCase();
  if (!value) return false;
  // Community metadata may contain subgroup IDs. They are not people and must
  // never be included in participant totals or duplicate calculations.
  return !/@g\.us$|@broadcast$|@newsletter$/.test(value);
}

function compactParticipant(p) {
  const id = participantKey(p);
  if (!isHumanParticipantId(id)) return null;
  return { id, isAdmin: Boolean(p?.isAdmin), isSuperAdmin: Boolean(p?.isSuperAdmin) };
}

function compactParticipants(rows) {
  const unique = new Map();
  for (const row of Array.isArray(rows) ? rows : []) {
    const participant = compactParticipant(row);
    if (participant && !unique.has(participant.id)) unique.set(participant.id, participant);
  }
  return [...unique.values()];
}

function loadScanCache() {
  scanCache.clear();
  let saved = null;
  try { saved = JSON.parse(fs.readFileSync(SCAN_CACHE_FILE, 'utf8')); } catch (_) {}
  const rows = Array.isArray(saved?.groups) ? saved.groups : [];
  for (const row of rows) {
    const id = String(row?.id || '').trim();
    // An old cache entry marked as estimated came from metadata that WhatsApp
    // did not refresh. Never reuse it as an authenticated scan.
    if (!id || !id.endsWith('@g.us') || row.participantCountEstimated) continue;
    const participants = compactParticipants(row.participants);
    scanCache.set(id, {
      id,
      name: String(row.name || 'ללא שם'),
      participantsCount: participants.length,
      visibleParticipantsCount: participants.length,
      participantCountSource: row.participantCountSource || 'saved.participants.userIds',
      participantCountEstimated: Boolean(row.participantCountEstimated),
      participantCountPending: false,
      isReadOnly: Boolean(row.isReadOnly),
      communityLike: Boolean(row.communityLike),
      participants,
      scannedAt: row.scannedAt || saved.updatedAt || null
    });
  }
  if (scanCache.size) log(`נטענו ${scanCache.size} סריקות קבוצות שמורות — לא יהיה צורך לסרוק אותן מחדש.`);
}

function persistScanCache() {
  const payload = {
    version: 1,
    updatedAt: new Date().toISOString(),
    groups: [...scanCache.values()]
  };
  scanCacheWritePromise = scanCacheWritePromise.catch(() => {}).then(() => {
    const tempPath = `${SCAN_CACHE_FILE}.tmp`;
    fs.writeFileSync(tempPath, JSON.stringify(payload), 'utf8');
    fs.rmSync(SCAN_CACHE_FILE, { force: true });
    fs.renameSync(tempPath, SCAN_CACHE_FILE);
  });
  return scanCacheWritePromise;
}

function cacheCompletedScan(group) {
  const participants = compactParticipants(group?.participants);
  if (!group?.id || !String(group.id).endsWith('@g.us') || group.participantCountEstimated) return;
  scanCache.set(String(group.id), {
    id: String(group.id),
    name: String(group.name || 'ללא שם'),
    participantsCount: participants.length,
    visibleParticipantsCount: participants.length,
    participantCountSource: group.participantCountSource || 'fresh.participants.userIds',
    participantCountEstimated: Boolean(group.participantCountEstimated),
    participantCountPending: false,
    isReadOnly: Boolean(group.isReadOnly),
    communityLike: Boolean(group.communityLike),
    participants,
    scannedAt: new Date().toISOString()
  });
}

function savedScanForGroup(groupId) {
  const saved = scanCache.get(String(groupId || ''));
  if (!saved) return null;
  return { ...saved, participants: saved.participants.map(row => ({ ...row })) };
}

function bestParticipantCountFromChat(chat, fallbackParticipants = []) {
  // Do not guess from arbitrary metadata fields. In communities, fields such
  // as subgroupCount/size describe the community structure and were previously
  // mistaken for audience size. Only actual user IDs are authoritative.
  const participants = compactParticipants(fallbackParticipants);
  return { value: participants.length, source: 'participants.userIds' };
}

function withTimeout(promise, ms, label = 'operation') {
  let timer;
  return Promise.race([
    promise.finally(() => clearTimeout(timer)),
    new Promise((_, reject) => { timer = setTimeout(() => reject(new Error(`${label} timeout אחרי ${Math.round(ms / 1000)} שניות`)), ms); })
  ]);
}

async function waitForWhatsAppCollections(clientArg, timeoutMs = 180000) {
  const started = Date.now();
  let lastError = null;
  while (Date.now() - started < timeoutMs) {
    try {
      const ready = await withTimeout(clientArg?.pupPage?.evaluate(() => {
        const collections = typeof window.require === 'function' ? window.require('WAWebCollections') : null;
        return Boolean(window.WWebJS && collections?.Chat && typeof collections.Chat.getModelsArray === 'function');
      }), 5000, 'המתנה לטעינת WhatsApp Web');
      if (ready) return true;
    } catch (err) {
      lastError = err;
    }
    await sleep(1500);
  }
  throw new Error(`WhatsApp Web עדיין לא מוכן לטעינת קבוצות${lastError ? `: ${lastError.message || lastError}` : ''}`);
}

function isCommunityLike(chat) {
  const meta = chat.groupMetadata || {};
  const name = String(chat.name || '').toLowerCase();
  return Boolean(meta.isCommunity || meta.isParentGroup || meta.parentGroup || meta.parentGroupId || meta.isCommunityAnnounce || name.includes('community') || name.includes('קהילה'));
}

// Loading the list must be fast. Do not refresh metadata here: one problematic
// community can otherwise block all workers indefinitely. Accurate participant
// data is fetched only for selected groups during the scan.
async function getRawGroupCatalog(clientArg) {
  if (!clientArg?.pupPage) return [];
  return await clientArg.pupPage.evaluate(() => {
    const collections = typeof window.require === 'function' ? window.require('WAWebCollections') : null;
    if (!collections?.Chat || typeof collections.Chat.getModelsArray !== 'function') {
      throw new Error('אוסף הקבוצות של WhatsApp Web עדיין לא נטען');
    }
    const chats = collections.Chat.getModelsArray();
    const serializeParticipants = gm => {
      let rows = [];
      try {
        if (gm?.participants?.serialize) rows = gm.participants.serialize();
        else if (Array.isArray(gm?.participants)) rows = gm.participants;
      } catch (_) {}
      try {
        const { toPn } = window.require('WAWebLidMigrationUtils');
        return (rows || []).map(p => {
          const id = toPn(p?.id) ?? p?.id;
          return { id, isAdmin: Boolean(p?.isAdmin), isSuperAdmin: Boolean(p?.isSuperAdmin) };
        });
      } catch (_) { return rows || []; }
    };
    return chats.filter(chat => chat?.id?._serialized && chat?.id?.server === 'g.us').map(chat => {
      try {
        const metadata = (() => {
          try { return chat.groupMetadata?.serialize?.() || {}; } catch (_) { return {}; }
        })();
        return {
          id: { _serialized: chat.id._serialized, server: 'g.us' },
          name: String(chat.formattedTitle || chat.name || metadata.subject || 'ללא שם'),
          isGroup: true,
          isAdmin: (() => { try { return typeof chat.iAmAdmin === 'function' ? Boolean(chat.iAmAdmin()) : Boolean(chat.iAmAdmin); } catch (_) { return false; } })(),
          isReadOnly: Boolean(chat.groupMetadata?.announce),
          participants: serializeParticipants(chat.groupMetadata),
          groupMetadata: metadata,
          timestamp: chat.t || chat.timestamp || 0
        };
      } catch (_) { return null; }
    }).filter(Boolean);
  });
}

async function getRawGroupById(clientArg, groupId, metadataTimeoutMs = 4500) {
  if (!clientArg?.pupPage) return null;
  return await clientArg.pupPage.evaluate(async ({ groupId, metadataTimeoutMs }) => {
    const collections = typeof window.require === 'function' ? window.require('WAWebCollections') : null;
    if (!collections?.Chat) throw new Error('אוסף הקבוצות של WhatsApp Web עדיין לא נטען');
    const wid = window.require('WAWebWidFactory').createWid(groupId);
    let chat = collections.Chat.get(wid);
    if (!chat && typeof collections.Chat.find === 'function') {
      try {
        chat = await Promise.race([
          collections.Chat.find(wid),
          new Promise(resolve => setTimeout(() => resolve(null), Math.min(metadataTimeoutMs, 2500)))
        ]);
      } catch (_) {}
    }
    if (!chat || chat.id?.server !== 'g.us') return null;
    let metadataRefreshed = false;
    try {
      const Query = window.require('WAWebGroupQueryJob');
      if (Query?.queryAndUpdateGroupMetadataById) {
        metadataRefreshed = await Promise.race([
          Query.queryAndUpdateGroupMetadataById({ id: groupId }).then(() => true).catch(() => false),
          new Promise(resolve => setTimeout(() => resolve(false), metadataTimeoutMs))
        ]);
      } else {
        const metadataCollection = collections.GroupMetadata || collections.WAWebGroupMetadataCollection;
        if (metadataCollection?.update) {
          metadataRefreshed = await Promise.race([
            metadataCollection.update(wid).then(() => true).catch(() => false),
            new Promise(resolve => setTimeout(() => resolve(false), metadataTimeoutMs))
          ]);
        }
      }
    } catch (_) {}
    chat = collections.Chat.get(wid) || chat;
    if (!chat.groupMetadata) return null;
    let metadata = {};
    try { metadata = chat.groupMetadata.serialize?.() || {}; } catch (_) {}
    let participants = [];
    try {
      if (chat.groupMetadata.participants?.serialize) participants = chat.groupMetadata.participants.serialize();
      else if (Array.isArray(chat.groupMetadata.participants)) participants = chat.groupMetadata.participants;
    } catch (_) {}
    try {
      const { toPn } = window.require('WAWebLidMigrationUtils');
      participants = (participants || []).map(p => {
        const id = toPn(p?.id) ?? p?.id;
        return { id, isAdmin: Boolean(p?.isAdmin), isSuperAdmin: Boolean(p?.isSuperAdmin) };
      });
    } catch (_) {}
    return {
      id: { _serialized: chat.id._serialized, server: 'g.us' },
      name: String(chat.formattedTitle || chat.name || metadata.subject || 'ללא שם'),
      isGroup: true,
      isAdmin: (() => { try { return typeof chat.iAmAdmin === 'function' ? Boolean(chat.iAmAdmin()) : Boolean(chat.iAmAdmin); } catch (_) { return false; } })(),
      isReadOnly: Boolean(chat.groupMetadata.announce),
      participants,
      groupMetadata: metadata,
      metadataRefreshed,
      timestamp: chat.t || chat.timestamp || 0
    };
  }, { groupId, metadataTimeoutMs });
}

async function getVerifiedGroupForScan(rec, groupId) {
  const attempts = [
    { metadataTimeoutMs: 8000, totalTimeoutMs: 14000 },
    { metadataTimeoutMs: 15000, totalTimeoutMs: 22000 },
    { metadataTimeoutMs: 25000, totalTimeoutMs: 34000 }
  ];
  let lastError = null;
  let lastChat = null;
  for (let i = 0; i < attempts.length; i++) {
    const attempt = attempts[i];
    try {
      lastChat = await withTimeout(
        getRawGroupById(rec.client, groupId, attempt.metadataTimeoutMs),
        attempt.totalTimeoutMs,
        `אימות מטא-דאטה של ${groupId}`
      );
      if (!lastChat || !lastChat.isGroup || lastChat.id?.server !== 'g.us') {
        throw new Error('הפריט אינו קבוצת וואטסאפ רגילה');
      }
      if (lastChat.metadataRefreshed) return lastChat;
      lastError = new Error('WhatsApp לא אישר שרשימת המשתתפים התרעננה');
    } catch (err) {
      lastError = err;
    }
    if (i < attempts.length - 1) {
      log(`אימות הקבוצה עדיין לא הושלם — ניסיון ${i + 2}/${attempts.length} בעוד ${i + 2} שניות...`, 'warn', rec.id);
      await sleep((i + 2) * 1000);
    }
  }
  const error = new Error(`לא הצלחתי לאמת את רשימת המשתתפים אחרי ${attempts.length} ניסיונות${lastError ? `: ${lastError.message || lastError}` : ''}`);
  error.code = 'GROUP_VERIFY_FAILED';
  error.lastChat = lastChat;
  throw error;
}

function sessionDir(accountId) {
  return path.join(AUTH_DIR, `session-group-audience-analyzer-${accountId}`);
}

async function safeDestroyClient(accountId) {
  const rec = accounts.get(accountId);
  if (!rec?.client) return;
  const old = rec.client;
  if (isPrimaryClient(old)) {
    throw new Error('החיבור הראשי משותף לכל המערכות. נתק אותו רק ממרכז השליטה.');
  }
  // Invalidate every pending handler/promise from the old browser before
  // destroying it. Otherwise its initialize().catch/finally can overwrite the
  // state of a newly-created client with "Execution context was destroyed".
  rec.initSeq += 1;
  rec.client = null;
  rec.starting = false;
  // whatsapp-web.js may finish a delayed evaluate() after destroy() closes the
  // page. Mark a short grace window so that this expected rejection from the
  // old browser cannot be presented as a failure of the replacement account.
  rec.teardownUntil = Date.now() + 30000;
  try { old.removeAllListeners?.(); } catch (_) {}
  try {
    await withTimeout(Promise.resolve(old.destroy()), 15000, 'סגירת חיבור WhatsApp ישן');
  } catch (err) {
    if (!isExpectedShutdownError(err)) log(`destroy החזיר שגיאה לא קריטית: ${err.message || err}`, 'warn', accountId);
  }
  // Give Chromium time to settle its pending callbacks before a replacement
  // client starts on the same LocalAuth slot.
  await sleep(1800);
}

function resetAccountRuntime(rec, clearGroups = false) {
  rec.catalogSyncSeq += 1;
  rec.catalogSyncPromise = null;
  rec.qrDataUrl = null;
  rec.pairingCode = null;
  rec.pairingPhone = null;
  rec.pairingCodeRequestedAt = null;
  rec.account = null;
  rec.readyHandled = false;
  rec.qrLogged = false;
  rec.authenticatedLogged = false;
  rec.status = 'booting';
  rec.statusText = 'פותח חיבור ל-WhatsApp Web...';
  if (clearGroups) rec.groups = [];
}

function createClient(accountId) {
  const rec = accounts.get(accountId);
  if (!rec) throw new Error('חשבון לא קיים');
  if (rec.starting) return;
  const otherConnecting = connectingRecord(accountId);
  if (otherConnecting) {
    throw new Error(`החשבון ${otherConnecting.account?.pushname || otherConnecting.label} עדיין בתהליך חיבור. השלם את החיבור שלו לפני פתיחת חשבון נוסף.`);
  }
  rec.starting = true;
  const mySeq = ++rec.initSeq;
  rec.readyHandled = false;
  rec.qrLogged = false;
  rec.authenticatedLogged = false;
  rec.status = 'booting';
  rec.statusText = 'פותח חיבור ל-WhatsApp Web...';
  emitState();

  const sharedPrimary = rec.primary === true;
  const localClient = sharedPrimary ? getPrimaryClient() : new Client({
    authStrategy: new LocalAuth({ clientId: `group-audience-analyzer-${accountId}`, dataPath: AUTH_DIR, rmMaxRetries: 30 }),
    // Avoid pinning a stale WhatsApp Web build. If the cache is empty,
    // whatsapp-web.js will load the current web.whatsapp.com build and cache it.
    webVersion: process.env.WWEBJS_VERSION || undefined,
    webVersionCache: { type: 'local', path: WEB_CACHE_DIR, strict: false },
    // Large accounts can take several minutes to finish the first sync after
    // scanning. The previous two-minute timeout made the QR appear to work,
    // then the client failed before it reached READY.
    authTimeoutMs: 300000,
    // 0 means unlimited. WhatsApp refreshes an unused QR periodically; a
    // limit of 5 destroyed Puppeteer while initialize() was still running and
    // produced both "Max qrcode retries reached" and
    // "Execution context was destroyed".
    qrMaxRetries: 0,
    // whatsapp-web.js 1.34.7 still defaults to Chrome 101 on macOS 10.14.
    // Let the installed Chrome/Edge expose its real, current user agent so
    // WhatsApp does not reject the QR as an obsolete/unsupported browser.
    userAgent: false,
    deviceName: 'Windows',
    browserName: 'Chrome',
    takeoverOnConflict: true,
    takeoverTimeoutMs: 5000,
    puppeteer: {
      headless: true,
      protocolTimeout: 900000,
      timeout: 180000,
      defaultViewport: null,
      ...(BROWSER_EXECUTABLE ? { executablePath: BROWSER_EXECUTABLE } : {}),
      args: ['--no-sandbox','--disable-setuid-sandbox','--disable-dev-shm-usage','--no-first-run']
    }
  });
  rec.client = localClient;

  localClient.on('qr', async qr => {
    if (mySeq !== rec.initSeq) return;
    try {
      const qrDataUrl = await QRCode.toDataURL(qr, { width: 360, margin: 1 });
      if (mySeq !== rec.initSeq || rec.client !== localClient) return;
      rec.status = 'qr';
      rec.statusText = 'סרוק את ה-QR עם הוואטסאפ שלך — הוא ימשיך להתעדכן עד לסריקה';
      rec.qrDataUrl = qrDataUrl;
      const firstQr = !rec.qrLogged;
      if (firstQr) {
        log('נוצר QR חדש לסריקה — אין מגבלת ניסיונות', 'info', accountId);
        rec.qrLogged = true;
      }
      emitState();
      if (firstQr) {
        try {
          const [webVersion, browserUserAgent] = await Promise.all([
            withTimeout(localClient.getWWebVersion(), 5000, 'קריאת גרסת WhatsApp Web'),
            withTimeout(localClient.pupPage.evaluate(() => navigator.userAgent), 5000, 'קריאת גרסת Chrome')
          ]);
          if (mySeq === rec.initSeq) log(`אבחון חיבור: WhatsApp Web ${webVersion} | ${browserUserAgent}`, 'info', accountId);
        } catch (err) {
          if (mySeq === rec.initSeq) log(`לא הצלחתי לקרוא פרטי אבחון דפדפן: ${err.message || err}`, 'warn', accountId);
        }
      }
    } catch (err) {
      if (mySeq !== rec.initSeq) return;
      log(`לא הצלחתי ליצור תמונת QR: ${err.message || err}`, 'error', accountId);
    }
  });

  localClient.on('authenticated', () => {
    if (mySeq !== rec.initSeq) return;
    rec.status = 'authenticated';
    rec.statusText = 'התחברת בהצלחה, ממתין ל-READY...';
    rec.qrDataUrl = null;
    rec.pairingCode = null;
    rec.pairingPhone = null;
    rec.pairingCodeRequestedAt = null;
    if (!rec.authenticatedLogged) { log('אימות וואטסאפ הצליח', 'info', accountId); rec.authenticatedLogged = true; }
    emitState();
  });

  localClient.on('loading_screen', (percent, message) => {
    if (mySeq !== rec.initSeq) return;
    rec.status = 'loading';
    rec.statusText = `וואטסאפ הסתנכרן: ${Number(percent || 0)}%${message ? ` — ${message}` : ''}`;
    emitState();
  });

  localClient.on('change_state', nextState => {
    if (mySeq !== rec.initSeq) return;
    log(`מצב וואטסאפ השתנה: ${nextState}`, 'info', accountId);
    if (nextState === 'CONFLICT' || nextState === 'UNPAIRED' || nextState === 'UNPAIRED_IDLE') {
      rec.statusText = `וואטסאפ לא השלים חיבור (${nextState}). נסה חיבור מחדש.`;
      emitState();
    }
  });

  localClient.on('ready', async () => {
    if (mySeq !== rec.initSeq) return;
    if (rec.readyHandled) {
      log('READY התקבל שוב — מדלג כדי לא לטעון קבוצות פעמיים', 'warn', accountId);
      return;
    }
    rec.readyHandled = true;
    rec.status = 'ready';
    rec.statusText = 'מחובר ומוכן';
    rec.qrDataUrl = null;
    rec.pairingCode = null;
    rec.pairingPhone = null;
    rec.pairingCodeRequestedAt = null;
    rec.account = localClient.info ? {
      pushname: localClient.info.pushname,
      wid: localClient.info.wid?._serialized || null,
      platform: localClient.info.platform || null
    } : null;
    if (rec.account?.pushname) rec.label = rec.account.pushname;
    saveAccounts();
    log(`המערכת מוכנה${rec.account?.pushname ? ' — ' + rec.account.pushname : ''}`, 'info', accountId);
    emitState();
    try {
      await sleep(8000);
      // טעינת קבוצות ראשונית רצה ברקע. בחשבונות עם הרבה קבוצות זה יכול לקחת כמה דקות.
      await refreshGroups(accountId, { initial: true });
    } catch (err) {
      const details = err && (err.stack || err.message || String(err));
      log(`טעינת הקבוצות האוטומטית נכשלה, אבל החיבור נשאר פעיל. לחץ "רענן קבוצות" אחרי דקה. פירוט: ${details}`, 'error', accountId);
      rec.status = 'ready';
      rec.statusText = 'מחובר, אבל טעינת הקבוצות נכשלה. לחץ רענן קבוצות שוב.';
      emitState();
    }
  });

  localClient.on('auth_failure', msg => {
    if (mySeq !== rec.initSeq) return;
    rec.status = 'auth_failure';
    rec.statusText = 'שגיאת התחברות. כדאי למחוק סשן ולהתחבר מחדש.';
    log(`שגיאת התחברות: ${msg}`, 'error', accountId);
    emitState();
  });

  localClient.on('disconnected', reason => {
    if (mySeq !== rec.initSeq) return;
    rec.status = 'disconnected';
    rec.statusText = 'החיבור נותק';
    log(`נותק: ${reason}`, 'warn', accountId);
    emitState();
  });

  const start = sharedPrimary ? initializePrimaryClient() : localClient.initialize();
  start.catch(err => {
    if (mySeq !== rec.initSeq) return;
    rec.status = 'error';
    const message = String(err?.message || err || 'שגיאה לא ידועה');
    rec.statusText = /Could not find Chrome|executable path|Failed to launch/i.test(message)
      ? 'לא נמצא Chrome/Edge במחשב. התקן Chrome או הגדר PUPPETEER_EXECUTABLE_PATH ואז הפעל מחדש.'
      : 'שגיאה בהפעלת הלקוח — פתח את לוג המערכת לפרטים';
    log(`שגיאה בהפעלה: ${err.stack || message}${BROWSER_EXECUTABLE ? ` | דפדפן: ${BROWSER_EXECUTABLE}` : ' | לא נמצא דפדפן אוטומטי'}`, 'error', accountId);
    emitState();
  }).finally(() => {
    // A previous client's promise may settle after a reconnect. It must never
    // clear the starting flag of the replacement client.
    if (mySeq === rec.initSeq) rec.starting = false;
  });
}

async function waitForInitializationTurn(rec) {
  // Keep account startup strictly sequential. A fresh account remains on its
  // QR until the user scans it; only then may the next saved account start.
  while (true) {
    if (!rec.client) return;
    if (['error', 'auth_failure', 'disconnected'].includes(rec.status)) return;
    if (rec.status === 'ready' && !rec.starting) return;
    await sleep(500);
  }
}

async function waitForFreeConnectionSlot(accountId) {
  while (connectingRecord(accountId)) await sleep(500);
}


function normalizePhoneForPairing(phone) {
  let digits = String(phone || '').replace(/[^0-9]/g, '');
  if (digits.startsWith('00')) digits = digits.slice(2);
  if (digits.startsWith('0') && digits.length >= 9 && digits.length <= 10) digits = '972' + digits.slice(1);
  if (!/^\d{8,15}$/.test(digits)) throw new Error('מספר לא תקין. כתוב מספר מלא, למשל 9725XXXXXXXX או 05XXXXXXXX');
  return digits;
}

async function waitForClientBoot(rec, timeoutMs = 60000) {
  const started = Date.now();
  while (Date.now() - started < timeoutMs) {
    if (rec.client && rec.client.pupPage && typeof rec.client.requestPairingCode === 'function') return rec.client;
    await sleep(300);
  }
  if (!rec.client) throw new Error('הלקוח עדיין לא נוצר. נסה שוב בעוד כמה שניות.');
  return rec.client;
}

async function requestPairingCodeForAccount(accountId, phone) {
  const rec = accounts.get(accountId || state.activeAccountId);
  if (!rec) throw new Error('חשבון לא נמצא');
  if (rec.status === 'ready') throw new Error('החשבון כבר מחובר. כדי לחבר מספר אחר לחץ "נתק והחלף חשבון פעיל" או צור סלוט חדש.');
  const normalizedPhone = normalizePhoneForPairing(phone);
  if (!rec.client && !rec.starting) createClient(rec.id);
  const client = await waitForClientBoot(rec);
  if (typeof client.requestPairingCode !== 'function') {
    throw new Error('גרסת whatsapp-web.js שמותקנת אצלך לא תומכת בקוד צימוד. הרץ npm install כדי לעדכן לגרסה שבחבילה.');
  }
  rec.status = 'pairing';
  rec.statusText = 'מבקש קוד צימוד מ-WhatsApp...';
  emitState();
  const code = await withTimeout(client.requestPairingCode(normalizedPhone, true, 180000), 180000, 'בקשת קוד צימוד');
  rec.pairingCode = String(code || '').trim();
  rec.pairingPhone = normalizedPhone;
  rec.pairingCodeRequestedAt = new Date().toISOString();
  rec.status = 'pairing';
  rec.statusText = rec.pairingCode ? 'התקבל קוד צימוד. הקלד אותו בטלפון.' : 'נשלחה בקשת צימוד. בדוק את הטלפון.';
  log(`נוצר קוד צימוד למספר ${normalizedPhone}${rec.pairingCode ? ': ' + rec.pairingCode : ''}`, 'info', rec.id);
  emitState();
  return { code: rec.pairingCode, phone: normalizedPhone };
}

function dedupeGroupKeysByGroupId(groupKeys) {
  const out = [];
  const seen = new Set();
  for (const key of groupKeys || []) {
    const resolved = resolveGroupKey(key);
    const gid = resolved.groupId;
    if (!gid || seen.has(gid)) continue;
    seen.add(gid);
    out.push(`${resolved.accountId}::${gid}`);
  }
  return out;
}

function catalogGroupFromChat(chat, previous = null) {
  const participants = compactParticipants(chat?.participants);
  const communityLike = isCommunityLike(chat || {});
  const cachedCount = participants.length;
  const savedScan = savedScanForGroup(chat?.id?._serialized);
  const base = {
    id: chat.id._serialized,
    name: chat.name || previous?.name || 'ללא שם',
    participantsCount: cachedCount,
    visibleParticipantsCount: cachedCount,
    participantCountSource: 'cached.participants.userIds',
    participantCountEstimated: false,
    participantCountPending: true,
    isAdmin: Boolean(chat.isAdmin),
    isReadOnly: Boolean(chat.isReadOnly),
    communityLike,
    timestamp: chat.timestamp || previous?.timestamp || 0
  };
  // A completed user-requested scan is more authoritative than the lightweight
  // catalog cache. Preserve it when the background catalog grows.
  if (previous && !previous.participantCountPending) {
    return {
      ...base,
      participantsCount: previous.participantsCount,
      visibleParticipantsCount: previous.visibleParticipantsCount,
      participantCountSource: previous.participantCountSource,
      participantCountEstimated: previous.participantCountEstimated,
      participantCountPending: false,
      isAdmin: Boolean(chat.isAdmin)
    };
  }
  // Restore an accurate completed scan from the persistent runtime cache on
  // the first catalog load after restarting or upgrading the application.
  if (savedScan) {
    return {
      ...base,
      name: chat.name || savedScan.name || base.name,
      participantsCount: savedScan.participantsCount,
      visibleParticipantsCount: savedScan.visibleParticipantsCount,
      participantCountSource: 'saved.participants.userIds',
      participantCountEstimated: savedScan.participantCountEstimated,
      participantCountPending: false,
      isAdmin: Boolean(chat.isAdmin),
      isReadOnly: Boolean(chat.isReadOnly || savedScan.isReadOnly),
      communityLike: Boolean(communityLike || savedScan.communityLike)
    };
  }
  if (previous && Number(previous.participantsCount || 0) > cachedCount) {
    base.participantsCount = Number(previous.participantsCount || 0);
    base.visibleParticipantsCount = Number(previous.visibleParticipantsCount || previous.participantsCount || 0);
  }
  return base;
}

function mergeCatalogGroups(existingGroups, chats) {
  const byId = new Map((existingGroups || []).map(group => [group.id, group]));
  for (const chat of chats || []) {
    if (!chat?.isGroup || chat.id?.server !== 'g.us' || !chat.id?._serialized) continue;
    byId.set(chat.id._serialized, catalogGroupFromChat(chat, byId.get(chat.id._serialized)));
  }
  return [...byId.values()].sort((a, b) => (b.participantsCount - a.participantsCount) || a.name.localeCompare(b.name, 'he'));
}

function syncCatalogInBackground(rec, syncSeq) {
  if (rec.catalogSyncPromise) return rec.catalogSyncPromise;
  const clientRef = rec.client;
  rec.catalogSyncPromise = (async () => {
    const startedAt = Date.now();
    let lastGrowthAt = startedAt;
    let lastCount = (rec.groups || []).length;
    log(`נמצאו כרגע ${(rec.groups || []).filter(group => group.isAdmin === true).length} קבוצות בניהול מתוך ${lastCount}. ממשיך לסנכרן ברקע...`, 'info', rec.id);
    while (Date.now() - startedAt < 150000) {
      await sleep(5000);
      if (rec.catalogSyncSeq !== syncSeq || rec.client !== clientRef || rec.status !== 'ready') return;
      try {
        const chats = await withTimeout(getRawGroupCatalog(rec.client), 20000, 'בדיקת המשך סנכרון קבוצות');
        const merged = mergeCatalogGroups(rec.groups, chats);
        rec.groups = merged;
        if (merged.length > lastCount) {
          lastCount = merged.length;
          lastGrowthAt = Date.now();
          const managedCount = merged.filter(group => group.isAdmin === true).length;
          rec.statusText = `מחובר — נמצאו ${managedCount} קבוצות בניהול, ממשיך לסנכרן ברקע...`;
          log(`הרשימה גדלה ל-${managedCount} קבוצות בניהול מתוך ${lastCount}. ממשיך לבדוק...`, 'info', rec.id);
          emitState();
        }
      } catch (err) {
        log(`בדיקת סנכרון רקע נכשלה זמנית: ${err.message || err}`, 'warn', rec.id);
      }
      const elapsed = Date.now() - startedAt;
      if (elapsed >= 90000 && Date.now() - lastGrowthAt >= 45000) break;
    }
    if (rec.catalogSyncSeq !== syncSeq || rec.client !== clientRef || rec.status !== 'ready') return;
    const managedCount = (rec.groups || []).filter(group => group.isAdmin === true).length;
    rec.statusText = `מחובר ומוכן — נמצאו ${managedCount} קבוצות בניהול`;
    log(`סנכרון הרשימה הסתיים: ${managedCount} קבוצות בניהול מתוך ${rec.groups.length} קבוצות בחשבון.`, 'info', rec.id);
    emitState();
  })().finally(() => {
    if (rec.catalogSyncSeq === syncSeq) rec.catalogSyncPromise = null;
  });
  return rec.catalogSyncPromise;
}

async function refreshGroups(accountId, options = {}) {
  const rec = accounts.get(accountId || state.activeAccountId);
  if (!rec) throw new Error('חשבון לא נמצא');
  if (rec.refreshPromise) return rec.refreshPromise;
  const syncSeq = ++rec.catalogSyncSeq;
  // Invalidate a previous background poll immediately; its sequence check
  // will make it exit without touching the new run.
  rec.catalogSyncPromise = null;
  rec.refreshPromise = (async () => {
    if (!rec.client || rec.status !== 'ready') throw new Error(`חשבון ${rec.label} עדיין לא מחובר`);
    const initialText = options.initial ? 'טוען רשימת קבוצות מהירה. הספירה המדויקת תתבצע רק לקבוצות שייבחרו לבדיקה...' : 'מרענן רשימת קבוצות מהירה...';
    log(initialText, 'info', rec.id);
    rec.statusText = 'מחובר — טוען קבוצות, נא להמתין...';
    emitState();
    let chats;
    let lastErr = null;
    for (let attempt = 1; attempt <= 2; attempt++) {
      try {
        if (attempt > 1) { log('רשימת הקבוצות עדיין לא זמינה. מנסה שוב בעוד 3 שניות...', 'warn', rec.id); await sleep(3000); }
        await waitForWhatsAppCollections(rec.client);
        chats = await withTimeout(getRawGroupCatalog(rec.client), 30000, 'טעינת רשימת קבוצות מ-WhatsApp Web');
        if (!Array.isArray(chats) || !chats.length) throw new Error('רשימת הקבוצות עדיין ריקה');
        break;
      } catch (err) {
        lastErr = err;
        log(`ניסיון ${attempt}/2 לטעינת קבוצות נכשל: ${err && (err.message || String(err))}`, 'warn', rec.id);
      }
    }
    if (!chats) {
      const details = lastErr && (lastErr.stack || lastErr.message || String(lastErr));
      log(`שגיאה בטעינת קבוצות אחרי 2 ניסיונות: ${details}`, 'error', rec.id);
      throw new Error(details || 'שגיאה בטעינת קבוצות');
    }
    log(`התקבלו ${Array.isArray(chats) ? chats.length : 0} צ׳אטים. מסנן קבוצות וואטסאפ...`, 'info', rec.id);
    rec.groups = mergeCatalogGroups(rec.groups, chats);
    rec.status = 'ready';
    const managedCount = rec.groups.filter(group => group.isAdmin === true).length;
    rec.statusText = `מחובר — נמצאו ${managedCount} קבוצות בניהול, ממשיך לסנכרן ברקע...`;
    log(`נטענו ${managedCount} קבוצות בניהול מתוך ${rec.groups.length} קבוצות בחשבון. הרשימה תמשיך להסתנכרן ברקע.`, 'info', rec.id);
    emitState();
    syncCatalogInBackground(rec, syncSeq);
    return rec.groups;
  })().finally(() => { rec.refreshPromise = null; });
  return rec.refreshPromise;
}

function resolveGroupKey(key) {
  const value = String(key || '');
  if (value.includes('::')) {
    const [accountId, ...rest] = value.split('::');
    return { accountId, groupId: rest.join('::') };
  }
  for (const rec of accounts.values()) {
    if ((rec.groups || []).some(g => g.id === value)) return { accountId: rec.id, groupId: value };
  }
  return { accountId: state.activeAccountId, groupId: value };
}

function managedOwnerForGroup(groupId, preferredAccountId = null) {
  const candidates = [...accounts.values()].filter(rec =>
    (rec.groups || []).some(group => group.id === groupId && group.isAdmin === true)
  );
  if (!candidates.length) return null;
  return candidates.find(rec => rec.id === preferredAccountId) ||
    candidates.find(rec => rec.id === state.activeAccountId) ||
    candidates.find(rec => rec.status === 'ready') ||
    candidates[0];
}

function requireManagedGroupKeys(groupKeys) {
  const result = [];
  const seen = new Set();
  const rejected = [];
  for (const key of Array.isArray(groupKeys) ? groupKeys : []) {
    const { accountId, groupId } = resolveGroupKey(key);
    if (!groupId || seen.has(groupId)) continue;
    seen.add(groupId);
    const owner = managedOwnerForGroup(groupId, accountId);
    if (!owner) {
      rejected.push(groupId);
      continue;
    }
    result.push(`${owner.id}::${groupId}`);
  }
  if (rejected.length) {
    throw new Error(`${rejected.length} קבוצות נחסמו כי אף אחד מהחשבונות המחוברים אינו מנהל בהן. רענן את רשימת הקבוצות ונסה שוב.`);
  }
  if (!result.length) throw new Error('לא נבחרו קבוצות שבניהול החשבונות המחוברים');
  return result;
}

async function scanSelectedGroups(groupKeys, options = {}) {
  groupKeys = requireManagedGroupKeys(groupKeys);
  if (!Array.isArray(groupKeys) || groupKeys.length < 1) throw new Error('לא נבחרו קבוצות');
  const total = groupKeys.length;
  const selectedByIndex = new Array(total);
  let nextIndex = 0;
  let completed = 0;
  let loadedFromCache = 0;
  let scannedFresh = 0;
  const scanFailures = [];

  const scanOne = async i => {
    const { accountId, groupId } = resolveGroupKey(groupKeys[i]);
    const rec = accounts.get(accountId);
    if (!rec) throw new Error(`החשבון ${accountId} לא נמצא.`);
    const savedScan = options.forceRescan ? null : savedScanForGroup(groupId);
    if (savedScan) {
      const existing = (rec.groups || []).find(g => g.id === groupId);
      selectedByIndex[i] = {
        ...savedScan,
        key: `${rec.id}::${groupId}`,
        accountId: rec.id,
        accountLabel: rec.account?.pushname || rec.label,
        isAdmin: Boolean(existing?.isAdmin),
        participantCountSource: 'saved.participants.userIds',
        participantCountPending: false
      };
      if (existing) {
        existing.participantsCount = savedScan.participantsCount;
        existing.visibleParticipantsCount = savedScan.visibleParticipantsCount;
        existing.participantCountSource = 'saved.participants.userIds';
        existing.participantCountEstimated = savedScan.participantCountEstimated;
        existing.participantCountPending = false;
        existing.communityLike = savedScan.communityLike;
      }
      loadedFromCache += 1;
      return;
    }
    if (!rec.client || rec.status !== 'ready') throw new Error(`החשבון ${rec?.label || accountId} לא מחובר. חבר אותו לפני סריקה.`);
    const chat = await getVerifiedGroupForScan(rec, groupId);
    if (chat.isAdmin !== true) {
      const existing = (rec.groups || []).find(group => group.id === groupId);
      if (existing) existing.isAdmin = false;
      throw new Error(`הקבוצה ${chat.name || groupId} נחסמה כי החשבון אינו מנהל בה יותר`);
    }
    const participants = compactParticipants(chat.participants);
    const participantsCount = participants.length;
    const communityLike = isCommunityLike(chat);
    selectedByIndex[i] = {
      id: chat.id._serialized,
      key: `${rec.id}::${chat.id._serialized}`,
      accountId: rec.id,
      accountLabel: rec.account?.pushname || rec.label,
      name: chat.name || 'ללא שם',
      participantsCount,
      visibleParticipantsCount: participants.length,
      participantCountSource: 'verified.fresh.participants.userIds',
      participantCountEstimated: false,
      participantCountPending: false,
      isAdmin: Boolean(chat.isAdmin),
      isReadOnly: Boolean(chat.isReadOnly),
      communityLike,
      participants
    };
    cacheCompletedScan(selectedByIndex[i]);
    scannedFresh += 1;
    if (scannedFresh % 10 === 0) await persistScanCache();
    const existing = (rec.groups || []).find(g => g.id === groupId);
    if (existing) {
      existing.participantsCount = participantsCount;
      existing.visibleParticipantsCount = participantsCount;
      existing.participantCountSource = selectedByIndex[i].participantCountSource;
      existing.participantCountEstimated = false;
      existing.participantCountPending = false;
      existing.communityLike = communityLike;
    }
    log(`נסרקה ואומתה קבוצה: ${chat.name || groupId} — ${participantsCount} משתמשים`, 'info', rec.id);
  };

  const worker = async () => {
    while (true) {
      const i = nextIndex++;
      if (i >= total) return;
      try { await scanOne(i); }
      catch (err) {
        const resolved = resolveGroupKey(groupKeys[i]);
        const rec = accounts.get(resolved.accountId);
        const known = (rec?.groups || []).find(g => g.id === resolved.groupId);
        scanFailures.push({ id: resolved.groupId, name: known?.name || resolved.groupId, message: err.message || String(err) });
        log(`אימות הקבוצה נכשל ולא נשמר: ${known?.name || resolved.groupId} — ${err.message || err}`, 'error', rec?.id || null);
      }
      finally {
        completed += 1;
        io.emit('scanProgress', { current: completed, total, id: resolveGroupKey(groupKeys[i]).groupId });
        if (completed % 10 === 0 || completed === total) emitState();
      }
      if (options.delay !== false) await sleep(100);
    }
  };
  // Too many simultaneous metadata refresh jobs cause WhatsApp Web to return
  // cached data. Three workers keep the scan reasonably fast and verifiable.
  const concurrency = Math.min(3, total);
  await Promise.all(Array.from({ length: concurrency }, () => worker()));
  if (scannedFresh > 0) await persistScanCache();
  if (scanFailures.length) {
    const names = scanFailures.slice(0, 5).map(row => row.name).join(', ');
    throw new Error(`האימות לא הושלם עבור ${scanFailures.length} קבוצות${names ? `: ${names}` : ''}. הקבוצות שאומתו כבר נשמרו; לחץ שוב על הסריקה ורק הקבוצות שלא אומתו ייבדקו מחדש.`);
  }
  const selected = selectedByIndex.filter(Boolean);
  state.lastFullScan = { at: new Date().toISOString(), groups: selected };
  if (loadedFromCache > 0) log(`נטענו ${loadedFromCache} קבוצות מהסריקות השמורות${scannedFresh ? `, ו-${scannedFresh} קבוצות חדשות נסרקו` : ' — ללא סריקה חוזרת'}.`);
  return selected;
}

function buildAudienceReport(selected, startedAt = new Date()) {
  const memberToGroups = new Map();
  let totalEntries = 0;
  for (const group of selected) {
    const seenInsideGroup = new Set();
    for (const p of group.participants) {
      if (!p.id || seenInsideGroup.has(p.id)) continue;
      seenInsideGroup.add(p.id);
      totalEntries += 1;
      if (!memberToGroups.has(p.id)) memberToGroups.set(p.id, []);
      memberToGroups.get(p.id).push({ id: group.id, key: group.key, name: group.name, accountLabel: group.accountLabel });
    }
  }
  const duplicateMembers = [];
  for (const [memberId, groups] of memberToGroups.entries()) if (groups.length > 1) duplicateMembers.push({ memberId, groups, appearances: groups.length });
  const groupStats = selected.map(group => {
    let duplicateInGroup = 0;
    const seen = new Set();
    for (const p of group.participants) {
      if (!p.id || seen.has(p.id)) continue;
      seen.add(p.id);
      const groups = memberToGroups.get(p.id) || [];
      if (groups.length > 1) duplicateInGroup += 1;
    }
    return {
      id: group.id,
      key: group.key,
      accountId: group.accountId,
      accountLabel: group.accountLabel,
      name: group.name,
      participantsCount: group.participantsCount,
      visibleParticipantsCount: group.visibleParticipantsCount || (group.participants || []).length || group.participantsCount,
      participantCountEstimated: Boolean(group.participantCountEstimated),
      duplicateMembersInGroup: duplicateInGroup,
      uniqueOnlyInThisGroup: Math.max(((group.participants || []).length || group.participantsCount) - duplicateInGroup, 0),
      duplicateRate: (group.participants || []).length ? Number(((duplicateInGroup / (group.participants || []).length) * 100).toFixed(2)) : 0,
      communityLike: group.communityLike
    };
  }).sort((a, b) => (b.duplicateMembersInGroup - a.duplicateMembersInGroup) || (b.duplicateRate - a.duplicateRate));
  const pairStats = [];
  for (let i = 0; i < selected.length; i++) {
    const a = selected[i]; const aSet = new Set(a.participants.map(p => p.id));
    for (let j = i + 1; j < selected.length; j++) {
      const b = selected[j]; const bSet = new Set(b.participants.map(p => p.id));
      let overlap = 0; for (const id of aSet) if (bSet.has(id)) overlap++;
      pairStats.push({ groupA: `${a.name} (${a.accountLabel})`, groupB: `${b.name} (${b.accountLabel})`, groupAId: a.id, groupBId: b.id, overlap, overlapRateSmallGroup: Math.min(aSet.size, bSet.size) ? Number(((overlap / Math.min(aSet.size, bSet.size)) * 100).toFixed(2)) : 0 });
    }
  }
  pairStats.sort((a, b) => b.overlap - a.overlap || b.overlapRateSmallGroup - a.overlapRateSmallGroup);
  return {
    generatedAt: new Date().toISOString(),
    selectedGroups: selected.length,
    totalParticipantEntries: totalEntries,
    uniqueParticipants: memberToGroups.size,
    duplicateUniqueParticipants: duplicateMembers.length,
    duplicateExtraAppearances: totalEntries - memberToGroups.size,
    duplicateRateFromEntries: totalEntries ? Number((((totalEntries - memberToGroups.size) / totalEntries) * 100).toFixed(2)) : 0,
    groups: groupStats,
    topDuplicateGroups: groupStats.slice(0, 20),
    topOverlappingPairs: pairStats.slice(0, 50),
    privacy: { note: 'הדוח אינו מציג מספרי טלפון. נשמרים רק מזהי וואטסאפ פנימיים לצורך חישוב כפילויות.' },
    runtimeSeconds: Number(((new Date() - startedAt) / 1000).toFixed(1))
  };
}

async function analyzeGroups(groupKeys) {
  groupKeys = dedupeGroupKeysByGroupId(groupKeys);
  if (!Array.isArray(groupKeys) || groupKeys.length < 2) throw new Error('צריך לבחור לפחות 2 קבוצות שונות כדי לחשב כפולים');
  const startedAt = new Date();
  log(`מתחיל סריקה עבור ${groupKeys.length} קבוצות שנבחרו...`);
  const selected = await scanSelectedGroups(groupKeys);
  const report = buildAudienceReport(selected, startedAt);
  const fileBase = `report-${new Date().toISOString().replace(/[:.]/g, '-')}`;
  const jsonPath = path.join(REPORTS_DIR, `${fileBase}.json`);
  const csvPath = path.join(REPORTS_DIR, `${fileBase}-groups.csv`);
  fs.writeFileSync(jsonPath, JSON.stringify(report, null, 2), 'utf8');
  fs.writeFileSync(csvPath, toCsv(report.groups), 'utf8');
  report.files = { json: `/reports/${path.basename(jsonPath)}`, csv: `/reports/${path.basename(csvPath)}` };
  state.lastReport = report;
  log(`הסריקה הסתיימה: ${report.totalParticipantEntries} כניסות משתתפים, ${report.uniqueParticipants} ייחודיים, ${report.duplicateUniqueParticipants} כפולים ייחודיים.`);
  emitState();
  return report;
}

function uniqueStatsForGroups(groups) {
  const seen = new Set(); let total = 0;
  for (const g of groups) {
    const inside = new Set();
    for (const p of g.participants || []) {
      if (!p.id || inside.has(p.id)) continue;
      inside.add(p.id); total += 1; seen.add(p.id);
    }
  }
  const unique = seen.size;
  const duplicateExtra = Math.max(total - unique, 0);
  const duplicateRate = total ? Number(((duplicateExtra / total) * 100).toFixed(2)) : 0;
  return { total, unique, duplicateExtra, duplicateRate };
}

function recommendGroupsFromScan(scannedGroups, prefs) {
  const targetUnique = Math.max(1, Number(prefs.targetUnique || 0));
  const maxDuplicateRate = Math.max(0, Number(prefs.maxDuplicateRate ?? 12));
  const minParticipants = Math.max(0, Number(prefs.minParticipants || 0));
  const allowCommunities = Boolean(prefs.allowCommunities);
  let candidates = scannedGroups.filter(g => (g.participantsCount || 0) >= minParticipants && (allowCommunities || !g.communityLike));
  candidates = candidates.sort((a, b) => (b.participantsCount - a.participantsCount) || a.name.localeCompare(b.name, 'he'));
  const chosen = []; const chosenIds = new Set(); const memberSet = new Set(); let totalEntries = 0;
  while (candidates.length && memberSet.size < targetUnique) {
    let best = null;
    for (const g of candidates) {
      const gUniqueKey = g.key || `${g.accountId}::${g.id}`;
      if (chosenIds.has(gUniqueKey)) continue;
      const ids = [...new Set((g.participants || []).map(p => p.id).filter(Boolean))];
      let newUnique = 0; for (const id of ids) if (!memberSet.has(id)) newUnique++;
      const newTotal = totalEntries + ids.length;
      const newUniqueTotal = memberSet.size + newUnique;
      const newDupRate = newTotal ? ((newTotal - newUniqueTotal) / newTotal) * 100 : 0;
      const overlap = ids.length - newUnique;
      const under = newDupRate <= maxDuplicateRate;
      const score = (under ? 1000000 : 0) + (newUnique * 1000) + (ids.length * 2) - (overlap * 35) - (newDupRate * 120);
      const row = { group: g, ids, newUnique, newDupRate, score, under };
      if (!best || row.score > best.score) best = row;
    }
    if (!best || best.newUnique <= 0) break;
    chosen.push(best.group); chosenIds.add(best.group.key || `${best.group.accountId}::${best.group.id}`);
    totalEntries += best.ids.length; for (const id of best.ids) memberSet.add(id);
    candidates = candidates.filter(g => (g.key || `${g.accountId}::${g.id}`) !== (best.group.key || `${best.group.accountId}::${best.group.id}`));
  }
  let improved = true;
  while (improved) {
    improved = false;
    const currentStats = uniqueStatsForGroups(chosen);
    if (chosen.length <= 1) break;
    let removable = null;
    for (const g of chosen) {
      const trial = chosen.filter(x => (x.key || `${x.accountId}::${x.id}`) !== (g.key || `${g.accountId}::${g.id}`));
      const st = uniqueStatsForGroups(trial);
      if (st.unique >= targetUnique && st.duplicateRate <= maxDuplicateRate) {
        const loss = currentStats.unique - st.unique;
        const benefit = currentStats.duplicateRate - st.duplicateRate;
        const score = benefit * 1000 - loss;
        if (!removable || score > removable.score) removable = { group: g, score };
      }
    }
    if (removable) { const idx = chosen.findIndex(g => (g.key || `${g.accountId}::${g.id}`) === (removable.group.key || `${removable.group.accountId}::${removable.group.id}`)); if (idx >= 0) chosen.splice(idx, 1); improved = true; }
  }
  const stats = uniqueStatsForGroups(chosen);
  const report = buildAudienceReport(chosen, new Date());
  const okTarget = stats.unique >= targetUnique;
  const okDup = stats.duplicateRate <= maxDuplicateRate;
  return {
    generatedAt: new Date().toISOString(),
    preferences: { targetUnique, maxDuplicateRate, minParticipants, allowCommunities },
    ok: okTarget && okDup,
    okTarget,
    okDuplicateRate: okDup,
    scannedGroups: scannedGroups.length,
    eligibleGroups: scannedGroups.filter(g => (g.participantsCount || 0) >= minParticipants && (allowCommunities || !g.communityLike)).length,
    selectedGroups: chosen.map(g => ({ id: g.id, key: g.key || `${g.accountId}::${g.id}`, accountId: g.accountId, accountLabel: g.accountLabel, name: g.name, participantsCount: g.participantsCount, visibleParticipantsCount: g.visibleParticipantsCount || (g.participants || []).length || g.participantsCount, participantCountEstimated: Boolean(g.participantCountEstimated), communityLike: g.communityLike, isReadOnly: g.isReadOnly })),
    summary: { selectedGroupsCount: chosen.length, totalParticipantEntries: stats.total, uniqueParticipants: stats.unique, duplicateExtraAppearances: stats.duplicateExtra, duplicateRateFromEntries: stats.duplicateRate },
    report,
    note: okTarget && okDup ? 'נמצאה קומבינציה שעומדת ביעדים לפי הנתונים שנסרקו.' : 'לא נמצאה קומבינציה מושלמת מתוך הקבוצות שסומנו. מוצגת הקומבינציה הכי קרובה לפי האלגוריתם.'
  };
}

async function getInviteLinksForGroups(groupKeys) {
  groupKeys = requireManagedGroupKeys(groupKeys);
  const rows = [];
  for (const key of groupKeys || []) {
    const { accountId, groupId } = resolveGroupKey(key);
    const rec = accounts.get(accountId);
    try {
      if (!rec || !rec.client || rec.status !== 'ready') throw new Error(`החשבון ${rec?.label || accountId} לא מחובר`);
      const chat = await rec.client.getChatById(groupId);
      if (!chat || !chat.isGroup) throw new Error('לא קבוצה');
      let code = null;
      if (typeof chat.getInviteCode === 'function') code = await chat.getInviteCode();
      rows.push({ id: groupId, key: `${rec.id}::${groupId}`, accountId: rec.id, accountLabel: rec.account?.pushname || rec.label, name: chat.name || groupId, ok: Boolean(code), link: code ? `https://chat.whatsapp.com/${code}` : '', error: code ? '' : 'לא הצלחתי לשלוף קישור. בדרך כלל צריך להיות מנהל בקבוצה.' });
      await sleep(200);
    } catch (err) { rows.push({ id: groupId, key, accountId, name: groupId, ok: false, link: '', error: err.message || String(err) }); }
  }
  return rows;
}

function lastFourPhoneDigits(participantId) {
  const value = String(participantId || '').trim().toLowerCase();
  const [user, server = ''] = value.split('@');
  // A remaining @lid value is an internal WhatsApp identifier, not a phone
  // number. Do not present its final digits as phone digits.
  if (server === 'lid' || /g\.us|broadcast|newsletter/.test(server)) return '';
  const digits = String(user || '').replace(/\D/g, '');
  return digits.length >= 4 ? digits.slice(-4) : '';
}

function sameScannedSelection(groupKeys) {
  const requested = groupKeys.map(key => resolveGroupKey(key).groupId).sort();
  const cached = (state.lastFullScan?.groups || []).map(group => group.id).sort();
  return requested.length > 0 && requested.length === cached.length && requested.every((id, index) => id === cached[index]);
}

async function scannedGroupsForExport(groupKeys) {
  const normalized = requireManagedGroupKeys(groupKeys);
  if (sameScannedSelection(normalized)) {
    log('משתמש בסריקה האחרונה הזהה כדי ליצור את קובץ האקסל בלי לסרוק שוב.');
    return state.lastFullScan.groups;
  }
  log(`סורק ${normalized.length} קבוצות בניהול לפני יצירת קובץ האקסל...`);
  return scanSelectedGroups(normalized);
}

function buildPhoneSuffixProof(selected) {
  const membershipRows = [];
  const exactMembers = new Map();
  for (const group of selected) {
    const seenInsideGroup = new Set();
    for (const participant of group.participants || []) {
      const id = String(participant?.id || '');
      if (!id || seenInsideGroup.has(id)) continue;
      seenInsideGroup.add(id);
      const suffix = lastFourPhoneDigits(id);
      membershipRows.push({ suffix, groupName: group.name, accountLabel: group.accountLabel || '' });
      if (!exactMembers.has(id)) exactMembers.set(id, new Set());
      exactMembers.get(id).add(group.key || `${group.accountId}::${group.id}`);
    }
  }

  const availableRows = membershipRows.filter(row => row.suffix);
  const suffixCounts = new Map();
  const suffixGroups = new Map();
  for (const row of availableRows) {
    suffixCounts.set(row.suffix, (suffixCounts.get(row.suffix) || 0) + 1);
    if (!suffixGroups.has(row.suffix)) suffixGroups.set(row.suffix, new Set());
    suffixGroups.get(row.suffix).add(row.groupName);
  }
  const uniqueSuffixes = suffixCounts.size;
  const duplicateBySuffix = Math.max(availableRows.length - uniqueSuffixes, 0);
  const exactUnique = exactMembers.size;
  const exactDuplicateExtra = Math.max(membershipRows.length - exactUnique, 0);
  const duplicateSuffixRows = [...suffixCounts.entries()]
    .filter(([, count]) => count > 1)
    .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))
    .map(([suffix, count]) => [suffix, count, (suffixGroups.get(suffix) ? [...suffixGroups.get(suffix)] : []).join(' | ')]);

  return {
    membershipRows,
    availableRows,
    duplicateSuffixRows,
    stats: {
      selectedGroups: selected.length,
      totalMembershipRows: membershipRows.length,
      rowsWithLast4: availableRows.length,
      rowsWithoutPhoneMapping: membershipRows.length - availableRows.length,
      uniqueLast4: uniqueSuffixes,
      duplicateByLast4: duplicateBySuffix,
      exactUniqueParticipants: exactUnique,
      exactDuplicateExtra
    }
  };
}

async function writePhoneSuffixWorkbook(selected) {
  const proof = buildPhoneSuffixProof(selected);
  const created = new Date();
  const stamp = created.toISOString().replace(/[:.]/g, '-');
  const filePath = path.join(REPORTS_DIR, `last-4-digits-proof-${stamp}.xlsx`);
  const summaryRows = [
    ['הוכחת כמות כפולים — 4 ספרות אחרונות'],
    ['נוצר בתאריך', created.toLocaleString('he-IL')],
    ['מספר קבוצות בניהול שנבחרו', proof.stats.selectedGroups],
    ['סה״כ הופעות משתתפים בכל הקבוצות', proof.stats.totalMembershipRows],
    ['שורות שבהן זמינות 4 ספרות אחרונות', proof.stats.rowsWithLast4],
    ['ערכי 4 ספרות ייחודיים לאחר הסרת כפילויות', proof.stats.uniqueLast4],
    ['כמות כפילויות לפי 4 ספרות', proof.stats.duplicateByLast4],
    ['כמות כפילויות מדויקת לפי מזהה WhatsApp פנימי', proof.stats.exactDuplicateExtra],
    ['משתתפים ייחודיים מדויקים לפי WhatsApp', proof.stats.exactUniqueParticipants],
    ['שורות בלי מיפוי זמין למספר טלפון', proof.stats.rowsWithoutPhoneMapping],
    ['הסבר', 'הגיליון "רשימת 4 ספרות" מכיל שורה לכל הופעה של משתתף בקבוצה. אפשר להעלות אותו ל-Google Sheets ולהפעיל הסרת כפילויות.'],
    ['הערת דיוק', 'לשני אנשים שונים עשויות להיות אותן 4 ספרות אחרונות. לכן נתון הכפילויות המדויק מחושב פנימית לפי מזהה WhatsApp, בלי לחשוף אותו בקובץ.']
  ];
  const fullRows = [
    ['4 ספרות אחרונות', 'שם הקבוצה', 'חשבון מנהל'],
    ...proof.membershipRows.map(row => [row.suffix || 'לא זמין', row.groupName, row.accountLabel])
  ];
  const sheetsRows = [['4 ספרות אחרונות'], ...proof.availableRows.map(row => [row.suffix])];
  const duplicatesRows = [
    ['4 ספרות אחרונות', 'מספר הופעות', 'שמות הקבוצות'],
    ...proof.duplicateSuffixRows
  ];
  const groupsRows = [
    ['שם הקבוצה', 'חשבון מנהל', 'מספר משתתפים שנסרקו'],
    ...selected.map(group => [group.name, group.accountLabel || '', (group.participants || []).length])
  ];

  await createXlsx(filePath, [
    { name: 'סיכום', rows: summaryRows, titleRows: 1, columnWidths: [48, 100] },
    { name: 'רשימה מלאה', rows: fullRows, freezeRows: 1, autoFilterRow: 1, columnWidths: [20, 48, 26] },
    { name: 'רשימת 4 ספרות', rows: sheetsRows, freezeRows: 1, autoFilterRow: 1, columnWidths: [24] },
    { name: 'כפילויות לפי 4 ספרות', rows: duplicatesRows, freezeRows: 1, autoFilterRow: 1, columnWidths: [20, 18, 90] },
    { name: 'קבוצות שנבדקו', rows: groupsRows, freezeRows: 1, autoFilterRow: 1, columnWidths: [52, 28, 24] }
  ], { title: 'הוכחת כפילויות לפי 4 ספרות אחרונות' });
  return { filePath, proof };
}

async function writeInviteLinksWorkbook(groupKeys) {
  const links = await getInviteLinksForGroups(groupKeys);
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const filePath = path.join(REPORTS_DIR, `selected-group-links-${stamp}.xlsx`);
  const rows = [
    ['שם הקבוצה', 'חשבון מנהל', 'קישור הצטרפות', 'מצב'],
    ...links.map(row => [row.name, row.accountLabel || '', { value: row.link, style: row.link ? 5 : 0 }, row.ok ? 'הקישור נשלף' : row.error])
  ];
  await createXlsx(filePath, [{ name: 'קישורי קבוצות', rows, freezeRows: 1, autoFilterRow: 1, columnWidths: [52, 28, 62, 62] }], { title: 'קישורי הקבוצות שנבחרו' });
  return { filePath, links };
}

function toCsv(rows) {
  const headers = ['accountLabel', 'name', 'participantsCount', 'duplicateMembersInGroup', 'uniqueOnlyInThisGroup', 'duplicateRate', 'communityLike'];
  const escape = v => `"${String(v ?? '').replace(/"/g, '""')}"`;
  return '\ufeff' + [headers.join(','), ...rows.map(row => headers.map(h => escape(row[h])).join(','))].join('\n');
}

function apiState() {
  state.groups = allGroups();
  const s = statusForEmit();
  return { status: s.status, statusText: s.statusText, qrDataUrl: s.qrDataUrl, pairingCode: s.pairingCode, pairingPhone: s.pairingPhone, account: s.account, activeAccountId: state.activeAccountId, accounts: accountSummaries(), groups: state.groups, lastReport: state.lastReport, logs: state.logs.slice(0, 100) };
}

app.get('/api/state', (req, res) => res.json(apiState()));

app.post('/api/accounts/add', async (req, res) => {
  if (state.sessionBusy) return res.status(409).json({ ok: false, error: 'פעולת חיבור/ניתוק כבר רצה עכשיו' });
  const connecting = connectingRecord();
  if (connecting) {
    return res.status(409).json({
      ok: false,
      error: `החשבון ${connecting.account?.pushname || connecting.label} עדיין בתהליך חיבור. סרוק את ה-QR והמתן ל"מחובר ומוכן" לפני חיבור חשבון נוסף.`
    });
  }
  state.sessionBusy = true;
  try {
    const id = `acc-${Date.now()}`;
    const rec = ensureAccount(id, `חשבון ${accounts.size + 1}`);
    state.activeAccountId = id;
    saveAccounts();
    log('יוצר חשבון וואטסאפ נוסף. סרוק QR לחשבון החדש...', 'info', id);
    createClient(id);
    res.json({ ok: true, accountId: id });
  } catch (err) { res.status(500).json({ ok: false, error: err.message }); }
  finally { state.sessionBusy = false; emitState(); }
});

app.post('/api/accounts/switch', async (req, res) => {
  const id = req.body?.accountId;
  if (!accounts.has(id)) return res.status(404).json({ ok: false, error: 'חשבון לא נמצא' });
  const rec = accounts.get(id);
  const connecting = !rec.client ? connectingRecord(id) : null;
  if (connecting) {
    return res.status(409).json({
      ok: false,
      error: `החשבון ${connecting.account?.pushname || connecting.label} עדיין בתהליך חיבור. השלם אותו לפני הפעלת חשבון אחר.`
    });
  }
  state.activeAccountId = id;
  saveAccounts();
  if (!rec.client && !rec.starting) createClient(id);
  log(`החשבון הפעיל הוחלף ל-${rec.label}`);
  emitState();
  res.json({ ok: true });
});

app.post('/api/accounts/remove', async (req, res) => {
  if (accounts.size <= 1) return res.status(400).json({ ok: false, error: 'אי אפשר למחוק את החשבון היחיד. אפשר לנתק ולחבר אותו מחדש.' });
  const id = req.body?.accountId || state.activeAccountId;
  const rec = accounts.get(id);
  if (!rec) return res.status(404).json({ ok: false, error: 'חשבון לא נמצא' });
  try { if (rec.client) await safeDestroyClient(id); } catch (_) {}
  await safeRemoveSessionDir(id);
  accounts.delete(id);
  if (state.activeAccountId === id) state.activeAccountId = accounts.keys().next().value;
  saveAccounts();
  log(`החשבון ${rec.label} נמחק מהרשימה`);
  emitState();
  res.json({ ok: true });
});

app.post('/api/groups/refresh', async (req, res) => {
  try {
    const id = req.body?.accountId || state.activeAccountId;
    res.json({ ok: true, groups: await refreshGroups(id), allGroups: allGroups() });
  } catch (err) { res.status(500).json({ ok: false, error: err.message }); }
});

app.post('/api/groups/refresh-all', async (req, res) => {
  try {
    const ready = [...accounts.values()].filter(r => r.client && r.status === 'ready');
    for (const rec of ready) await refreshGroups(rec.id);
    res.json({ ok: true, groups: allGroups() });
  } catch (err) { res.status(500).json({ ok: false, error: err.message }); }
});

app.post('/api/analyze', async (req, res) => {
  try { res.json({ ok: true, report: await analyzeGroups(req.body.groupIds) }); }
  catch (err) { log(`שגיאת סריקה: ${err.stack || err.message}`, 'error'); res.status(500).json({ ok: false, error: err.message }); }
});

app.post('/api/export/last-four', async (req, res) => {
  try {
    const groupIds = requireManagedGroupKeys(Array.isArray(req.body?.groupIds) ? req.body.groupIds : []);
    const selected = await scannedGroupsForExport(groupIds);
    const { filePath, proof } = await writePhoneSuffixWorkbook(selected);
    log(`נוצר Excel מקבוצות בניהול בלבד: ${proof.stats.totalMembershipRows} הופעות, ${proof.stats.duplicateByLast4} כפילויות לפי 4 ספרות, ${proof.stats.exactDuplicateExtra} כפילויות מדויקות.`);
    res.json({ ok: true, url: `/reports/${path.basename(filePath)}`, stats: proof.stats });
  } catch (err) {
    log(`שגיאת ייצוא 4 ספרות אחרונות: ${err.stack || err.message}`, 'error');
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.post('/api/export/selected-links', async (req, res) => {
  try {
    const groupIds = requireManagedGroupKeys(Array.isArray(req.body?.groupIds) ? req.body.groupIds : []);
    log(`שולף קישורי הצטרפות עבור ${groupIds.length} קבוצות בניהול...`);
    const { filePath, links } = await writeInviteLinksWorkbook(groupIds);
    const okCount = links.filter(row => row.ok).length;
    log(`קובץ הקישורים מוכן: ${okCount} קישורים נשלפו מתוך ${links.length} קבוצות בניהול.`);
    res.json({ ok: true, url: `/reports/${path.basename(filePath)}`, okCount, failedCount: links.length - okCount });
  } catch (err) {
    log(`שגיאת ייצוא קישורים: ${err.stack || err.message}`, 'error');
    res.status(500).json({ ok: false, error: err.message });
  }
});


app.post('/api/session/pairing-code', async (req, res) => {
  try {
    const id = req.body?.accountId || state.activeAccountId;
    const phone = req.body?.phone;
    if (!phone) throw new Error('צריך להזין מספר טלפון לקבלת קוד צימוד');
    const result = await requestPairingCodeForAccount(id, phone);
    res.json({ ok: true, ...result });
  } catch (err) { log(`שגיאת קוד צימוד: ${err.stack || err.message}`, 'error', req.body?.accountId || state.activeAccountId); res.status(500).json({ ok: false, error: err.message }); }
});

app.post('/api/session/logout-new', async (req, res) => {
  const rec = activeRecord();
  if (!rec) return res.status(400).json({ ok: false, error: 'אין חשבון פעיל' });
  if (rec.primary) return res.status(400).json({ ok: false, error: 'זהו החשבון הראשי המשותף. אין להחליף אותו ממסך בדיקת הכפילויות.' });
  if (state.sessionBusy || rec.sessionBusy) return res.status(409).json({ ok: false, error: 'פעולת חיבור/ניתוק כבר רצה עכשיו' });
  state.sessionBusy = rec.sessionBusy = true;
  try {
    log('מתנתק ומוחק סשן כדי לחבר חשבון חדש באותו סלוט...', 'info', rec.id);
    if (rec.client) await safeDestroyClient(rec.id);
    resetAccountRuntime(rec, true);
    const removed = await safeRemoveSessionDir(rec.id);
    if (!removed) {
      throw new Error('לא הצלחתי למחוק את תיקיית הסשן כי קובץ עדיין נעול. סגור חלונות Chrome/Node ישנים ונסה שוב.');
    }
    rec.statusText = 'הסשן נמחק. יוצר QR חדש...';
    emitState();
    await sleep(800);
    createClient(rec.id);
    res.json({ ok: true });
  } catch (err) { log(`שגיאה בניתוק וחיבור חדש: ${err.stack || err.message}`, 'error', rec.id); res.status(500).json({ ok: false, error: err.message }); }
  finally { state.sessionBusy = rec.sessionBusy = false; }
});

app.post('/api/session/reconnect', async (req, res) => {
  const rec = activeRecord();
  if (!rec) return res.status(400).json({ ok: false, error: 'אין חשבון פעיל' });
  if (rec.primary) return res.json({ ok: true, message: 'החשבון הראשי כבר מחובר ומשותף לכל המערכות.' });
  if (state.sessionBusy || rec.sessionBusy) return res.status(409).json({ ok: false, error: 'פעולת חיבור/ניתוק כבר רצה עכשיו' });
  state.sessionBusy = rec.sessionBusy = true;
  try {
    log('מבצע חיבור מחדש בלי למחוק סשן...', 'info', rec.id);
    await safeDestroyClient(rec.id);
    resetAccountRuntime(rec, false);
    rec.statusText = 'מתחבר מחדש...';
    emitState();
    await sleep(500);
    createClient(rec.id);
    res.json({ ok: true });
  } catch (err) { log(`שגיאה בחיבור מחדש: ${err.stack || err.message}`, 'error', rec.id); res.status(500).json({ ok: false, error: err.message }); }
  finally { state.sessionBusy = rec.sessionBusy = false; }
});

app.post('/api/logout', async (req, res) => {
  try {
    const rec = activeRecord();
    if (rec?.client) {
      try { await rec.client.logout(); }
      catch (err) { log(`logout החזיר שגיאה לא קריטית: ${err.message || err}`, 'warn', rec.id); }
      await safeDestroyClient(rec.id);
    }
    res.json({ ok: true });
  } catch (err) { res.status(500).json({ ok: false, error: err.message }); }
});

app.post('/api/recommend', async (req, res) => {
  try {
    let { groupIds, targetUnique, maxDuplicateRate, minParticipants, allowCommunities } = req.body || {};
    groupIds = dedupeGroupKeysByGroupId(groupIds);
    if (!Array.isArray(groupIds) || groupIds.length < 1) throw new Error('צריך לסמן קבוצות לפני הפעלת ההמלצה');
    if (!Number(targetUnique)) throw new Error('צריך להזין כמה אנשים ייחודיים אתה רוצה להגיע אליהם');
    log(`AI המלצה: סורק ${groupIds.length} קבוצות מסומנות ומחשב קומבינציה...`);
    const scanned = await scanSelectedGroups(groupIds);
    const recommendation = recommendGroupsFromScan(scanned, { targetUnique, maxDuplicateRate, minParticipants, allowCommunities });
    state.lastRecommendation = recommendation;
    log(`AI המלצה הסתיימה: ${recommendation.summary.selectedGroupsCount} קבוצות, ${recommendation.summary.uniqueParticipants} ייחודיים, ${recommendation.summary.duplicateRateFromEntries}% כפילות.`);
    emitState();
    res.json({ ok: true, recommendation });
  } catch (err) { log(`שגיאת AI המלצה: ${err.stack || err.message}`, 'error'); res.status(500).json({ ok: false, error: err.message }); }
});

app.post('/api/recommend/links', async (req, res) => {
  try {
    let groupIds = dedupeGroupKeysByGroupId(Array.isArray(req.body?.groupIds) ? req.body.groupIds : []);
    if (!groupIds.length && state.lastRecommendation) groupIds = state.lastRecommendation.selectedGroups.map(g => g.key || `${g.accountId}::${g.id}`);
    if (!groupIds.length) throw new Error('אין קבוצות מומלצות לשליפת קישורים');
    log(`שולף קישורים עבור ${groupIds.length} קבוצות מומלצות...`);
    const links = await getInviteLinksForGroups(groupIds);
    res.json({ ok: true, links });
  } catch (err) { log(`שגיאת שליפת קישורים: ${err.stack || err.message}`, 'error'); res.status(500).json({ ok: false, error: err.message }); }
});

io.on('connection', socket => { socket.emit('state', apiState()); });

function start(port = PORT) {
  if (server.listening) return server;
  server.listen(port, () => {
    clearStaleWebCache();
    clearSavedReportHistory();
    loadScanCache();
    loadAccounts();
    log(`Group Audience Analyzer running on http://localhost:${PORT}`);
    saveAccounts();
    // מפעילים את החשבונות השמורים אחד-אחד. אם חשבון דורש QR, התור נעצר עליו
    // עד שהחיבור הושלם. כך לעולם לא נפתחים שני תהליכי QR/Puppeteer במקביל.
    (async () => {
      const active = activeRecord();
      const ordered = [active, ...[...accounts.values()].filter(rec => rec !== active)].filter(Boolean);
      for (const rec of ordered) {
        if (rec.client) continue;
        await waitForFreeConnectionSlot(rec.id);
        createClient(rec.id);
        await waitForInitializationTurn(rec);
        await sleep(1500);
      }
    })().catch(err => log(`שגיאה בתור הפעלת החשבונות: ${err.stack || err.message || err}`, 'error'));
  });
  return server;
}

if (require.main === module) start();

module.exports = { app, server, start, buildPhoneSuffixProof, lastFourPhoneDigits, writePhoneSuffixWorkbook };
