const $ = (selector) => document.querySelector(selector);
let current = { accounts: [], groups: [], inviteResults: [], logs: [], busy: false };

async function request(url, options = {}) {
  const response = await fetch(url, { headers: { 'Content-Type': 'application/json' }, ...options });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || 'הפעולה נכשלה');
  return data;
}
function esc(value) { return String(value ?? '').replace(/[&<>"]/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[char]); }
function status(item) { return !item.present ? '<span class="no">חסר</span>' : item.admin ? '<span class="admin">מנהל</span>' : '<span class="member">חבר</span>'; }
function accountClass(account) { return account.status === 'ready' ? 'ready' : account.status === 'awaiting_qr' ? 'waiting' : account.status === 'error' ? 'error' : 'connecting'; }
function accountLabel(account) { return account.status === 'ready' ? 'מחובר ומוכן' : account.status === 'awaiting_qr' ? 'ממתין לסריקת QR' : account.status === 'error' ? 'נדרשת בדיקה' : 'מתחבר ל־WhatsApp'; }
function renderConnectionStage(accounts) {
  const account = accounts.find((item) => item.qrDataUrl);
  const stage = $('#connect-stage');
  if (!account) { stage.hidden = true; stage.innerHTML = ''; return; }
  stage.hidden = false;
  stage.innerHTML = `<div class="qr-frame"><img src="${account.qrDataUrl}" alt="QR לחיבור ${esc(account.label)}"><span>WhatsApp ← מכשירים מקושרים ← קישור מכשיר</span></div><div class="connect-copy"><p class="section-kicker">חיבור חשבון: ${esc(account.label)}</p><h2>סרוק את ה־QR בתוך המערכת</h2><p>פתח WhatsApp בטלפון, עבור אל <strong>מכשירים מקושרים</strong>, בחר <strong>קישור מכשיר</strong> וסרוק את הקוד שמופיע כאן.</p><div class="connect-status"><i></i><span>${esc(account.statusText)}</span></div><small>הקוד מתחלף אוטומטית אם פג תוקפו. לא נפתח חלון WhatsApp או Chrome נוסף.</small></div>`;
}

function render(data) {
  current = data;
  $('#scan').disabled = data.busy;
  $('#fetch-links').disabled = data.busy || !data.groups.some((group) => group.missing.length);
  $('#promote').disabled = data.busy || !data.groups.some((group) => group.needsPromotion.length);
  const accounts = data.accounts;
  renderConnectionStage(accounts);
  $('#accounts').innerHTML = accounts.map((account, index) => `<article class="account ${accountClass(account)}"><div class="account-top"><span class="account-number">${index + 1}</span><div><strong>${esc(account.label)}</strong><span class="account-state">${account.primary ? 'חשבון ראשי משותף · ' : ''}${accountLabel(account)}</span></div><button class="remove-account" data-account-id="${esc(account.id)}" title="הסר חשבון">הסר</button></div><p>${esc(account.statusText)}</p><small class="account-ready">${account.status === 'ready' ? 'החשבון מחובר ומוכן לסריקה.' : account.qrDataUrl ? 'ממתין לסריקת ה־QR שמופיע למעלה.' : ''}</small></article>`).join('') || '<div class="empty-state"><span>+</span><strong>אין חשבונות בסנכרון</strong><p>אפשר לחבר כמה חשבונות שצריך. ה־QR יוצג בתוך המערכת.</p></div>';
  $('#head').innerHTML = `<tr><th>קבוצה / קהילה</th><th>סוג</th>${accounts.map((account) => `<th>${esc(account.label)}</th>`).join('')}<th>קישור</th></tr>`;
  $('#groups').innerHTML = data.groups.map((group) => `<tr class="${group.complete ? 'complete' : ''}"><td><strong>${esc(group.name)}</strong><small>${esc(group.id)}</small></td><td>${esc(group.type)}</td>${accounts.map((account) => `<td>${status(group.accounts[account.id])}</td>`).join('')}<td>${esc(group.inviteStatus)}</td></tr>`).join('') || `<tr><td colspan="${accounts.length + 3}">חבר את החשבונות ולחץ ״סרוק והשווה״.</td></tr>`;
  const missing = data.groups.filter((group) => group.missing.length).length;
  const promotion = data.groups.filter((group) => group.needsPromotion.length).length;
  $('#summary').textContent = `${data.groups.length} יעדים | ${missing} עם חשבון חסר | ${promotion} ממתינים לקידום`;
  $('#invites').innerHTML = data.inviteResults.map((row) => `<article class="result ${row.ok ? 'ok' : 'fail'}"><strong>${esc(row.groupName)}</strong><span>${row.ok ? `<a href="${esc(row.link)}" target="_blank" rel="noreferrer">נשלף ואומת — פתח קישור</a>` : row.codeRetrieved ? `נשלף קוד, אך האימות נכשל: ${esc(row.error)}` : esc(row.error)}</span></article>`).join('') || '<p>עדיין לא בוצעה שליפת קישורים.</p>';
  $('#logs').innerHTML = data.logs.map((row) => `<p class="${esc(row.level)}"><time>${new Date(row.at).toLocaleTimeString('he-IL')}</time> ${esc(row.text)}</p>`).join('') || '<p>ממתין לפעולה.</p>';
}
async function refresh() { try { render(await request('/api/state')); } catch (error) { console.error(error); } }
async function act(callback) { try { await callback(); await refresh(); } catch (error) { alert(error.message); await refresh(); } }

$('#add-account').addEventListener('click', () => $('#dialog').showModal());
$('#accounts').addEventListener('click', (event) => {
  const button = event.target.closest('.remove-account');
  if (!button) return;
  const account = current.accounts.find((item) => item.id === button.dataset.accountId);
  if (!account || !confirm(`להסיר את ${account.label} מסנכרון הניהול?`)) return;
  act(() => request(`/api/accounts/${encodeURIComponent(account.id)}`, { method: 'DELETE' }));
});
$('#create').addEventListener('click', (event) => { event.preventDefault(); act(async () => { await request('/api/accounts', { method: 'POST', body: JSON.stringify({ label: $('#label').value }) }); $('#dialog').close(); $('#label').value = ''; }); });
$('#scan').addEventListener('click', () => act(() => request('/api/scan', { method: 'POST', body: '{}' })));
$('#fetch-links').addEventListener('click', () => act(() => request('/api/invites', { method: 'POST', body: JSON.stringify({}) })));
$('#promote').addEventListener('click', () => {
  const targets = current.groups.filter((group) => group.needsPromotion.length).length;
  if (!targets || !confirm(`לקדם לחשבונות שכבר נמצאים בקבוצות ב־${targets} יעדים? המערכת תבדוק כל קידום.`)) return;
  act(() => request('/api/promote', { method: 'POST', body: JSON.stringify({ confirm: 'PROMOTE', delayMs: Number($('#delay').value) * 1000 }) }));
});
refresh();
setInterval(refresh, 2500);
