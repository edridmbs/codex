'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const { EventEmitter } = require('node:events');
const { Client } = require('../shared/whatsapp-client');

test('preflight responses are skipped and unavailable HTML bodies produce a handled cache warning', async () => {
  const client = new Client({ webVersionCache: { type: 'none' } });
  client.pupPage = new EventEmitter();
  client.pupPage.goto = async () => {};
  const warnings = [];
  client.on('cache_warning', error => warnings.push(error.message));
  await client.initWebVersionCache();
  const handler = client.pupPage.listeners('response')[0];
  const response = method => ({ ok: () => true, url: () => 'https://web.whatsapp.com/', request: () => ({ method: () => method }), text: async () => { throw new Error('Could not load response body'); } });
  await handler(response('OPTIONS'));
  assert.deepEqual(warnings, []);
  await handler(response('GET'));
  assert.deepEqual(warnings, ['Could not load response body']);
  await handler({ ...response('GET'), text: async () => '<html>verified content</html>' });
  assert.equal(client.currentIndexHtml, '<html>verified content</html>');
  await client.destroy();
});

test('a pending load event cannot block WhatsApp DOM navigation and other destinations keep their options', async () => {
  const client = new Client({ webVersionCache: { type: 'none' } });
  client.bootStartedAt = Date.now();
  client.pupPage = new EventEmitter();
  const calls = [];
  client.pupPage.goto = async (url, options) => {
    calls.push({ url, options });
    if (url === 'https://web.whatsapp.com/' && options.waitUntil === 'load') return new Promise(() => {});
    return 'document available';
  };
  const phases = [];
  client.on('boot_progress', details => phases.push(details.phase));
  await client.initWebVersionCache();
  let deadline;
  try {
    const result = await Promise.race([
      client.pupPage.goto('https://web.whatsapp.com/', { waitUntil: 'load', timeout: 0, referer: 'https://whatsapp.com/' }),
      new Promise((_, reject) => { deadline = setTimeout(() => reject(new Error('navigation blocked on load')), 100); }),
    ]);
    assert.equal(result, 'document available');
    assert.equal(calls[0].options.timeout, 45000);
    assert.equal(calls[0].options.referer, 'https://whatsapp.com/');
    assert.deepEqual(phases, ['browser_ready', 'page_navigation', 'document_ready']);
    await client.pupPage.goto('https://example.com/', { waitUntil: 'load', timeout: 1000 });
    assert.deepEqual(calls[1].options, { waitUntil: 'load', timeout: 1000 });
  } finally { clearTimeout(deadline); await client.destroy(); }
});
