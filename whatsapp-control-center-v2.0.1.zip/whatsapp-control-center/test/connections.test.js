'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const { EventEmitter } = require('node:events');
const { supervise } = require('../shared/connection-controller');
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

test('QR releases the next account without waiting for scan or initialize completion', async () => {
  const client = new EventEmitter();
  let timeout = false;
  const control = supervise(client, { bootMs: 20, onTimeout: () => { timeout = true; } });
  client.emit('qr', 'first');
  await control.available;
  await delay(30);
  assert.equal(timeout, false);
  control.cancel();
  assert.equal(client.listenerCount('qr'), 0);
});

test('a stuck launch releases the queue and reports its phase once', async () => {
  const client = new EventEmitter();
  const failures = [];
  const control = supervise(client, { bootMs: 15, onTimeout: phase => failures.push(phase) });
  await Promise.all([control.available, delay(30)]);
  assert.deepEqual(failures, ['boot']);
  client.emit('ready');
  assert.equal(client.listenerCount('authenticated'), 0);
});

test('repeated progress does not extend the synchronization deadline', async () => {
  const client = new EventEmitter();
  const failures = [];
  const control = supervise(client, { bootMs: 200, syncMs: 25, onTimeout: phase => failures.push(phase) });
  client.emit('authenticated');
  await delay(15);
  client.emit('authenticated');
  client.emit('loading_screen', 1);
  await delay(20);
  assert.deepEqual(failures, ['sync']);
  await control.available;
});

test('READY releases the queue and cannot be downgraded by delayed authentication', async () => {
  const client = new EventEmitter();
  const phases = [];
  const control = supervise(client, { bootMs: 15, syncMs: 15, onTimeout: () => assert.fail('timed out'), onPhase: phase => phases.push(phase) });
  client.emit('ready');
  await control.available;
  client.emit('authenticated');
  await delay(25);
  assert.deepEqual(phases, ['ready']);
});
