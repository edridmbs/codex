'use strict';

// A launch occupies the queue only until QR/READY/failure. Waiting for the
// user's scan or the full chat history must not block other saved accounts.
function supervise(client, { bootMs = 75000, syncMs = 180000, onTimeout, onPhase = () => {} }) {
  let timer;
  let finished = false;
  let released = false;
  let resolve;
  const available = new Promise((done) => { resolve = done; });
  const release = () => { if (!released) { released = true; resolve(); } };
  function arm(ms, phase) {
    clearTimeout(timer);
    timer = setTimeout(() => {
      if (finished) return;
      cancel();
      Promise.resolve().then(() => onTimeout(phase)).catch(() => {});
    }, ms);
    timer.unref?.();
  }
  const handlers = {
    qr: () => { clearTimeout(timer); release(); onPhase('qr'); },
    ready: () => { cancel(); onPhase('ready'); },
    auth_failure: () => cancel(),
    disconnected: () => cancel(),
  };
  // Do not extend the synchronization deadline on repeated authentication or
  // progress events; that would reintroduce indefinite waiting.
  let syncStarted = false;
  handlers.authenticated = () => {
    if (!syncStarted) { syncStarted = true; arm(syncMs, 'sync'); }
    onPhase('authenticated');
  };
  handlers.loading_screen = () => {
    if (!syncStarted) { syncStarted = true; arm(syncMs, 'sync'); }
    onPhase('loading');
  };
  function cancel() {
    finished = true;
    clearTimeout(timer);
    for (const [event, handler] of Object.entries(handlers)) client.off(event, handler);
    release();
  }
  for (const [event, handler] of Object.entries(handlers)) client.on(event, handler);
  arm(bootMs, 'boot');
  return { available, cancel };
}
module.exports = { supervise };
