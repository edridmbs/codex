import sys, json, subprocess, os
from PyQt5.QtWidgets import QApplication, QWidget, QLabel, QLineEdit, QTextEdit, QPushButton, QFileDialog, QGridLayout, QMessageBox

CONFIG_FILE = 'config.json'

def load_devices():
    try:
        out = subprocess.check_output(['adb','devices']).decode()
        return [l.split()[0] for l in out.splitlines() if '127.0.0.1' in l and 'device' in l]
    except:
        return []

def load_config():
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE,'r',encoding='utf-8') as f:
            return json.load(f)
    return {}

def save_config(conf):
    with open(CONFIG_FILE,'w',encoding='utf-8') as f:
        json.dump(conf,f,ensure_ascii=False,indent=2)

class App(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('WAJOY Config')
        self.devices = load_devices()
        self.conf = load_config()
        self.init_ui()

    def init_ui(self):
        layout = QGridLayout()
        layout.addWidget(QLabel('Device IP'),0,0)
        layout.addWidget(QLabel('Image Path'),0,1)
        layout.addWidget(QLabel('Browse'),0,2)
        layout.addWidget(QLabel('Message'),0,3)
        self.img_ed = {}
        self.msg_ed = {}
        for i,dev in enumerate(self.devices,1):
            layout.addWidget(QLabel(dev),i,0)
            ie = QLineEdit(self.conf.get(dev,{}).get('image',''))
            layout.addWidget(ie,i,1)
            btn = QPushButton('Browse')
            btn.clicked.connect(lambda _,entry=ie: self.browse(entry))
            layout.addWidget(btn,i,2)
            te = QTextEdit(self.conf.get(dev,{}).get('message',''))
            layout.addWidget(te,i,3)
            self.img_ed[dev] = ie
            self.msg_ed[dev] = te
        save_btn = QPushButton('Save')
        save_btn.clicked.connect(self.save)
        layout.addWidget(save_btn, len(self.devices)+1, 0, 1, 2)
        self.setLayout(layout)

    def browse(self, entry):
        path, _ = QFileDialog.getOpenFileName(self, 'Select Image', '', 'Images (*.png *.jpg *.jpeg)')
        if path:
            entry.setText(path)

    def save(self):
        new_conf = {}
        for dev in self.devices:
            new_conf[dev] = {
                'image': self.img_ed[dev].text(),
                'message': self.msg_ed[dev].toPlainText()
            }
        save_config(new_conf)
        QMessageBox.information(self, 'Saved', 'Configuration updated')

if __name__=='__main__':
    app = QApplication(sys.argv)
    w = App()
    w.show()
    sys.exit(app.exec_())
