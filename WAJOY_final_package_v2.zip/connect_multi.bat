@echo off
cd /d %~dp0
.\adb.exe kill-server
.\adb.exe start-server
set ports=21503 21513 21523 21533 21543 21553 21563 21573 21583 21593
for %%p in (%ports%) do (
    echo Connecting to 127.0.0.1:%%p...
    .\adb.exe connect 127.0.0.1:%%p
)
echo.
.\adb.exe devices
pause
