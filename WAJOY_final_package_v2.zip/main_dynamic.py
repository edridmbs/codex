import time, subprocess, random, json, os
from datetime import datetime
import schedule, colorama
import pandas as pd
import re

colorama.init(autoreset=True)
FORE, STYLE = colorama.Fore, colorama.Style
GREEN, YELLOW, RED, MAGENTA, RESET = FORE.GREEN, FORE.YELLOW, FORE.RED, FORE.MAGENTA, STYLE.RESET_ALL

LINKS_FILE   = 'links.txt'
STATE_FILE   = 'state.json'
CONFIG_FILE  = 'config.json'
REPORT_FILE  = 'report.xlsx'

BATCH             = 35
MIN_DELAY         = 60
MAX_DELAY         = 120
DEVICE_OFFSET_MIN = 30
INTERVAL_HOURS    = 10
POST_WINDOW_START = 7
POST_WINDOW_END   = 22
OPEN_WAIT         = 15
TAP_DELAY         = 5
HOME_DELAY        = 3

def adb(dev, *cmd):
    subprocess.run(['adb','-s',dev] + list(cmd), stdout=subprocess.DEVNULL)

def dump_ui(dev):
    remote, local = '/sdcard/window_dump.xml', f'window_dump_{dev}.xml'
    adb(dev, 'shell','uiautomator','dump', remote)
    adb(dev, 'pull', remote, local)
    try:
        return open(local,'r',encoding='utf-8').read()
    except:
        return ''

def find_button(xml):
    patterns = ['Join Group','הצטרפות לקבוצה','Request to Join','בקשת הצטרפות']
    for pat in patterns:
        m = re.search(r'text="{}"[^>]*bounds="(\[\d+,\d+\]\[\d+,\d+\])"'.format(pat), xml)
        if m:
            nums = list(map(int, re.findall(r'\d+', m.group(1))))
            x = (nums[0] + nums[2]) // 2
            y = (nums[1] + nums[3]) // 2
            return x, y, pat in patterns[2:]
    return None, None, False

def get_devices():
    out = subprocess.check_output(['adb','devices']).decode().splitlines()
    return [l.split()[0] for l in out if '127.0.0.1' in l and 'device' in l]

def scan_all():
    state = json.load(open(STATE_FILE)) if os.path.exists(STATE_FILE) else {}
    links = [l.strip() for l in open(LINKS_FILE) if l.strip() and not l.startswith('#')]
    report = {'open': [], 'approval': [], 'broken': []}
    for idx, dev in enumerate(get_devices()):
        if idx: time.sleep(DEVICE_OFFSET_MIN * 60)
        info = state.setdefault(dev, {'last_index': 0, 'joined': []})
        start = info['last_index']; batch = links[start:start + BATCH]
        for link in batch:
            if link in info['joined']: continue
            adb(dev, 'shell','am','start','-a','android.intent.action.VIEW','-d',link)
            time.sleep(OPEN_WAIT)
            xml = dump_ui(dev)
            x, y, isApp = find_button(xml)
            if x is not None:
                adb(dev, 'shell','input','tap', str(x), str(y)); time.sleep(TAP_DELAY)
                status = 'approval' if isApp else 'open'
            else:
                status = 'broken'
            color = GREEN if status=='open' else YELLOW if status=='approval' else RED
            print(f"{color}[{dev}] {status.upper()} {link}{RESET}")
            report[status].append(link)
            adb(dev, 'shell','input','keyevent','3'); time.sleep(HOME_DELAY)
            info['joined'].append(link)
        info['last_index']=min(start+BATCH,len(links)); state[dev]=info; json.dump(state, open(STATE_FILE,'w'), indent=2)
    with pd.ExcelWriter(REPORT_FILE) as writer:
        for k in report: pd.DataFrame(report[k], columns=['Link']).to_excel(writer, sheet_name=k.capitalize(), index=False)

def post_all():
    h=datetime.now().hour
    if not (POST_WINDOW_START<=h<POST_WINDOW_END): return
    state=json.load(open(STATE_FILE)); conf=json.load(open(CONFIG_FILE))
    for idx, dev in enumerate(get_devices()):
        if idx: time.sleep(DEVICE_OFFSET_MIN*60)
        for i, link in enumerate(state[dev]['joined']):
            img=conf.get(dev,{}).get('image',''); msg=conf.get(dev,{}).get('message','')
            adb(dev,'shell','am','start','-a','android.intent.action.SEND','-c','android.intent.category.DEFAULT',
                '--eu','android.intent.extra.TEXT',msg,'--es','android.intent.extra.STREAM',f'file://{img}','-t','image/jpeg','com.whatsapp/.ContactPicker')
            time.sleep(random.uniform(MIN_DELAY,MAX_DELAY))
            if (i+1)%50==0: time.sleep(100)

schedule.every(INTERVAL_HOURS).hours.do(scan_all)
schedule.every(INTERVAL_HOURS).hours.do(post_all)
scan_all(); post_all()
while True: schedule.run_pending(); time.sleep(60)
