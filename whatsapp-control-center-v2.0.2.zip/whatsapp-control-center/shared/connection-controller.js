'use strict';

// A launch occupies the queue only until QR/READY/failure. Waiting for the
// user's scan or the full chat history must not block other saved accounts.
function supervise(client, { bootMs = 180000, syncMs = 300000, maxSyncMs = 900000, onTimeout, onPhase = () => {} }) {
  let timer;
  let hardTimer;
  let finished = false;
  let released = false;
  let resolve;
  const available = new Promise((done) => { resolve = done; });
  const release = () => { if (!released) { released = true; resolve(); } };
  function arm(ms, phase) {
    clearTimeout(timer);
    timer = setTimeout(() => {
      if (finished) return;
      cancel();
      Promise.resolve().then(() => onTimeout(phase)).catch(() => {});
    }, ms);
    timer.unref?.();
  }
  let syncStarted = false;
  let awaitingQr = false;
  let highestProgress = -1;
  function startSync() {
    if (syncStarted) return;
    syncStarted = true;
    arm(syncMs, 'sync');
    hardTimer = setTimeout(() => {
      if (finished) return;
      cancel();
      Promise.resolve().then(() => onTimeout('sync_limit')).catch(() => {});
    }, maxSyncMs);
    hardTimer.unref?.();
  }
  function progress(value) {
    if (typeof value !== 'number' || !Number.isFinite(value) || value < 0 || value > 100) return;
    startSync();
    if (value > highestProgress) { highestProgress = value; arm(syncMs, 'sync'); }
  }
  const handlers = {
    qr: () => { clearTimeout(timer); clearTimeout(hardTimer); syncStarted = false; awaitingQr = true; release(); onPhase('qr'); },
    ready: () => { cancel(); onPhase('ready'); },
    auth_failure: () => cancel(),
    disconnected: () => cancel(),
  };
  // Only increasing progress extends the idle deadline. Repeated events do
  // not, and a separate hard limit prevents indefinite synchronization.
  handlers.authenticated = () => {
    awaitingQr = false;
    startSync();
    onPhase('authenticated');
  };
  handlers.loading_screen = percent => {
    awaitingQr = false;
    startSync();
    progress(percent);
    onPhase('loading');
  };
  handlers.boot_progress = details => {
    // The browser/document launch is sequential; restoring saved history runs
    // in parallel and must not hold the next account in the queue.
    if (details.phase === 'document_ready') release();
    if (!awaitingQr && details.phase === 'page_state' && details.debugVersionAvailable) {
      startSync();
      progress(details.syncProgress);
    }
  };
  function cancel() {
    finished = true;
    clearTimeout(timer);
    clearTimeout(hardTimer);
    for (const [event, handler] of Object.entries(handlers)) client.off(event, handler);
    release();
  }
  for (const [event, handler] of Object.entries(handlers)) client.on(event, handler);
  arm(bootMs, 'boot');
  return { available, cancel };
}
module.exports = { supervise };
