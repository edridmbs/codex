'use strict';
const { Client, LocalAuth } = require('whatsapp-web.js');
const WebCacheFactory = require('whatsapp-web.js/src/webCache/WebCacheFactory');
const { WhatsWebURL } = require('whatsapp-web.js/src/util/Constants');

// Catch failures in the library's async cache event handlers at their source.
// A missing response body affects caching, not account authentication.
class ManagedClient extends Client {
  async initialize() {
    this.bootStartedAt = Date.now();
    this.emit('boot_progress', { phase: 'browser_launch', elapsedMs: 0 });
    try { return await super.initialize(); }
    catch (error) { this.stopBootDiagnostics(); throw error; }
  }

  stopBootDiagnostics() { clearInterval(this.bootMonitor); this.bootMonitor = null; }

  async bootSnapshot() {
    const page = this.pupPage;
    if (!page || page.isClosed?.()) return { pageAvailable: false };
    return await page.evaluate(() => {
      let socket = null;
      try { socket = window.require?.('WAWebSocketModel')?.Socket; } catch (_) {}
      let syncProgress = null;
      try {
        const value = window.AuthStore?.OfflineMessageHandler?.getOfflineDeliveryProgress?.();
        if (typeof value === 'number' && Number.isFinite(value) && value >= 0 && value <= 100) syncProgress = value;
      } catch (_) {}
      return {
        pageAvailable: true,
        documentState: document.readyState,
        debugVersionAvailable: Boolean(window.Debug?.VERSION),
        appState: typeof socket?.state === 'string' ? socket.state : null,
        hasSynced: Boolean(socket?.hasSynced),
        syncProgress,
        online: navigator.onLine,
      };
    });
  }

  instrumentBootPage() {
    const page = this.pupPage;
    if (!page || this.bootPage === page) return;
    this.bootPage = page;
    const progress = (phase, details = {}) => this.emit('boot_progress', {
      phase, elapsedMs: Date.now() - this.bootStartedAt, ...details,
    });
    // Keep the library's full load readiness, but bound its timeout: 0.
    const goto = page.goto.bind(page);
    page.goto = async (url, options = {}) => {
      if (url !== WhatsWebURL) return goto(url, options);
      progress('page_navigation');
      const result = await goto(url, { ...options, waitUntil: 'load', timeout: 60000 });
      progress('document_ready');
      return result;
    };
    let failures = 0;
    page.on('requestfailed', request => {
      if (!['document', 'script', 'xhr', 'fetch'].includes(request.resourceType())) return;
      if (++failures > 10) return;
      let host = 'unknown';
      try { host = new URL(request.url()).hostname; } catch (_) {}
      this.emit('boot_network_warning', { host, resourceType: request.resourceType(), error: request.failure()?.errorText });
    });
    page.on('pageerror', error => this.emit('boot_page_warning', { message: error.message }));
    let polling = false;
    let last = '';
    this.stopBootDiagnostics();
    this.bootMonitor = setInterval(async () => {
      if (polling) return;
      polling = true;
      try {
        const snapshot = await this.bootSnapshot();
        const key = JSON.stringify(snapshot);
        if (key !== last) { last = key; progress('page_state', snapshot); }
      } catch (error) {
        progress('page_state_unavailable', { message: error.message });
      } finally { polling = false; }
    }, 5000);
    this.bootMonitor.unref?.();
    for (const event of ['ready', 'auth_failure', 'disconnected']) this.once(event, () => this.stopBootDiagnostics());
    progress('browser_ready', { browserProcessId: this.pupBrowser?.process?.()?.pid || null });
  }

  async inject() {
    this.emit('boot_progress', { phase: 'app_initialization', elapsedMs: Date.now() - this.bootStartedAt });
    return super.inject();
  }

  async destroy() {
    this.stopBootDiagnostics();
    return super.destroy();
  }

  async initWebVersionCache() {
    this.instrumentBootPage();
    const { type, ...options } = this.options.webVersionCache;
    const cache = WebCacheFactory.createWebCache(type, options);
    const content = await cache.resolve(this.options.webVersion);
    if (content) {
      await this.pupPage.setRequestInterception(true);
      this.pupPage.on('request', request => {
        if (request.isInterceptResolutionHandled()) return;
        const action = request.url() === WhatsWebURL
          ? request.respond({ status: 200, contentType: 'text/html', body: content })
          : request.continue();
        action.catch(error => this.emit('cache_warning', error));
      });
    } else {
      this.pupPage.on('response', async response => {
        if (!response.ok() || response.url() !== WhatsWebURL) return;
        if (response.request()?.method() === 'OPTIONS') return;
        try { this.currentIndexHtml = await response.text(); }
        catch (error) { this.emit('cache_warning', error); }
      });
    }
  }
}
module.exports = { Client: ManagedClient, LocalAuth };
