'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const { EventEmitter } = require('node:events');
const { supervise } = require('../shared/connection-controller');
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

test('QR releases the next account without waiting for scan or initialize completion', async () => {
  const client = new EventEmitter();
  let timeout = false;
  const control = supervise(client, { bootMs: 20, onTimeout: () => { timeout = true; } });
  client.emit('qr', 'first');
  await control.available;
  await delay(30);
  assert.equal(timeout, false);
  control.cancel();
  assert.equal(client.listenerCount('qr'), 0);
});

test('a stuck launch releases the queue and reports its phase once', async () => {
  const client = new EventEmitter();
  const failures = [];
  const control = supervise(client, { bootMs: 15, onTimeout: phase => failures.push(phase) });
  await Promise.all([control.available, delay(30)]);
  assert.deepEqual(failures, ['boot']);
  client.emit('ready');
  assert.equal(client.listenerCount('authenticated'), 0);
});

test('repeated progress does not extend the synchronization deadline', async () => {
  const client = new EventEmitter();
  const failures = [];
  const control = supervise(client, { bootMs: 200, syncMs: 25, onTimeout: phase => failures.push(phase) });
  client.emit('authenticated');
  client.emit('loading_screen', 1);
  await delay(15);
  client.emit('authenticated');
  client.emit('loading_screen', 1);
  await delay(20);
  assert.deepEqual(failures, ['sync']);
  await control.available;
});

test('document readiness releases the next account while the first restores its history', async () => {
  const client = new EventEmitter();
  const control = supervise(client, { bootMs: 200, onTimeout: () => assert.fail('timed out') });
  client.emit('boot_progress', { phase: 'document_ready' });
  await control.available;
  assert.ok(client.listenerCount('ready') > 0);
  control.cancel();
});

test('increasing chat progress keeps a slow saved login alive, with a separate maximum deadline', async () => {
  const client = new EventEmitter();
  const failures = [];
  const control = supervise(client, { bootMs: 10, syncMs: 35, maxSyncMs: 85, onTimeout: phase => failures.push(phase) });
  client.emit('boot_progress', { phase: 'page_state', debugVersionAvailable: true, syncProgress: 0 });
  await delay(20);
  client.emit('boot_progress', { phase: 'page_state', debugVersionAvailable: true, syncProgress: 8 });
  await delay(20);
  assert.deepEqual(failures, []);
  client.emit('loading_screen', 15);
  await delay(20);
  client.emit('loading_screen', 20);
  await delay(20);
  assert.deepEqual(failures, []);
  client.emit('loading_screen', 25);
  await delay(20);
  assert.deepEqual(failures, ['sync_limit']);
  await control.available;
});

test('waiting for a human QR scan has no synchronization deadline', async () => {
  const client = new EventEmitter();
  const control = supervise(client, { bootMs: 10, syncMs: 10, maxSyncMs: 10, onTimeout: () => assert.fail('timed out') });
  client.emit('qr');
  client.emit('boot_progress', { phase: 'page_state', debugVersionAvailable: true, syncProgress: 0 });
  await delay(30);
  control.cancel();
});

test('READY releases the queue and cannot be downgraded by delayed authentication', async () => {
  const client = new EventEmitter();
  const phases = [];
  const control = supervise(client, { bootMs: 15, syncMs: 15, onTimeout: () => assert.fail('timed out'), onPhase: phase => phases.push(phase) });
  client.emit('ready');
  await control.available;
  client.emit('authenticated');
  await delay(25);
  assert.deepEqual(phases, ['ready']);
});
