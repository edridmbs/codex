'use strict';

const path = require('path');
const { spawn } = require('child_process');
const express = require('express');
const { createLogger, redact } = require('./shared/diagnostics');
const diagnostics = createLogger('hub');
const events = [];
let eventId = 0;
function event(system, level, message, context) {
  const row = diagnostics.record(level, message, { ...context, source: system });
  events.push({ ...row, system, id: ++eventId });
  if (events.length > 500) events.shift();
}


const HUB_PORT = Number(process.env.HUB_PORT || 3030);
const HOST = '127.0.0.1';
const root = __dirname;
const apps = [
  { id: 'reports', name: 'בדיקת כפילויות ודוחות', port: 3031, entry: 'apps/reports/src/server.js', description: 'סריקת משתתפים, כפילויות, קישורי הצטרפות וייצוא דוחות.' },
  { id: 'master', name: 'Master Groups', port: 3032, entry: 'apps/master-groups/index.js', description: 'ניהול והפצה של הודעות לקבוצות, קהילות והכרזות.' },
  { id: 'admin', name: 'סנכרון ניהול', port: 3033, entry: 'apps/admin-sync/src/server.js', description: 'השוואת שלושה חשבונות, קישורי הצטרפות וקידום מאומת לניהול.' },
];
const children = new Map();

function startChild(item) {
  const child = spawn(process.execPath, [path.join(root, item.entry)], {
    cwd: root,
    env: { ...process.env, PORT: String(item.port), ...(process.platform === 'linux' ? { HEADLESS: 'true' } : {}), ...(!process.env.PUPPETEER_EXECUTABLE_PATH && process.platform === 'linux' && require('node:fs').existsSync('/usr/bin/chromium') ? { PUPPETEER_EXECUTABLE_PATH: '/usr/bin/chromium' } : {}) },
    stdio: ['ignore', 'pipe', 'pipe', 'ipc'],
    windowsHide: true,
  });
  event(item.id, 'info', 'מפעיל מערכת');
  child.on('message', (message) => {
    if (message?.type === 'diagnostic') {
      const row = redact(message.row);
      event(item.id, row.level, row.message, row.context);
    }
  });
  for (const [stream, level] of [[child.stdout, 'info'], [child.stderr, 'error']]) {
    let pending = '';
    stream.setEncoding('utf8');
    stream.on('data', (chunk) => {
      pending += chunk;
      const lines = pending.split(/\r?\n/); pending = lines.pop();
      for (const line of lines) if (line) event(item.id, level, line);
      if (pending.length > 12000) { event(item.id, level, pending); pending = ''; }
    });
    stream.on('end', () => { if (pending) event(item.id, level, pending); });
  }
  children.set(item.id, { child, startedAt: new Date().toISOString(), status: 'starting' });
  child.on('spawn', () => { children.get(item.id).status = 'starting'; });
  child.on('exit', (code, signal) => {
    const status = code === 0 || signal === 'SIGINT' || signal === 'SIGTERM' ? 'stopped' : 'failed';
    children.set(item.id, { ...children.get(item.id), status, code, signal });
    event(item.id, status === 'failed' ? 'error' : 'info', 'המערכת נעצרה', { code, signal });
  });
  child.on('error', (error) => {
    children.set(item.id, { ...children.get(item.id), status: 'failed', error: error.message });
    event(item.id, 'error', 'הפעלת המערכת נכשלה', { error });
  });
}

const app = express();
app.use(express.static(path.join(root, 'public')));
app.get('/api/apps', (req, res) => {
  res.json(apps.map((item) => ({
    ...item,
    url: `http://${HOST}:${item.port}`,
    state: (() => { const { child, ...state } = children.get(item.id) || { status: 'not_started' }; return redact(state); })(),
  })));
});
app.get('/api/logs', (req, res) => res.json({ events, writeFailure: diagnostics.writeFailure }));
app.get('/api/diagnostics/download', (req, res) => {
  const fs = require('node:fs');
  // Only rotated central logs: never sessions, account data, QR images or application reports.
  const contents = [diagnostics.file + '.1', diagnostics.file].filter(f => fs.existsSync(f)).map(f => fs.readFileSync(f, 'utf8')).join('');
  res.type('text/plain; charset=utf-8').attachment('whatsapp-diagnostics.jsonl').send(contents);
});
const poll = setInterval(async () => {
  for (const item of apps) {
    const state = children.get(item.id);
    if (!state || ['stopped', 'failed'].includes(state.status)) continue;
    try {
      const response = await fetch(`http://${HOST}:${item.port}${item.id === 'master' ? '/api/health' : '/api/state'}`, { signal: AbortSignal.timeout(1500) });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const body = await response.json();
      if (!body || typeof body !== 'object') throw new Error('Invalid health response');
      if (state.status !== 'running') event(item.id, 'info', 'המערכת מוכנה; אפשר לחבר חשבון WhatsApp');
      state.status = 'running';
    } catch (_) {
      if (state.status === 'running') event(item.id, 'warn', 'המערכת אינה מגיבה לבדיקת מוכנות');
      state.status = 'starting';
    }
  }
}, 3000);
poll.unref();
const hubServer = app.listen(HUB_PORT, HOST, () => {
  console.log(`WhatsApp Control Center: http://${HOST}:${HUB_PORT}`);
  for (const item of apps) startChild(item);
});

hubServer.on('error', (error) => {
  event('hub', 'error', 'לא ניתן לפתוח את מרכז השליטה', { error });
  console.error(error.code === 'EADDRINUSE' ? 'מרכז השליטה כבר פועל או שהפורט תפוס. סגור את ההפעלה הקודמת או הגדר HUB_PORT.' : error.message);
  process.exit(1);
});

let shuttingDown = false;
function shutdown() {
  if (shuttingDown) return;
  shuttingDown = true;
  clearInterval(poll);
  hubServer.close();
  const active = [...children.values()].map(({ child }) => child).filter(child => child && child.exitCode === null && child.signalCode === null);
  for (const child of active) child.kill('SIGTERM');
  const timer = setTimeout(() => {
    for (const child of active) if (child.exitCode === null && child.signalCode === null) child.kill('SIGKILL');
    process.exit(0);
  }, 4000);
  if (!active.length) { clearTimeout(timer); process.exit(0); }
  let remaining = active.length;
  for (const child of active) child.once('exit', () => { if (--remaining === 0) { clearTimeout(timer); process.exit(0); } });
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
