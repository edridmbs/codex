const $ = (selector) => document.querySelector(selector);
let current = { accounts: [], groups: [], inviteResults: [], logs: [], busy: false };

async function request(url, options = {}) {
  const response = await fetch(url, { headers: { 'Content-Type': 'application/json' }, ...options });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || 'הפעולה נכשלה');
  return data;
}
function esc(value) { return String(value ?? '').replace(/[&<>"]/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[char]); }
function status(item) { return !item.present ? '<span class="no">חסר</span>' : item.admin ? '<span class="admin">מנהל</span>' : '<span class="member">חבר</span>'; }

function render(data) {
  current = data;
  $('#scan').disabled = data.busy;
  $('#fetch-links').disabled = data.busy || !data.groups.some((group) => group.missing.length);
  $('#promote').disabled = data.busy || !data.groups.some((group) => group.needsPromotion.length);
  const accounts = data.accounts;
  $('#accounts').innerHTML = accounts.map((account) => `<article class="account"><strong>${esc(account.label)}</strong><span>${esc(account.statusText)}</span>${account.qrDataUrl ? `<img src="${account.qrDataUrl}" alt="QR לחיבור ${esc(account.label)}">` : ''}<small>${account.me ? `מחובר: ${esc(account.me)}` : ''}</small></article>`).join('') || '<p>עדיין לא חובר חשבון. חבר עד שלושה חשבונות.</p>';
  $('#head').innerHTML = `<tr><th>קבוצה / קהילה</th><th>סוג</th>${accounts.map((account) => `<th>${esc(account.label)}</th>`).join('')}<th>קישור</th></tr>`;
  $('#groups').innerHTML = data.groups.map((group) => `<tr class="${group.complete ? 'complete' : ''}"><td><strong>${esc(group.name)}</strong><small>${esc(group.id)}</small></td><td>${esc(group.type)}</td>${accounts.map((account) => `<td>${status(group.accounts[account.id])}</td>`).join('')}<td>${esc(group.inviteStatus)}</td></tr>`).join('') || '<tr><td colspan="8">חבר את החשבונות ולחץ ״סרוק והשווה״.</td></tr>';
  const missing = data.groups.filter((group) => group.missing.length).length;
  const promotion = data.groups.filter((group) => group.needsPromotion.length).length;
  $('#summary').textContent = `${data.groups.length} יעדים | ${missing} עם חשבון חסר | ${promotion} ממתינים לקידום`;
  $('#invites').innerHTML = data.inviteResults.map((row) => `<article class="result ${row.ok ? 'ok' : 'fail'}"><strong>${esc(row.groupName)}</strong><span>${row.ok ? `<a href="${esc(row.link)}" target="_blank" rel="noreferrer">נשלף ואומת — פתח קישור</a>` : row.codeRetrieved ? `נשלף קוד, אך האימות נכשל: ${esc(row.error)}` : esc(row.error)}</span></article>`).join('') || '<p>עדיין לא בוצעה שליפת קישורים.</p>';
  $('#logs').innerHTML = data.logs.map((row) => `<p class="${esc(row.level)}"><time>${new Date(row.at).toLocaleTimeString('he-IL')}</time> ${esc(row.text)}</p>`).join('') || '<p>ממתין לפעולה.</p>';
}
async function refresh() { try { render(await request('/api/state')); } catch (error) { console.error(error); } }
async function act(callback) { try { await callback(); await refresh(); } catch (error) { alert(error.message); await refresh(); } }

$('#add-account').addEventListener('click', () => { if (current.accounts.length >= 3) return alert('אפשר לחבר עד שלושה חשבונות.'); $('#dialog').showModal(); });
$('#create').addEventListener('click', (event) => { event.preventDefault(); act(async () => { await request('/api/accounts', { method: 'POST', body: JSON.stringify({ label: $('#label').value }) }); $('#dialog').close(); $('#label').value = ''; }); });
$('#scan').addEventListener('click', () => act(() => request('/api/scan', { method: 'POST', body: '{}' })));
$('#fetch-links').addEventListener('click', () => act(() => request('/api/invites', { method: 'POST', body: JSON.stringify({}) })));
$('#promote').addEventListener('click', () => {
  const targets = current.groups.filter((group) => group.needsPromotion.length).length;
  if (!targets || !confirm(`לקדם לחשבונות שכבר נמצאים בקבוצות ב־${targets} יעדים? המערכת תבדוק כל קידום.`)) return;
  act(() => request('/api/promote', { method: 'POST', body: JSON.stringify({ confirm: 'PROMOTE', delayMs: Number($('#delay').value) * 1000 }) }));
});
refresh();
setInterval(refresh, 2500);
