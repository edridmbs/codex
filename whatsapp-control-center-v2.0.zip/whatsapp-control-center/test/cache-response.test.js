'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const { EventEmitter } = require('node:events');
const { Client } = require('../shared/whatsapp-client');

test('preflight responses are skipped and unavailable HTML bodies produce a handled cache warning', async () => {
  const client = new Client({ webVersionCache: { type: 'none' } });
  client.pupPage = new EventEmitter();
  const warnings = [];
  client.on('cache_warning', error => warnings.push(error.message));
  await client.initWebVersionCache();
  const handler = client.pupPage.listeners('response')[0];
  const response = method => ({ ok: () => true, url: () => 'https://web.whatsapp.com/', request: () => ({ method: () => method }), text: async () => { throw new Error('Could not load response body'); } });
  await handler(response('OPTIONS'));
  assert.deepEqual(warnings, []);
  await handler(response('GET'));
  assert.deepEqual(warnings, ['Could not load response body']);
  await handler({ ...response('GET'), text: async () => '<html>verified content</html>' });
  assert.equal(client.currentIndexHtml, '<html>verified content</html>');
});
