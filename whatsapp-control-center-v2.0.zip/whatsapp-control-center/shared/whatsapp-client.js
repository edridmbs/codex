'use strict';
const { Client, LocalAuth } = require('whatsapp-web.js');
const WebCacheFactory = require('whatsapp-web.js/src/webCache/WebCacheFactory');
const { WhatsWebURL } = require('whatsapp-web.js/src/util/Constants');

// Catch failures in the library's async cache event handlers at their source.
// A missing response body affects caching, not account authentication.
class ManagedClient extends Client {
  async initWebVersionCache() {
    const { type, ...options } = this.options.webVersionCache;
    const cache = WebCacheFactory.createWebCache(type, options);
    const content = await cache.resolve(this.options.webVersion);
    if (content) {
      await this.pupPage.setRequestInterception(true);
      this.pupPage.on('request', request => {
        if (request.isInterceptResolutionHandled()) return;
        const action = request.url() === WhatsWebURL
          ? request.respond({ status: 200, contentType: 'text/html', body: content })
          : request.continue();
        action.catch(error => this.emit('cache_warning', error));
      });
    } else {
      this.pupPage.on('response', async response => {
        if (!response.ok() || response.url() !== WhatsWebURL) return;
        if (response.request()?.method() === 'OPTIONS') return;
        try { this.currentIndexHtml = await response.text(); }
        catch (error) { this.emit('cache_warning', error); }
      });
    }
  }
}
module.exports = { Client: ManagedClient, LocalAuth };
