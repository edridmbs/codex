'use strict';

// Reports owns every browser/profile. Consumers receive existing clients and
// replayed state, never create a second browser for the same identity.
const { EventEmitter } = require('node:events');
const events = new EventEmitter();
let records = [];
let owner = null;
function configure(service) { owner = service; }
function publish(next) { records = [...next]; events.emit('accounts', records); }
function subscribe(callback) {
  events.on('accounts', callback);
  callback(records);
  return () => events.off('accounts', callback);
}
function invoke(method, ...args) {
  if (!owner) throw new Error('מערכת החשבונות עדיין עולה; נסה שוב בעוד רגע');
  return owner[method](...args);
}
module.exports = {
  configure, publish, subscribe, snapshot: () => records,
  add: (label) => invoke('add', label),
  remove: (id) => invoke('remove', id),
  reconnect: (id) => invoke('reconnect', id),
  catalog: (client) => invoke('catalog', client),
  shutdown: () => invoke('shutdown'),
};
