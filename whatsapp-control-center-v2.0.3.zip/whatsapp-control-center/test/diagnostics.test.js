'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { redact, createLogger } = require('../shared/diagnostics');
test('redacts credentials, invite links, QR data and message content recursively', () => {
 const output = JSON.stringify(redact({ message: 'Failed https://chat.whatsapp.com/PRIVATECODE and Bearer PRIVATEKEY', context: { qr: 'PRIVATEQR', inviteCode: 'PRIVATERAW', bodyPreview: 'PRIVATEMESSAGE', nested: { cookie: 'PRIVATECOOKIE' }, phone: '972501234567', image: 'data:image/png;base64,PRIVATEIMAGE' } }));
 for (const secret of ['PRIVATECODE','PRIVATEKEY','PRIVATEQR','PRIVATERAW','PRIVATEMESSAGE','PRIVATECOOKIE','972501234567','PRIVATEIMAGE']) assert.ok(!output.includes(secret), secret);
});
test('redacts private fields in console JSON', () => {
 assert.ok(!redact('log {"qr":"PRIVATEQR","bodyPreview":"PRIVATETEXT"}').includes('PRIVATE'));
});
test('keeps error diagnostics and handles circular objects', () => {
 const error = new Error('connection refused'); const context = { error }; context.self = context;
 const result = redact(context);
 assert.equal(result.error.message, 'connection refused');
 assert.match(result.error.stack, /Error: connection refused/);
 assert.equal(result.self, '[circular]');
});
test('persists sanitized events, bounds memory and rotates files', () => {
 const dir = fs.mkdtempSync(path.join(os.tmpdir(),'wa-logs-'));
 try {
  const logger = createLogger('test', { directory: dir });
  logger.record('error', 'failed', { error: new Error('https://chat.whatsapp.com/PRIVATE') });
  assert.ok(!fs.readFileSync(logger.file,'utf8').includes('PRIVATE'));
  fs.writeFileSync(logger.file, 'x'.repeat(5 * 1024 * 1024 + 1));
  logger.record('info', 'rotated'); assert.ok(fs.existsSync(logger.file+'.1'));
  for(let i=0;i<510;i++) logger.record('info','event');
  assert.equal(logger.rows.length,500); assert.equal(logger.writeFailure,null);
 } finally { fs.rmSync(dir,{recursive:true,force:true}); }
});
