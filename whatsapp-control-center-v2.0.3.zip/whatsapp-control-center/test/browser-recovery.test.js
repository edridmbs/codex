'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const fs = require('node:fs');
const puppeteer = require('puppeteer');
const { Client: LibraryClient } = require('whatsapp-web.js');
const { Client } = require('../shared/whatsapp-client');
const executablePath = [process.env.WCC_TEST_BROWSER, '/usr/bin/chromium', puppeteer.executablePath()].find(p => p && fs.existsSync(p));

test('real Chromium bypasses a stale worker and resumes initialization after document replacement', { skip: !executablePath && 'Chromium is not installed', timeout: 30000 }, async t => {
  const server = http.createServer((req, res) => {
    if (req.url === '/worker.js') {
      res.writeHead(200, { 'Content-Type': 'text/javascript' });
      return res.end(`self.addEventListener('install', () => self.skipWaiting());
        self.addEventListener('activate', e => e.waitUntil(self.clients.claim()));
        self.addEventListener('fetch', e => { if (e.request.mode === 'navigate') e.respondWith(new Response('<h1>stale worker</h1>', {headers: {'Content-Type': 'text/html'}})); });`);
    }
    res.writeHead(200, { 'Content-Type': 'text/html', 'Cache-Control': 'no-store' });
    res.end('<!doctype html><h1>network document</h1>');
  });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const origin = `http://127.0.0.1:${server.address().port}`;
  let browser;
  const client = new Client({ webVersionCache: { type: 'none' } });
  try {
    browser = await puppeteer.launch({ executablePath, headless: true, args: ['--no-sandbox', '--disable-dev-shm-usage'] });
    const page = await browser.newPage();
    client.pupPage = page;
    client.pupBrowser = browser;
    client.bootStartedAt = Date.now();
    await page.goto(origin);
    await page.evaluate(async () => { await navigator.serviceWorker.register('/worker.js'); await navigator.serviceWorker.ready; });
    await page.waitForFunction(() => !!navigator.serviceWorker.controller);
    await page.goto(origin);
    assert.match(await page.content(), /stale worker/);
    await client.initWebVersionCache();
    await page.goto(origin);
    assert.match(await page.content(), /network document/);
    let attempts = 0;
    t.mock.method(LibraryClient.prototype, 'inject', async function () {
      attempts++;
      return this.pupPage.evaluate(() => {
        if (location.pathname === '/replacement') return 'replacement initialized';
        window.initializationWaiting = true;
        return new Promise(() => {});
      });
    });
    const warnings = [];
    client.on('cache_warning', error => warnings.push(error.message));
    const work = client.inject();
    await page.waitForFunction(() => window.initializationWaiting);
    await page.goto(`${origin}/replacement`);
    assert.equal(await work, 'replacement initialized');
    assert.equal(attempts, 2);
    assert.equal(warnings.length, 1);
  } finally {
    await client.destroy();
    if (browser?.isConnected()) await browser.close();
    await new Promise(resolve => server.close(resolve));
  }
});
