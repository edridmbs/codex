'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const { EventEmitter } = require('node:events');
const fs = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const { Client: LibraryClient } = require('whatsapp-web.js');
const { Client, LocalAuth } = require('../shared/whatsapp-client');

test('LOGOUT does not delete an open browser profile; explicit closed-browser logout still removes it', async () => {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'wcc-auth-recovery-'));
  const auth = new LocalAuth({ clientId: 'test', dataPath: dir });
  let connected = true;
  const client = new Client({ authStrategy: auth });
  client.pupBrowser = { isConnected: () => connected };
  try {
    await auth.beforeBrowserInitialized();
    const marker = path.join(auth.userDataDir, 'saved-login');
    await fs.writeFile(marker, 'preserve');
    await auth.logout();
    assert.equal(await fs.readFile(marker, 'utf8'), 'preserve');
    connected = false;
    await auth.logout();
    await assert.rejects(fs.stat(marker), { code: 'ENOENT' });
  } finally { await fs.rm(dir, { recursive: true, force: true }); }
});

test('navigation events ignore subframes, report async failures, and stop work after destroy', async t => {
  const client = new Client();
  const page = new EventEmitter();
  const main = { url: () => 'https://web.whatsapp.com/' };
  page.mainFrame = () => main;
  page.goto = async () => {};
  client.pupPage = page;
  client.bootStartedAt = Date.now();
  client.instrumentBootPage();
  let injections = 0;
  t.mock.method(LibraryClient.prototype, 'inject', async () => { injections++; throw new Error('real initialization failure'); });
  const failures = [];
  client.on('connection_error', error => failures.push(error.message));
  page.on('framenavigated', () => assert.fail('unguarded upstream handler executed'));
  try {
    page.emit('framenavigated', { url: () => 'https://web.whatsapp.com/subframe' });
    assert.equal(injections, 0);
    page.emit('framenavigated', main);
    await client.navigationWork;
    assert.deepEqual(failures, ['real initialization failure']);
    await client.destroy();
    page.emit('framenavigated', main);
    await client.navigationWork;
    assert.equal(injections, 1);
  } finally { client.stopBootDiagnostics(); }
});

test('navigation retries are bounded and unrelated initialization errors are not retried', async t => {
  const client = new Client();
  client.bootStartedAt = Date.now();
  let calls = 0;
  t.mock.method(LibraryClient.prototype, 'inject', async () => { calls++; throw new Error('Execution context was destroyed'); });
  await assert.rejects(client.inject(), /Execution context/);
  assert.equal(calls, 4);
  t.mock.method(LibraryClient.prototype, 'inject', async () => { calls++; throw new Error('auth timeout'); });
  await assert.rejects(client.inject(), /auth timeout/);
  assert.equal(calls, 5);
});
