'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const { EventEmitter } = require('node:events');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

test('Reports, Admin and Master share all identities, including late subscribers and reconnects', async () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'wa-accounts-'));
  process.env.SCALEAD_RUNTIME_DIR = root;
  process.env.DIAGNOSTICS_DIR = path.join(root, 'logs');
  process.env.ADMIN_SYNC_DATA_DIR = path.join(root, 'admin');
  process.env.MASTER_CONFIG_FILE = path.join(root, 'master.json');
  fs.mkdirSync(path.join(root, 'data'));
  fs.writeFileSync(path.join(root, 'data/accounts.json'), JSON.stringify({ controlCenterVersion: 2, activeAccountId: 'second', accounts: [
    { id: 'primary', label: 'A3', primary: true }, { id: 'second', label: 'second', primary: false },
  ] }));
  fs.mkdirSync(path.join(root, '.wwebjs_auth/session-group-audience-analyzer-second'), { recursive: true });
  fs.writeFileSync(path.join(root, '.wwebjs_auth/session-group-audience-analyzer-second/keep'), 'saved authentication');
  fs.mkdirSync(path.join(root, '.wwebjs_auth/session-group-audience-analyzer-primary'), { recursive: true });
  fs.writeFileSync(path.join(root, '.wwebjs_auth/session-group-audience-analyzer-primary/keep'), 'primary authentication');
  const instances = [];
  class FakeClient extends EventEmitter {
    constructor(options) {
      super(); this.options = options; this.initializeCount = 0; this.destroyCount = 0;
      this.info = { pushname: options.authStrategy.clientId, wid: { _serialized: `${instances.length + 1}@c.us` } };
      this.pupPage = { evaluate: async fn => {
        if (String(fn).includes('serializeParticipants')) return [{ id: { _serialized: 'group@g.us', server: 'g.us' }, name: 'shared group', isGroup: true, isAdmin: true, participants: [], groupMetadata: {} }];
        return true;
      } };
      instances.push(this);
    }
    initialize() { this.initializeCount++; setTimeout(() => this.emit('qr', `qr-${instances.indexOf(this)}`), 10); return new Promise(() => {}); }
    async destroy() { this.destroyCount++; }
    async getWWebVersion() { return 'mock'; }
    async getChats() { throw new Error('full chat serialization failed'); }
    async getChannels() { return []; }
  }
  const clientModule = require.resolve('../shared/whatsapp-client');
  require.cache[clientModule] = { id: clientModule, filename: clientModule, loaded: true, exports: { Client: FakeClient, LocalAuth: class { constructor(options) { Object.assign(this, options); } } } };
  const reports = require('../apps/reports/src/server');
  const registry = require('../shared/account-registry');
  const servers = [];
  async function start(module) {
    const server = await module.start(0); servers.push(server);
    if (!server.listening) await new Promise(resolve => server.once('listening', resolve));
    return `http://127.0.0.1:${server.address().port}`;
  }
  async function poll(fn) {
    const end = Date.now() + 3000;
    while (Date.now() < end) { if (await fn()) return; await new Promise(resolve => setTimeout(resolve, 10)); }
    assert.fail('timed out');
  }
  const get = async (url, options) => (await fetch(url, options)).json();
  const post = (url, body = {}) => get(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  try {
    const reportUrl = await start(reports);
    await poll(() => registry.snapshot().length === 2 && registry.snapshot().every(rec => rec.status === 'qr'));
    assert.equal(instances.length, 2);
    assert.match(instances[0].options.authStrategy.clientId, /primary$/);
    assert.match(instances[1].options.authStrategy.clientId, /second$/);
    assert.equal((await get(reportUrl + '/api/state')).activeAccountId, 'second');
    assert.ok(fs.existsSync(path.join(root, '.wwebjs_auth/session-group-audience-analyzer-second/keep')));
    for (const client of instances) client.emit('ready');
    // Start consumers AFTER READY: state must be replayed, with no initialize.
    const adminUrl = await start(require('../apps/admin-sync/src/server'));
    const masterUrl = await start(require('../apps/master-groups'));
    assert.deepEqual((await get(adminUrl + '/api/state')).accounts.map(a => a.status), ['ready', 'ready']);
    assert.deepEqual((await get(masterUrl + '/api/health')).accounts.map(a => a.ready), [true, true]);
    assert.equal(instances.length, 2);
    assert.ok(instances.every(client => client.initializeCount === 1));
    const scan = await post(adminUrl + '/api/scan');
    assert.equal(scan.ok, true);
    assert.equal(scan.groups[0].admins.length, 2);
    const chats = await get(masterUrl + '/api/accounts/second/chats');
    assert.equal(chats.ready, true);
    assert.equal(chats.chats[0].name, 'shared group');
    assert.equal((await post(reportUrl + '/api/session/reconnect', { accountId: 'second' })).ok, true);
    await poll(() => instances.length === 3 && registry.snapshot().find(rec => rec.id === 'second').status === 'qr');
    assert.equal(instances[1].destroyCount, 1);
    assert.equal(instances[0].destroyCount, 0);
    assert.equal(instances[1].listenerCount('message'), 0);
    assert.ok(fs.existsSync(path.join(root, '.wwebjs_auth/session-group-audience-analyzer-second/keep')));
    assert.equal((await get(adminUrl + '/api/state')).accounts.find(a => a.id === 'second').status, 'awaiting_qr');
    instances[2].emit('ready');
    instances[2].emit('authenticated'); // Delayed duplicate events must not change READY.
    assert.equal((await get(adminUrl + '/api/state')).accounts.find(a => a.id === 'second').status, 'ready');
    const removed = await get(adminUrl + '/api/accounts/second', { method: 'DELETE' });
    assert.equal(removed.ok, true);
    assert.equal((await get(masterUrl + '/api/health')).accounts.length, 1);
    assert.equal((await get(reportUrl + '/api/state')).accounts.length, 1);
    assert.equal(instances[0].destroyCount, 0);
    // Primary deletion is rejected BEFORE modifying its client/session.
    assert.equal((await post(reportUrl + '/api/accounts/remove', { accountId: 'primary' })).ok, false);
    assert.equal(instances[0].destroyCount, 0);
    const added = await post(adminUrl + '/api/accounts', { label: 'third' });
    assert.equal(added.ok, true);
    await poll(() => instances.length === 4 && registry.snapshot().some(rec => rec.status === 'qr'));
    assert.equal((await get(masterUrl + '/api/health')).accounts.length, 2);
    // A new QR for the protected primary switches profiles, preserving the old
    // login and the account identity used by both consumers.
    assert.equal((await post(reportUrl + '/api/session/new-qr', { accountId: 'primary' })).ok, false);
    assert.equal(instances.length, 4);
    assert.equal((await post(reportUrl + '/api/session/new-qr', { accountId: 'primary', confirm: 'NEW_QR' })).ok, true);
    await poll(() => instances.length === 5 && registry.snapshot().find(rec => rec.id === 'primary').status === 'qr');
    assert.equal(instances[0].destroyCount, 1);
    assert.equal(instances[0].listenerCount('message'), 0);
    assert.match(instances[4].options.authStrategy.clientId, /^group-audience-analyzer-primary-relink-/);
    assert.equal(instances[4].options.webVersionCache.type, 'none');
    assert.equal(instances[4].options.puppeteer.protocolTimeout, 900000);
    assert.ok(fs.existsSync(path.join(root, '.wwebjs_auth/session-group-audience-analyzer-primary/keep')));
    const saved = JSON.parse(fs.readFileSync(path.join(root, 'data/accounts.json')));
    assert.equal(saved.accounts.find(rec => rec.id === 'primary').authClientId, instances[4].options.authStrategy.clientId);
    assert.equal((await get(adminUrl + '/api/state')).accounts.find(rec => rec.primary).id, 'primary');
    assert.equal((await get(masterUrl + '/api/health')).accounts.length, 2);
    instances[4].emit('ready');
    assert.equal((await get(masterUrl + '/api/health')).accounts.find(rec => rec.id === 'Master_Broadcaster').ready, true);
  } finally {
    await registry.shutdown();
    for (const server of servers) await new Promise(resolve => server.close(resolve));
    fs.rmSync(root, { recursive: true, force: true });
  }
});
