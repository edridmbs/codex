const socket = io();
let groups = [];
let accounts = [];
let activeAccountId = null;
let selected = new Set();
let currentReport = null;
let currentRecommendation = null;
let scanRunning = false;

const el = id => document.getElementById(id);
const fmt = n => Number(n || 0).toLocaleString('he-IL');

function groupKey(g) { return g.key || `${g.accountId}::${g.id}`; }
function groupIdFromKey(key) {
  const value = String(key || '');
  return value.includes('::') ? value.split('::').slice(1).join('::') : value;
}
function hasSelectedSameGroup(groupId, exceptKey = null) {
  for (const key of selected) {
    if (exceptKey && key === exceptKey) continue;
    if (groupIdFromKey(key) === groupId) return true;
  }
  return false;
}
function selectedGroupsList() {
  return groups.filter(g => selected.has(groupKey(g)));
}
function uniqueGroupsById(rows) {
  const unique = new Map();
  for (const g of rows || []) {
    const id = String(g?.id || groupKey(g));
    const existing = unique.get(id);
    if (!existing || (g.accountId === activeAccountId && existing.accountId !== activeAccountId)) unique.set(id, g);
  }
  return [...unique.values()];
}
function updateQuickCalc() {
  const list = selectedGroupsList();
  const pending = list.filter(g => g.participantCountPending).length;
  const total = list.filter(g => !g.participantCountPending).reduce((sum, g) => sum + Number(g.participantsCount || 0), 0);
  const duplicateBlocked = groups.filter(g => !selected.has(groupKey(g)) && hasSelectedSameGroup(g.id)).length;
  const qGroups = el('quickGroups');
  if (qGroups) {
    el('quickGroups').textContent = fmt(list.length);
    el('quickTotal').textContent = pending
      ? `${fmt(total)} + ${fmt(pending)} ${scanRunning ? 'בסריקה' : 'טרם נסרקו'}`
      : fmt(total);
    el('quickBlocked').textContent = fmt(duplicateBlocked);
    const target = Number(el('aiTargetUnique')?.value || 0);
    el('quickTarget').textContent = target ? fmt(Math.max(target - total, 0)) : '—';
  }
  const analyzeBtn = el('analyzeBtn');
  if (analyzeBtn && !scanRunning) {
    analyzeBtn.disabled = list.length < 2;
    analyzeBtn.textContent = list.length >= 2
      ? `התחל סריקה של ${fmt(list.length)} קבוצות`
      : 'בחר לפחות 2 קבוצות לסריקה';
  }
  const exportLastFourBtn = el('exportLastFourBtn');
  const exportSelectedLinksBtn = el('exportSelectedLinksBtn');
  if (exportLastFourBtn && !scanRunning) exportLastFourBtn.disabled = list.length < 1;
  if (exportSelectedLinksBtn && !scanRunning) exportSelectedLinksBtn.disabled = list.length < 1;
}

function renderState(state) {
  activeAccountId = state.activeAccountId || activeAccountId;
  accounts = state.accounts || accounts || [];
  el('statusText').textContent = state.statusText || state.status;
  const dot = el('statusDot');
  dot.className = `dot ${state.status || ''}`;
  el('accountText').textContent = state.account?.pushname ? `פעיל: ${state.account.pushname}` : 'לא מחובר / ממתין';

  renderAccounts();
  const selectedAccount = accounts.find(acc => acc.id === activeAccountId);
  el('removeAccountBtn').disabled = Boolean(selectedAccount?.primary);
  el('logoutNewBtn').disabled = Boolean(selectedAccount?.primary);

  if (state.qrDataUrl) {
    el('qrPanel').classList.remove('hidden');
    el('qrImg').src = state.qrDataUrl;
  } else {
    el('qrPanel').classList.add('hidden');
  }

  if (state.pairingCode) {
    el('pairingResult').classList.remove('hidden');
    el('pairingCodeBox').textContent = state.pairingCode;
    el('pairingPhoneText').textContent = state.pairingPhone ? `למספר ${state.pairingPhone}` : '';
  }

  groups = (state.groups || groups).filter(group => group.isAdmin === true);
  const allowedKeys = new Set(groups.map(groupKey));
  selected = new Set([...selected].filter(key => allowedKeys.has(key)));
  if (state.lastReport) renderReport(state.lastReport);
  renderGroups();
  renderLogs(state.logs || []);
}

function renderAccounts() {
  const wrap = el('accountsWrap');
  if (!wrap) return;
  wrap.innerHTML = accounts.map(acc => {
    const title = acc.account?.pushname || acc.label || acc.id;
    const status = acc.statusText || acc.status || '';
    const cls = acc.isActive ? 'account-chip active' : 'account-chip';
    return `
      <button class="${cls}" data-account-id="${escapeHtml(acc.id)}">
        <strong>${escapeHtml(title)}</strong>
        <small>${escapeHtml(status)} · ${fmt(acc.managedGroupsCount || 0)} קבוצות בניהול</small>
      </button>
    `;
  }).join('') || '<div class="empty mini">אין חשבונות</div>';

  document.querySelectorAll('#accountsWrap .account-chip').forEach(btn => {
    btn.addEventListener('click', async () => {
      const id = btn.dataset.accountId;
      if (!id || id === activeAccountId) return;
      try { await post('/api/accounts/switch', { accountId: id }); }
      catch (e) { alert(e.message); }
    });
  });
}

function filteredGroups() {
  const q = el('searchInput').value.trim().toLowerCase();
  const sort = el('sortSelect').value;
  const filterAccount = el('accountFilter')?.value || 'all';
  let list = groups.filter(g => {
    if (filterAccount !== 'all' && g.accountId !== filterAccount) return false;
    if (g.isAdmin !== true) return false;
    return !q || (g.name || '').toLowerCase().includes(q) || (g.accountLabel || '').toLowerCase().includes(q);
  });
  list = uniqueGroupsById(list);
  if (sort === 'name') list.sort((a,b) => (a.name || '').localeCompare(b.name || '', 'he'));
  else list.sort((a,b) => (b.participantsCount - a.participantsCount) || (a.name || '').localeCompare(b.name || '', 'he'));
  return list;
}

function renderGroups() {
  const managedUniqueTotal = uniqueGroupsById(groups.filter(g => g.isAdmin === true)).length;
  el('totalGroups').textContent = fmt(managedUniqueTotal);
  el('selectedCount').textContent = fmt(selected.size);
  updateQuickCalc();
  const filter = el('accountFilter');
  if (filter) {
    const prev = filter.value || 'all';
    filter.innerHTML = '<option value="all">כל החשבונות</option>' + accounts.map(a => `<option value="${escapeHtml(a.id)}">${escapeHtml(a.account?.pushname || a.label || a.id)}</option>`).join('');
    filter.value = [...filter.options].some(o => o.value === prev) ? prev : 'all';
  }

  const list = filteredGroups();
  el('groupsList').innerHTML = list.map(g => {
    const key = groupKey(g);
    const duplicateLocked = !selected.has(key) && hasSelectedSameGroup(g.id);
    return `
    <label class="group-row ${duplicateLocked ? 'locked' : ''}">
      <input type="checkbox" data-key="${escapeHtml(key)}" data-group-id="${escapeHtml(g.id)}" ${selected.has(key) ? 'checked' : ''} ${duplicateLocked ? 'disabled' : ''} />
      <div>
        <div class="group-name">${escapeHtml(g.name)}</div>
        <div class="group-meta">
          <span class="badge account-badge">${escapeHtml(g.accountLabel || g.accountId || '')}</span>
          <span class="badge">קבוצת וואטסאפ</span>
          ${g.isAdmin ? '<span class="badge admin">בניהול החשבון</span>' : ''}
          ${duplicateLocked ? '<span class="badge lock">כבר סומנה מחשבון אחר</span>' : ''}
          ${g.communityLike ? '<span class="badge warn">חשוד כקהילה / קבוצת קהילה</span>' : ''}
          ${g.isReadOnly ? '<span class="badge warn">קריאה בלבד</span>' : ''}
          ${g.participantCountPending ? '<span class="badge warn">ספירה מדויקת בזמן הבדיקה</span>' : ''}
          ${g.participantCountEstimated && !g.participantCountPending ? '<span class="badge warn">הספירה לא אומתה</span>' : ''}
        </div>
      </div>
      <div class="count-pill pending-count">${g.participantCountPending ? 'טרם נסרקה' : fmt(g.participantsCount)}</div>
    </label>`;
  }).join('') || '<div class="empty">לא נמצאו קבוצות להצגה.</div>';

  document.querySelectorAll('#groupsList input[type="checkbox"]').forEach(cb => {
    cb.addEventListener('change', e => {
      const key = e.target.dataset.key;
      const groupId = e.target.dataset.groupId || groupIdFromKey(key);
      if (e.target.checked) {
        if (hasSelectedSameGroup(groupId, key)) {
          e.target.checked = false;
          alert('הקבוצה הזאת כבר מסומנת מחשבון אחר. כדי למנוע כפילות בחישוב אפשר לסמן כל קבוצה רק פעם אחת.');
          return;
        }
        selected.add(key);
      } else selected.delete(key);
      el('selectedCount').textContent = fmt(selected.size);
      updateQuickCalc();
      renderGroups();
  updateQuickCalc();
    });
  });
}

function renderReport(report) {
  currentReport = report;
  el('emptyReport').classList.add('hidden');
  el('reportWrap').classList.remove('hidden');
  el('mTotal').textContent = fmt(report.totalParticipantEntries);
  el('mUnique').textContent = fmt(report.uniqueParticipants);
  el('mDupUnique').textContent = fmt(report.duplicateUniqueParticipants);
  el('mDupExtra').textContent = fmt(report.duplicateExtraAppearances);

  if (report.files) {
    el('jsonLink').href = report.files.json;
    el('csvLink').href = report.files.csv;
  }

  el('groupsReport').innerHTML = (report.groups || []).map(g => `
    <tr>
      <td>${escapeHtml(g.name)}<br><small>${escapeHtml(g.accountLabel || '')}</small></td>
      <td>${fmt(g.participantsCount)}</td>
      <td>${fmt(g.duplicateMembersInGroup)}</td>
      <td>${g.duplicateRate}%</td>
    </tr>
  `).join('');

  el('pairsReport').innerHTML = (report.topOverlappingPairs || []).slice(0, 25).map(p => `
    <tr>
      <td>${escapeHtml(p.groupA)}</td>
      <td>${escapeHtml(p.groupB)}</td>
      <td>${fmt(p.overlap)}</td>
      <td>${p.overlapRateSmallGroup}%</td>
    </tr>
  `).join('') || '<tr><td colspan="4">אין חפיפות בין זוגות קבוצות.</td></tr>';
}

function renderRecommendation(rec) {
  currentRecommendation = rec;
  const box = el('recommendationBox');
  box.classList.remove('hidden');
  const s = rec.summary || {};
  const status = rec.ok ? 'עומד ביעד' : 'הכי קרוב שמצאתי';
  box.innerHTML = `
    <div class="rec-head">
      <strong>${escapeHtml(status)}</strong><br>
      ${fmt(s.selectedGroupsCount)} קבוצות · ${fmt(s.uniqueParticipants)} אנשים ייחודיים · ${fmt(s.totalParticipantEntries)} כניסות משתתפים · ${s.duplicateRateFromEntries || 0}% כפילות<br>
      <small>${escapeHtml(rec.note || '')}</small>
    </div>
    <div class="rec-list">
      ${(rec.selectedGroups || []).map(g => `
        <div class="rec-row">
          <div>
            <strong>${escapeHtml(g.name)}</strong>
            <div class="group-meta">
              <span class="badge account-badge">${escapeHtml(g.accountLabel || '')}</span>
              <span class="badge">${fmt(g.participantsCount)} משתתפים</span>
              ${g.participantCountEstimated ? `<span class="badge warn">${fmt(g.visibleParticipantsCount || 0)} זוהו לכפילויות</span>` : ''}
              ${g.communityLike ? '<span class="badge warn">קהילה/קבוצת קהילה</span>' : ''}
            </div>
          </div>
          <div class="count-pill">${fmt(g.participantsCount)}</div>
        </div>
      `).join('') || '<div class="empty">לא נמצאו קבוצות מתאימות.</div>'}
    </div>
  `;
  el('applyRecommendationBtn').disabled = !(rec.selectedGroups || []).length;
  el('linksBtn').disabled = !(rec.selectedGroups || []).length;
}

function renderLogs(logs) {
  el('logs').innerHTML = logs.map(l => `<div class="log-row ${l.level || ''}">${escapeHtml(l.ts)} · ${escapeHtml(l.message)}</div>`).join('');
}

function escapeHtml(s) {
  return String(s ?? '').replace(/[&<>'"]/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', "'":'&#39;', '"':'&quot;' }[c]));
}

async function post(url, body = {}) {
  const res = await fetch(url, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body) });
  const json = await res.json().catch(() => ({}));
  if (!res.ok || !json.ok) throw new Error(json.error || `שגיאת שרת ${res.status}`);
  return json;
}

function downloadFile(url) {
  const link = document.createElement('a');
  link.href = url;
  link.download = '';
  document.body.appendChild(link);
  link.click();
  link.remove();
}

async function guardedButton(buttonId, fn) {
  const btn = el(buttonId);
  btn.disabled = true;
  try { await fn(); }
  catch (e) { alert(e.message); }
  finally { btn.disabled = false; }
}

el('searchInput').addEventListener('input', renderGroups);
el('sortSelect').addEventListener('change', renderGroups);
el('accountFilter')?.addEventListener('change', renderGroups);
el('aiTargetUnique')?.addEventListener('input', updateQuickCalc);
el('refreshBtn').addEventListener('click', () => guardedButton('refreshBtn', async () => {
  const r = await post('/api/groups/refresh', { accountId: activeAccountId });
  groups = r.allGroups || r.groups || groups;
  renderGroups();
}));

el('refreshAllBtn')?.addEventListener('click', () => guardedButton('refreshAllBtn', async () => {
  const r = await post('/api/groups/refresh-all');
  groups = r.groups || groups;
  renderGroups();
}));

el('addAccountBtn')?.addEventListener('click', () => guardedButton('addAccountBtn', async () => {
  selected.clear();
  await post('/api/accounts/add');
}));

el('removeAccountBtn')?.addEventListener('click', () => {
  const acc = accounts.find(a => a.id === activeAccountId);
  const name = acc?.account?.pushname || acc?.label || activeAccountId;
  const ok = confirm(`למחוק את החשבון הפעיל מהרשימה ולמחוק את הסשן שלו?\n${name}`);
  if (!ok) return;
  guardedButton('removeAccountBtn', async () => {
    selected.clear();
    await post('/api/accounts/remove', { accountId: activeAccountId });
  });
});

el('reconnectBtn').addEventListener('click', () => guardedButton('reconnectBtn', async () => {
  await post('/api/session/reconnect');
}));

el('newQrBtn').addEventListener('click', () => {
  if (!confirm('לפתוח חיבור מקומי חדש לסריקת QR לחשבון הפעיל? החיבור הנוכחי ייסגר ותיקיית ההתחברות הקודמת תישמר כגיבוי. נדרשת סריקה מחדש בטלפון.')) return;
  guardedButton('newQrBtn', async () => {
    selected.clear();
    currentReport = null;
    await post('/api/session/new-qr', { accountId: activeAccountId, confirm: 'NEW_QR' });
  });
});

el('logoutNewBtn').addEventListener('click', () => {
  const ok = confirm('לנתק את החשבון הפעיל, למחוק את הסשן המקומי שלו ולהציג QR לחשבון אחר באותו סלוט?');
  if (!ok) return;
  guardedButton('logoutNewBtn', async () => {
    selected.clear();
    currentReport = null;
    currentRecommendation = null;
    el('recommendationBox').classList.add('hidden');
    el('linksOutput').classList.add('hidden');
    await post('/api/session/logout-new');
    renderGroups();
  });
});


el('pairingBtn')?.addEventListener('click', () => guardedButton('pairingBtn', async () => {
  const phone = el('pairingPhone').value.trim();
  if (!phone) return alert('תכתוב מספר טלפון לקבלת קוד צימוד');
  el('pairingResult').classList.remove('hidden');
  el('pairingCodeBox').textContent = 'מבקש קוד...';
  el('pairingPhoneText').textContent = '';
  const r = await post('/api/session/pairing-code', { accountId: activeAccountId, phone });
  el('pairingCodeBox').textContent = r.code || 'נשלחה בקשה';
  el('pairingPhoneText').textContent = r.phone ? `למספר ${r.phone}` : '';
}));

el('selectVisibleBtn').addEventListener('click', () => {
  filteredGroups().forEach(g => { if (!hasSelectedSameGroup(g.id)) selected.add(groupKey(g)); });
  renderGroups();
});
el('selectAllUniqueBtn')?.addEventListener('click', () => {
  const source = groups.filter(g => g.isAdmin === true);
  const uniqueGroups = uniqueGroupsById(source);
  selected = new Set(uniqueGroups.map(groupKey));
  renderGroups();
  el('progressText').textContent = `סומנו ${fmt(uniqueGroups.length)} קבוצות ייחודיות שבניהול לפחות אחד החשבונות`;
});
el('clearBtn').addEventListener('click', () => { selected.clear(); renderGroups(); });

el('analyzeBtn').addEventListener('click', async () => {
  if (selected.size < 2) return alert('צריך לבחור לפחות 2 קבוצות כדי לבדוק כפולים.');
  scanRunning = true;
  el('analyzeBtn').disabled = true;
  el('analyzeBtn').textContent = `סורק ${fmt(selected.size)} קבוצות...`;
  el('progressText').textContent = 'מתחיל בדיקה...';
  updateQuickCalc();
  try {
    const r = await post('/api/analyze', { groupIds: [...selected] });
    renderReport(r.report);
    el('progressText').textContent = `הסתיים: ${fmt(r.report.selectedGroups)} קבוצות נסרקו`;
  } catch (e) {
    alert(e.message);
    el('progressText').textContent = '';
  } finally {
    scanRunning = false;
    updateQuickCalc();
  }
});

el('exportLastFourBtn')?.addEventListener('click', async () => {
  if (selected.size < 1) return alert('צריך לסמן לפחות קבוצה אחת שבניהול החשבונות.');
  scanRunning = true;
  el('exportLastFourBtn').disabled = true;
  el('exportSelectedLinksBtn').disabled = true;
  el('progressText').textContent = 'מכין Excel מקבוצות בניהול בלבד. אם הבחירה עדיין לא נסרקה, הסריקה תתחיל עכשיו...';
  updateQuickCalc();
  try {
    const r = await post('/api/export/last-four', { groupIds: [...selected] });
    downloadFile(r.url);
    el('progressText').textContent = `האקסל מוכן: ${fmt(r.stats.totalMembershipRows)} הופעות, ${fmt(r.stats.uniqueLast4)} ערכי 4 ספרות ייחודיים, ${fmt(r.stats.duplicateByLast4)} כפילויות לפי 4 ספרות.`;
  } catch (e) {
    alert(e.message);
    el('progressText').textContent = 'ייצוא האקסל נכשל. הפרטים מופיעים בלוג.';
  } finally {
    scanRunning = false;
    updateQuickCalc();
  }
});

el('exportSelectedLinksBtn')?.addEventListener('click', async () => {
  if (selected.size < 1) return alert('צריך לסמן לפחות קבוצה אחת שבניהול החשבונות.');
  el('exportSelectedLinksBtn').disabled = true;
  el('progressText').textContent = 'שולף קישורי הצטרפות לקבוצות בניהול שסומנו...';
  try {
    const r = await post('/api/export/selected-links', { groupIds: [...selected] });
    downloadFile(r.url);
    el('progressText').textContent = `קובץ הקישורים מוכן: ${fmt(r.okCount)} קישורים נשלפו${r.failedCount ? `, ${fmt(r.failedCount)} לא נשלפו` : ''}.`;
  } catch (e) {
    alert(e.message);
    el('progressText').textContent = 'ייצוא הקישורים נכשל. הפרטים מופיעים בלוג.';
  } finally {
    updateQuickCalc();
  }
});

el('recommendBtn').addEventListener('click', async () => {
  if (selected.size < 1) return alert('צריך לסמן קבוצות לפני הפעלת ההמלצה.');
  const targetUnique = Number(el('aiTargetUnique').value || 0);
  const maxDuplicateRate = Number(el('aiMaxDup').value || 12);
  const minParticipants = Number(el('aiMinParticipants').value || 0);
  const allowCommunities = el('aiAllowCommunities').checked;
  if (!targetUnique) return alert('תכתוב כמה אנשים ייחודיים אתה צריך.');
  el('recommendBtn').disabled = true;
  el('progressText').textContent = 'AI סורק את הקבוצות המסומנות ומחשב המלצה...';
  try {
    const r = await post('/api/recommend', { groupIds: [...selected], targetUnique, maxDuplicateRate, minParticipants, allowCommunities });
    renderRecommendation(r.recommendation);
    el('progressText').textContent = `המלצה מוכנה: ${fmt(r.recommendation.summary.selectedGroupsCount)} קבוצות`;
  } catch (e) {
    alert(e.message);
    el('progressText').textContent = '';
  } finally {
    el('recommendBtn').disabled = false;
  }
});

el('applyRecommendationBtn').addEventListener('click', () => {
  if (!currentRecommendation) return;
  selected = new Set((currentRecommendation.selectedGroups || []).map(g => groupKey(g)));
  renderGroups();
});

el('linksBtn').addEventListener('click', async () => {
  if (!currentRecommendation || !(currentRecommendation.selectedGroups || []).length) return alert('אין עדיין המלצה.');
  el('linksBtn').disabled = true;
  el('linksOutput').classList.remove('hidden');
  el('linksOutput').value = 'שולף קישורים...';
  try {
    const groupIds = currentRecommendation.selectedGroups.map(g => groupKey(g));
    const r = await post('/api/recommend/links', { groupIds });
    el('linksOutput').value = r.links.map(row => row.ok ? row.link : `# ${row.accountLabel ? row.accountLabel + ' | ' : ''}${row.name} — ${row.error}`).join('\n');
  } catch (e) {
    el('linksOutput').value = '';
    alert(e.message);
  } finally {
    el('linksBtn').disabled = false;
  }
});

socket.on('state', renderState);
socket.on('log', l => console.log(l));
socket.on('scanProgress', p => {
  scanRunning = true;
  el('progressText').textContent = `סורק ${p.current} מתוך ${p.total}...`;
  el('analyzeBtn').disabled = true;
  el('analyzeBtn').textContent = `סורק ${p.current} מתוך ${p.total}...`;
  updateQuickCalc();
});

fetch('/api/state').then(r => r.json()).then(renderState).catch(() => {});
