'use strict';

const fs = require('fs');
const archiver = require('archiver');

function xmlEscape(value) {
  return String(value ?? '')
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

function columnName(index) {
  let value = index + 1;
  let name = '';
  while (value > 0) {
    const remainder = (value - 1) % 26;
    name = String.fromCharCode(65 + remainder) + name;
    value = Math.floor((value - 1) / 26);
  }
  return name;
}

function safeSheetName(name, used) {
  const base = String(name || 'גיליון').replace(/[\\/?*\[\]:]/g, ' ').trim().slice(0, 31) || 'גיליון';
  let candidate = base;
  let number = 2;
  while (used.has(candidate)) {
    const suffix = ` ${number++}`;
    candidate = `${base.slice(0, 31 - suffix.length)}${suffix}`;
  }
  used.add(candidate);
  return candidate;
}

function cellXml(value, ref, styleIndex) {
  const style = Number.isInteger(styleIndex) ? ` s="${styleIndex}"` : '';
  if (value === null || value === undefined || value === '') {
    return `<c r="${ref}"${style} t="inlineStr"><is><t></t></is></c>`;
  }
  if (typeof value === 'number' && Number.isFinite(value)) {
    return `<c r="${ref}"${style} t="n"><v>${value}</v></c>`;
  }
  if (typeof value === 'boolean') {
    return `<c r="${ref}"${style} t="b"><v>${value ? 1 : 0}</v></c>`;
  }
  return `<c r="${ref}"${style} t="inlineStr"><is><t xml:space="preserve">${xmlEscape(value)}</t></is></c>`;
}

function sheetXml(sheet) {
  const rows = Array.isArray(sheet.rows) ? sheet.rows : [];
  const columnCount = rows.reduce((max, row) => Math.max(max, Array.isArray(row) ? row.length : 0), 0);
  const rowCount = Math.max(rows.length, 1);
  const lastRef = `${columnName(Math.max(columnCount - 1, 0))}${rowCount}`;
  const widths = Array.isArray(sheet.columnWidths) ? sheet.columnWidths : [];
  const cols = columnCount
    ? `<cols>${Array.from({ length: columnCount }, (_, i) => `<col min="${i + 1}" max="${i + 1}" width="${Number(widths[i] || 18)}" customWidth="1"/>`).join('')}</cols>`
    : '';
  const titleRows = Number(sheet.titleRows || 0);
  const headerRows = new Set(Array.isArray(sheet.headerRows) ? sheet.headerRows : [titleRows]);
  const data = rows.map((row, rowIndex) => {
    const excelRow = rowIndex + 1;
    const values = Array.isArray(row) ? row : [];
    const cells = values.map((raw, columnIndex) => {
      const cell = raw && typeof raw === 'object' && !Array.isArray(raw) && Object.prototype.hasOwnProperty.call(raw, 'value') ? raw : { value: raw };
      let style = cell.style;
      if (!Number.isInteger(style)) {
        if (rowIndex < titleRows) style = 1;
        else if (headerRows.has(rowIndex)) style = 2;
        else if (typeof cell.value === 'number') style = Number.isInteger(cell.value) ? 3 : 4;
        else style = 0;
      }
      return cellXml(cell.value, `${columnName(columnIndex)}${excelRow}`, style);
    }).join('');
    return `<row r="${excelRow}">${cells}</row>`;
  }).join('');
  const freezeRows = Number(sheet.freezeRows || 0);
  const sheetViews = freezeRows > 0
    ? `<sheetViews><sheetView rightToLeft="1" workbookViewId="0"><pane ySplit="${freezeRows}" topLeftCell="A${freezeRows + 1}" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>`
    : '<sheetViews><sheetView rightToLeft="1" workbookViewId="0"/></sheetViews>';
  const filterRow = Number(sheet.autoFilterRow || 0);
  const autoFilter = filterRow > 0 && columnCount > 0 && rowCount >= filterRow
    ? `<autoFilter ref="A${filterRow}:${columnName(columnCount - 1)}${rowCount}"/>`
    : '';
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><dimension ref="A1:${lastRef}"/>${sheetViews}<sheetFormatPr defaultRowHeight="18"/>${cols}<sheetData>${data}</sheetData>${autoFilter}<pageMargins left="0.25" right="0.25" top="0.5" bottom="0.5" header="0.2" footer="0.2"/></worksheet>`;
}

const stylesXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <fonts count="4">
    <font><sz val="11"/><name val="Aptos"/><family val="2"/></font>
    <font><b/><sz val="16"/><color rgb="FFFFFFFF"/><name val="Aptos Display"/></font>
    <font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Aptos"/></font>
    <font><color rgb="FF0563C1"/><u/><sz val="11"/><name val="Aptos"/></font>
  </fonts>
  <fills count="5">
    <fill><patternFill patternType="none"/></fill>
    <fill><patternFill patternType="gray125"/></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FF123047"/><bgColor indexed="64"/></patternFill></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FF0F766E"/><bgColor indexed="64"/></patternFill></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FFE8F3F1"/><bgColor indexed="64"/></patternFill></fill>
  </fills>
  <borders count="2">
    <border><left/><right/><top/><bottom/><diagonal/></border>
    <border><left style="thin"><color rgb="FFD1D5DB"/></left><right style="thin"><color rgb="FFD1D5DB"/></right><top style="thin"><color rgb="FFD1D5DB"/></top><bottom style="thin"><color rgb="FFD1D5DB"/></bottom><diagonal/></border>
  </borders>
  <cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
  <cellXfs count="7">
    <xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0"><alignment horizontal="right" vertical="top" wrapText="1"/></xf>
    <xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0"><alignment horizontal="right" vertical="center" wrapText="1"/></xf>
    <xf numFmtId="0" fontId="2" fillId="3" borderId="1" xfId="0"><alignment horizontal="right" vertical="center" wrapText="1"/></xf>
    <xf numFmtId="3" fontId="0" fillId="0" borderId="1" xfId="0"><alignment horizontal="right" vertical="top"/></xf>
    <xf numFmtId="10" fontId="0" fillId="0" borderId="1" xfId="0"><alignment horizontal="right" vertical="top"/></xf>
    <xf numFmtId="0" fontId="3" fillId="0" borderId="1" xfId="0"><alignment horizontal="left" vertical="top"/></xf>
    <xf numFmtId="0" fontId="0" fillId="4" borderId="1" xfId="0"><alignment horizontal="right" vertical="top" wrapText="1"/></xf>
  </cellXfs>
  <cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
</styleSheet>`;

async function createXlsx(filePath, sheets, options = {}) {
  const used = new Set();
  const normalized = (sheets || []).map(sheet => ({ ...sheet, name: safeSheetName(sheet.name, used) }));
  if (!normalized.length) throw new Error('צריך לפחות גיליון אחד');
  fs.mkdirSync(require('path').dirname(filePath), { recursive: true });

  const output = fs.createWriteStream(filePath);
  const archive = archiver('zip', { zlib: { level: 9 } });
  const completion = new Promise((resolve, reject) => {
    output.on('close', resolve);
    output.on('error', reject);
    archive.on('error', reject);
    archive.on('warning', err => err.code === 'ENOENT' ? undefined : reject(err));
  });
  archive.pipe(output);

  const overrides = normalized.map((_, i) => `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join('');
  archive.append(`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>${overrides}<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/><Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/></Types>`, { name: '[Content_Types].xml' });
  archive.append('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/></Relationships>', { name: '_rels/.rels' });
  archive.append(`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"><Application>ScaleAd WhatsApp Group Analyzer</Application><AppVersion>1.1.25</AppVersion></Properties>`, { name: 'docProps/app.xml' });
  const now = new Date().toISOString();
  archive.append(`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>${xmlEscape(options.title || 'ScaleAd report')}</dc:title><dc:creator>ScaleAd WhatsApp Group Analyzer</dc:creator><dcterms:created xsi:type="dcterms:W3CDTF">${now}</dcterms:created><dcterms:modified xsi:type="dcterms:W3CDTF">${now}</dcterms:modified></cp:coreProperties>`, { name: 'docProps/core.xml' });

  const workbookSheets = normalized.map((sheet, i) => `<sheet name="${xmlEscape(sheet.name)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join('');
  archive.append(`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><bookViews><workbookView activeTab="0"/></bookViews><sheets>${workbookSheets}</sheets><calcPr calcId="191029" fullCalcOnLoad="1"/></workbook>`, { name: 'xl/workbook.xml' });
  const relationships = normalized.map((_, i) => `<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`).join('');
  archive.append(`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${relationships}<Relationship Id="rId${normalized.length + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`, { name: 'xl/_rels/workbook.xml.rels' });
  archive.append(stylesXml, { name: 'xl/styles.xml' });
  normalized.forEach((sheet, i) => archive.append(sheetXml(sheet), { name: `xl/worksheets/sheet${i + 1}.xml` }));
  archive.finalize();
  await completion;
  return filePath;
}

module.exports = { createXlsx };
