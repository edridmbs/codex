const container = document.querySelector('#apps');
const status = document.querySelector('#status');
const escapeHtml = (value) => String(value ?? '').replace(/[&<>\"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);
async function refresh() {
  try {
    const apps = await fetch('/api/apps').then((res) => res.json());
    const running = apps.filter((app) => app.state.status === 'running').length;
    status.textContent = `${running} מתוך ${apps.length} מערכות פעילות`;
    container.innerHTML = apps.map((app) => `<article><div><span class="badge ${escapeHtml(app.state.status)}">${escapeHtml(app.state.status)}</span><h2>${escapeHtml(app.name)}</h2><p>${escapeHtml(app.description)}</p></div><a href="${escapeHtml(app.url)}" target="_blank" rel="noreferrer">פתח מערכת</a></article>`).join('');
  } catch (error) { status.textContent = 'לא ניתן לקרוא את מצב המערכות'; }
}
refresh(); setInterval(refresh, 2000);

let logEvents = [];
const names = { hub: 'מרכז שליטה', admin: 'סנכרון ניהול', master: 'Master Groups', reports: 'כפילויות ודוחות' };
const levels = { info: 'מידע', warn: 'אזהרה', error: 'שגיאה', debug: 'אבחון' };
function renderLogs() {
  const system = document.querySelector('#log-system').value;
  const level = document.querySelector('#log-level').value;
  const rows = logEvents.filter(row => (!system || row.system === system) && (!level || row.level === level)).slice(-150).reverse();
  document.querySelector('#logs').innerHTML = rows.map(row => `<li class="${escapeHtml(row.level)}"><time>${escapeHtml(new Date(row.at).toLocaleTimeString('he-IL'))}</time> <strong>${escapeHtml(names[row.system] || row.system)}</strong> · ${escapeHtml(levels[row.level] || row.level)}<div>${escapeHtml(row.message)}</div></li>`).join('') || '<li>עדיין אין אירועים המתאימים למסנן.</li>';
}
async function refreshLogs() {
  try {
    const response = await fetch('/api/logs');
    if (!response.ok) throw new Error('HTTP ' + response.status);
    const data = await response.json(); logEvents = data.events;
    document.querySelector('#log-status').textContent = data.writeFailure ? 'שמירת האבחון לקובץ נכשלה: ' + data.writeFailure : 'היומן מתעדכן אוטומטית';
    renderLogs();
  } catch (_) { document.querySelector('#log-status').textContent = 'עדכון היומן נכשל; מנסה שוב אוטומטית'; }
}
document.querySelector('#log-system').addEventListener('change', renderLogs);
document.querySelector('#log-level').addEventListener('change', renderLogs);
refreshLogs(); setInterval(refreshLogs, 2000);
